export type Language = 'en' | 'hi';

export const translations = {
  en: {
    // Header & Common
    appTag: 'CAL AI • SMART NUTRITION',
    stepOf: 'Step',
    of: 'of',
    continue: 'Continue →',
    back: 'Back',
    skip: 'Skip for now',
    skipOptional: 'Skip (Optional)',
    recommended: 'Recommended',
    optionalBadge: 'OPTIONAL',

    // Step 0: Welcome
    heroBadge: '✨ #1 AI Nutrition & Calorie Tracker',
    heroTitle1: 'Reach Your',
    heroTitle2: 'Dream Body',
    heroSubtitle: 'Simple, accurate AI calorie tracking calibrated to your body and habits.',
    heroStartBtn: 'Get Started →',
    heroStat: '2.1M+ people tracking daily',

    // Step 1: Goal
    goalTitle: 'What is your main goal?',
    goalSubtitle: 'We will calculate your exact daily calories and macros.',
    goals: {
      lose_weight: { title: 'Lose Weight & Burn Fat', desc: 'Shed excess fat while staying strong and toned' },
      build_muscle: { title: 'Build Lean Muscle', desc: 'Gain healthy muscle mass with high protein target' },
      maintain_tone: { title: 'Stay Fit & Toned', desc: 'Maintain your current weight and improve fitness' },
      improve_health: { title: 'Boost Energy & Health', desc: 'Eat cleaner, feel energized, and live healthy' },
    },

    // Step 2: Body Focus
    focusTitle: 'Where do you want to see results?',
    focusSubtitle: 'Select your primary focus area for body transformation.',
    focusAreas: {
      belly: { title: 'Belly & Waist', desc: 'Flatten tummy and burn visceral fat' },
      upper: { title: 'Chest, Arms & Back', desc: 'Build upper body strength and definition' },
      lower: { title: 'Legs, Thighs & Glutes', desc: 'Tone lower body and improve athletic power' },
      full: { title: 'Full Body Transformation', desc: 'Overall fat loss and full body toning' },
    },

    // Step 3: Gender
    genderTitle: 'What is your biological sex?',
    genderSubtitle: 'Used to calculate your basal metabolic burn rate (BMR).',
    genders: {
      male: { title: 'Male', desc: 'Standard male metabolic formula' },
      female: { title: 'Female', desc: 'Standard female metabolic formula' },
    },

    // Step 4: Age
    ageTitle: 'How old are you?',
    ageSubtitle: 'Age helps us determine your daily calorie burn speed.',
    years: 'years old',

    // Step 5: Height & Weight
    hwTitle: 'Height & Current Weight',
    hwSubtitle: 'Used to calculate your Body Mass Index (BMI).',
    height: 'Height',
    weight: 'Current Weight',
    bmiLabel: 'Your current BMI is',

    // Step 6: Target Weight & Pace
    targetTitle: 'What is your target weight?',
    targetSubtitle: 'Slide to select your dream weight milestone.',
    targetLabel: 'Target Goal',
    paceTitle: 'Select your goal pace:',
    paces: {
      slow: { title: 'Easy & Relaxed', rate: '0.25 kg / week', desc: 'Gentle habit changes' },
      steady: { title: 'Steady (Recommended)', rate: '0.50 kg / week', desc: 'Best long-term results' },
      moderate: { title: 'Fast Track', rate: '0.75 kg / week', desc: 'Motivated & focused' },
    },

    // Step 7: Daily Activity
    activityTitle: 'What is your daily activity level?',
    activitySubtitle: 'Select how much you move on a typical day.',
    activities: {
      sedentary: { title: 'Sedentary (Desk Job)', desc: 'Mostly sitting, minimal walking' },
      lightly_active: { title: 'Lightly Active', desc: 'Light walks / workouts 1-2 days a week' },
      moderately_active: { title: 'Moderately Active', desc: 'Workouts or gym 3-5 days a week' },
      very_active: { title: 'Very Active', desc: 'Heavy training or physical daily job' },
    },

    // Step 8: Diet Style
    dietTitle: 'What type of food do you eat?',
    dietSubtitle: 'We will customize your meals and macro split for your diet.',
    diets: [
      { id: 'Anything / Balanced', title: 'Standard / All Foods', desc: 'Chicken, fish, eggs, dairy, vegetables & grains' },
      { id: 'Vegetarian', title: 'Vegetarian', desc: 'Pure vegetarian diet with lentils, paneer & dairy' },
      { id: 'Eggetarian', title: 'Eggetarian', desc: 'Vegetarian foods plus eggs' },
      { id: 'Vegan', title: 'Plant-Based / Vegan', desc: '100% plant foods, tofu, legumes & nuts' },
    ],

    // Step 9: Obstacles
    obstacleTitle: 'What is your biggest daily challenge?',
    obstacleSubtitle: 'Select all that apply so Cal AI can help you succeed.',
    obstaclesList: [
      'Late-night snacking',
      'Sugar & sweet cravings',
      'Low daily protein intake',
      'Busy work / Lack of time',
      'Eating outside / Ordering food',
      'Drinking enough water',
    ],

    // Step 10: Optional Medical Report
    reportStepTitle: 'Medical / Blood Report (Optional)',
    reportStepSubtitle: 'Upload a lab report or click an easy sample to adjust your nutrients.',
    reportOptionalHint: 'This step is completely optional. You can skip anytime.',
    trySampleTitle: '⚡ Try 1-Click Easy Sample:',
    sampleLipid: 'Sample: Mild Cholesterol Report',
    sampleSugar: 'Sample: Normal Wellness Bloodwork',
    uploadBoxTitle: 'Upload or photo of your report',
    uploadBoxSubtitle: 'PDF, JPG, PNG or photo from phone',
    skipReportBtn: 'Skip this step →',

    // Step 11: Account
    accountTitle: 'Save Your Health Plan',
    accountSubtitle: 'Create your free account to sync your daily diary securely.',
    fullName: 'Full Name',
    email: 'Email Address',
    password: 'Password',
    createAccountBtn: 'Generate My Cal AI Plan →',
    creatingBtn: 'Calculating & Saving Plan...',

    // Step 12: Loading
    calculatingTitle: 'Creating Your Personalized Plan...',
    calculatingBmr: 'Calibrating Basal Metabolic Rate (BMR)...',
    calculatingMacros: 'Calculating Protein, Carbs & Fats...',
    calculatingTimeline: 'Setting target milestone date...',
    calculatingDone: 'Plan Ready!',
  },

  hi: {
    // Header & Common
    appTag: 'CAL AI • स्मार्ट न्यूट्रिशन',
    stepOf: 'स्टेप',
    of: 'का',
    continue: 'आगे बढ़ें →',
    back: 'पीछे',
    skip: 'अभी छोड़ें (Skip)',
    skipOptional: 'छोड़ें (वैकल्पic)',
    recommended: 'बेस्ट ऑप्शन',
    optionalBadge: 'वैकल्पिक (OPTIONAL)',

    // Step 0: Welcome
    heroBadge: '✨ #1 AI डाइट और कैलोरी ट्रैकर',
    heroTitle1: 'पाएं अपना',
    heroTitle2: 'परफेक्ट बॉडी गोल',
    heroSubtitle: 'आसान और सटीक AI कैलोरी ट्रैकर जो आपके शरीर और आदतों के अनुसार तैयार होता है।',
    heroStartBtn: 'शुरू करें →',
    heroStat: '21 लाख+ लोग रोज़ इस्तेमाल कर रहे हैं',

    // Step 1: Goal
    goalTitle: 'आपका मुख्य लक्ष्य क्या है?',
    goalSubtitle: 'हम आपके लिए सही कैलोरी और प्रोटीन की मात्रा तय करेंगे।',
    goals: {
      lose_weight: { title: 'वजन घटाएं और फैट बर्न करें', desc: 'पेट और शरीर का एक्स्ट्रा फैट कम करें और फिट रहें' },
      build_muscle: { title: 'मसल बनाएं (Lean Muscle)', desc: 'हाई प्रोटीन डाइट के साथ मजबूत बॉडी बनाएं' },
      maintain_tone: { title: 'फिट और टोन्ड रहें', desc: 'वर्तमान वजन बनाए रखें और एनर्जी बढ़ाएं' },
      improve_health: { title: 'हेल्थ और एनर्जी बढ़ाएं', desc: 'अच्छा खाना खाएं और दिनभर एक्टिव महसूस करें' },
    },

    // Step 2: Body Focus
    focusTitle: 'आप किस हिस्से पर ज्यादा फोकस करना चाहते हैं?',
    focusSubtitle: 'अपने ट्रांसफॉर्मेशन का मुख्य फोकस एरिया चुनें।',
    focusAreas: {
      belly: { title: 'पेट और कमर (Belly Fat)', desc: 'पेट की चर्बी कम करके फ्लैट पेट पाएं' },
      upper: { title: 'छाती, बाहें और पीठ', desc: 'ऊपरी शरीर को मजबूत और मस्कुलर बनाएं' },
      lower: { title: 'पैर और जांघें (Legs & Thighs)', desc: 'पैरों को टोन्ड और एक्टिव बनाएं' },
      full: { title: 'पूरा शरीर (Full Body)', desc: 'पूरे शरीर का फैट लॉस और फिटनेस' },
    },

    // Step 3: Gender
    genderTitle: 'आपका जेंडर क्या है?',
    genderSubtitle: 'यह आपकी मेटाबॉलिक बर्न रेट (BMR) जानने के लिए जरूरी है।',
    genders: {
      male: { title: 'पुरुष (Male)', desc: 'पुरुषों के मेटाबॉलिक फॉर्मूले के अनुसार' },
      female: { title: 'महिला (Female)', desc: 'महिलाओं के मेटाबॉलिक फॉर्मूले के अनुसार' },
    },

    // Step 4: Age
    ageTitle: 'आपकी उम्र कितनी है?',
    ageSubtitle: 'उम्र के हिसाब से कैलोरी बर्न होने की स्पीड तय होती है।',
    years: 'साल',

    // Step 5: Height & Weight
    hwTitle: 'आपकी लंबाई और वजन',
    hwSubtitle: 'इससे हम आपका बॉडी मास इंडेक्स (BMI) निकालेंगे।',
    height: 'लंबाई (Height)',
    weight: 'वर्तमान वजन (Weight)',
    bmiLabel: 'आपका वर्तमान BMI है',

    // Step 6: Target Weight & Pace
    targetTitle: 'आप कितना वजन हासिल करना चाहते हैं?',
    targetSubtitle: 'स्लाइडर से अपना टारगेट गोल वजन चुनें।',
    targetLabel: 'टारगेट वजन',
    paceTitle: 'वजन बदलने की स्पीड चुनें:',
    paces: {
      slow: { title: 'आराम से (Easy)', rate: '0.25 kg / हफ्ता', desc: 'आसान और लगातार' },
      steady: { title: 'बेस्ट स्पीड (Recommended)', rate: '0.50 kg / हफ्ता', desc: 'सबसे टिकाऊ और स्वस्थ तरीका' },
      moderate: { title: 'तेज़ स्पीड (Fast)', rate: '0.75 kg / हफ्ता', desc: 'जल्दी रिजल्ट पाने के लिए' },
    },

    // Step 7: Daily Activity
    activityTitle: 'आप रोज़ाना कितने एक्टिव रहते हैं?',
    activitySubtitle: 'दिनभर में आपका चलना-फिरना कितना होता है।',
    activities: {
      sedentary: { title: 'कम चलना (Desk Job)', desc: 'ज्यादातर बैठना, बहुत कम चलना' },
      lightly_active: { title: 'हल्का एक्टिव', desc: 'हफ्ते में 1-2 दिन वॉक या हल्की कसरत' },
      moderately_active: { title: 'मीडियम एक्टिव', desc: 'हफ्ते में 3-5 दिन जिम या वर्कआउट' },
      very_active: { title: 'काफी एक्टिव', desc: 'भारी वर्कआउट या मेहनत वाला काम' },
    },

    // Step 8: Diet Style
    dietTitle: 'आप किस तरह का खाना खाते हैं?',
    dietSubtitle: 'हम आपके पसंदीदा खाने के अनुसार ही डाइट प्लान बनाएंगे।',
    diets: [
      { id: 'Anything / Balanced', title: 'नॉन-वेज / सब कुछ', desc: 'चिकन, मछली, अंडे, दालें, रोटी और सब्जियां' },
      { id: 'Vegetarian', title: 'शुद्ध शाकाहारी (Vegetarian)', desc: 'दाल, पनीर, दूध, दही, सब्जियां और फल' },
      { id: 'Eggetarian', title: 'अंडा + शाकाहारी (Eggetarian)', desc: 'शाकाहारी खाना और अंडे' },
      { id: 'Vegan', title: 'वीगन (Vegan)', desc: '100% पौधे आधारित आहार, टोफू और दालें' },
    ],

    // Step 9: Obstacles
    obstacleTitle: 'आपकी सबसे बड़ी चुनौती क्या है?',
    obstacleSubtitle: 'जो भी परेशानियां आती हैं, उन्हें सेलेक्ट करें ताकि AI आपकी मदद कर सके।',
    obstaclesList: [
      'रात को भूख लगना (Late night snacks)',
      'मीठा खाने की तलब (Sugar cravings)',
      'कम प्रोटीन मिल पाना',
      'व्यस्त दिनचर्या / समय की कमी',
      'बाहर का खाना ज्यादा खाना',
      'पर्याप्त पानी न पी पाना',
    ],

    // Step 10: Optional Medical Report
    reportStepTitle: 'मेडिकल / ब्लड रिपोर्ट (वैकल्पिक)',
    reportStepSubtitle: 'अगर आपके पास कोई टेस्ट रिपोर्ट है तो अपलोड करें, या 1-क्लिक सैंपल देखें।',
    reportOptionalHint: 'यह स्टेप पूरी तरह वैकल्पिक (Optional) है। आप इसे कभी भी छोड़ सकते हैं।',
    trySampleTitle: '⚡ 1-क्लिक आसान सैंपल टेस्ट करें:',
    sampleLipid: 'सैंपल: हल्का कोलेस्ट्रॉल रिपोर्ट',
    sampleSugar: 'सैंपल: नॉर्मल ब्लड टेस्ट रिपोर्ट',
    uploadBoxTitle: 'रिपोर्ट फोटो या फाइल अपलोड करें',
    uploadBoxSubtitle: 'PDF, JPG या मोबाइल से फोटो',
    skipReportBtn: 'यह स्टेप छोड़ें (Skip) →',

    // Step 11: Account
    accountTitle: 'अपना AI हेल्थ प्लान सेव करें',
    accountSubtitle: 'मुफ्त अकाउंट बनाएं ताकि आपका डाइट डेटा सुरक्षित रहे।',
    fullName: 'आपका पूरा नाम',
    email: 'ईमेल आईडी',
    password: 'पासवर्ड',
    createAccountBtn: 'मेरा Cal AI प्लान बनाएं →',
    creatingBtn: 'प्लान तैयार हो रहा है...',

    // Step 12: Loading
    calculatingTitle: 'आपका प्लान तैयार किया जा रहा है...',
    calculatingBmr: 'मेटाबॉलिक रेट (BMR) की गणना हो रही है...',
    calculatingMacros: 'कैलोरी, प्रोटीन और फैट तय किए जा रहे हैं...',
    calculatingTimeline: 'टारगेट तारीख तय की जा रही है...',
    calculatingDone: 'प्लान पूरी तरह तैयार!',
  },
};
