import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, Users, Crown, ShoppingBag, Star, FileText, 
  DollarSign, CheckCircle2, AlertTriangle, Eye, Plus, Send, 
  QrCode, Edit, ArrowRight, Lock, LogOut, Sparkles, Filter, 
  Truck, Check, Stethoscope, Search, ExternalLink, RefreshCw, Upload
} from 'lucide-react';
import { 
  AdminStats, MedicalReportAnalysis, Order, Prescription, 
  UserReview, Product, Biomarker 
} from '../types';
import { 
  INITIAL_ADMIN_STATS, INITIAL_USER_REPORTS_FOR_ADMIN, 
  INITIAL_PRESCRIPTIONS, INITIAL_REVIEWS, INITIAL_ORDERS 
} from '../data/mockAdminData';
import { INITIAL_PRODUCTS } from '../data/products';

interface AdminDashboardProps {
  onExitAdmin: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onExitAdmin }) => {
  // Authentication State (Admin Only Barrier)
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  // Active Tab
  const [activeTab, setActiveTab] = useState<'overview' | 'reports' | 'orders' | 'products_qr' | 'reviews'>('overview');

  // Stats & Data
  const [stats, setStats] = useState<AdminStats>(INITIAL_ADMIN_STATS);
  const [reports, setReports] = useState<MedicalReportAnalysis[]>(INITIAL_USER_REPORTS_FOR_ADMIN);
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  const [prescriptions, setPrescriptions] = useState<Prescription[]>(INITIAL_PRESCRIPTIONS);
  const [reviews, setReviews] = useState<UserReview[]>(INITIAL_REVIEWS);
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);

  // QR Code Settings
  const [qrSettings, setQrSettings] = useState({
    qrImageUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=upi://pay?pa=calai.official@okhdfcbank&pn=CalAI%20Nutrition&mc=5411&cu=INR',
    upiId: 'calai.official@okhdfcbank',
    payeeName: 'Cal AI Health & Nutrition Inc.',
    merchantNote: 'Scan & Pay via any UPI App (GPay, PhonePe, Paytm)',
  });
  const [isUpdatingQr, setIsUpdatingQr] = useState(false);
  const [qrSuccessMessage, setQrSuccessMessage] = useState('');

  // Prescription modal state
  const [selectedReportForRx, setSelectedReportForRx] = useState<MedicalReportAnalysis | null>(null);
  const [rxDiagnosis, setRxDiagnosis] = useState('');
  const [rxMedicines, setRxMedicines] = useState<{ name: string; dosage: string; frequency: string; duration: string; notes: string }[]>([
    { name: '', dosage: '', frequency: '', duration: '', notes: '' }
  ]);
  const [rxSupplements, setRxSupplements] = useState<string>('Cal AI 100% Pure Whey Isolate, Triple Strength Omega-3');
  const [rxNotes, setRxNotes] = useState('');
  const [isSubmittingRx, setIsSubmittingRx] = useState(false);

  // AI Scanning state
  const [isAiScanningReport, setIsAiScanningReport] = useState<string | null>(null);

  // Load latest from backend if available
  useEffect(() => {
    fetch('/api/admin/stats')
      .then((res) => res.json())
      .then((data) => {
        if (data && data.totalUsers) setStats((prev) => ({ ...prev, ...data }));
      })
      .catch(() => {});

    fetch('/api/admin/orders')
      .then((res) => res.json())
      .then((data) => {
        if (data && data.orders && data.orders.length > 0) setOrders(data.orders);
      })
      .catch(() => {});

    fetch('/api/admin/qr-settings')
      .then((res) => res.json())
      .then((data) => {
        if (data && data.qrImageUrl) setQrSettings(data);
      })
      .catch(() => {});
  }, []);

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Strict admin credentials
    if ((adminEmail.trim().toLowerCase() === 'admin@cal.ai' && adminPassword === 'admin123') || adminPassword === '8899') {
      setIsAdminLoggedIn(true);
      setLoginError('');
    } else {
      setLoginError('Access restricted: Invalid admin credentials. Standard users cannot log in.');
    }
  };

  const handleStatusChange = async (orderId: string, newStatus: 'confirmed' | 'processing' | 'shipped' | 'delivered') => {
    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, orderStatus: newStatus } : o))
    );
    try {
      await fetch(`/api/admin/orders/${orderId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderStatus: newStatus }),
      });
    } catch (e) {}
  };

  const handleScanReportWithAi = async (reportId: string) => {
    setIsAiScanningReport(reportId);
    try {
      const report = reports.find((r) => r.id === reportId);
      const res = await fetch('/api/analyze-report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          reportText: report?.summary || 'Comprehensive blood and lipid panel',
          reportType: report?.reportName || 'Blood Test',
        }),
      });
      const data = await res.json();
      setReports((prev) =>
        prev.map((r) =>
          r.id === reportId
            ? {
                ...r,
                summary: data.summary || r.summary,
                biomarkers: data.biomarkers || r.biomarkers,
                identifiedRisks: data.identifiedRisks || r.identifiedRisks,
                dietaryRecommendations: data.dietaryRecommendations || r.dietaryRecommendations,
              }
            : r
        )
      );
    } catch (e) {
      console.error(e);
    } finally {
      setIsAiScanningReport(null);
    }
  };

  const handleOpenRxModal = (report: MedicalReportAnalysis) => {
    setSelectedReportForRx(report);
    setRxDiagnosis(report.identifiedRisks?.join(', ') || 'Metabolic Optimization & Nutrient Support');
    setRxMedicines([
      { name: 'Ferrous Ascorbate + Folic Acid', dosage: '100mg', frequency: 'Once daily after lunch', duration: '30 Days', notes: 'Take with lemon water for high absorption' },
      { name: 'Vitamin D3 Cholecalciferol', dosage: '60,000 IU', frequency: 'Once weekly for 8 weeks', duration: '8 Weeks', notes: 'Supports bone density and metabolism' },
    ]);
    setRxNotes('Patient advised to follow daily protein target and take omega-3 supplements.');
  };

  const handleAddMedicineRow = () => {
    setRxMedicines((prev) => [...prev, { name: '', dosage: '', frequency: '', duration: '', notes: '' }]);
  };

  const handleRemoveMedicineRow = (index: number) => {
    setRxMedicines((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmitPrescription = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedReportForRx) return;
    setIsSubmittingRx(true);
    try {
      const rxPayload = {
        userId: selectedReportForRx.userId,
        userName: selectedReportForRx.userName,
        reportId: selectedReportForRx.id,
        doctorName: 'Dr. Arjun Mehta, MD Clinical Nutrition',
        diagnosis: rxDiagnosis,
        medicines: rxMedicines.filter((m) => m.name.trim() !== ''),
        recommendedSupplements: rxSupplements.split(',').map((s) => s.trim()),
        dietaryAdjustments: selectedReportForRx.dietaryRecommendations || [],
        notes: rxNotes,
      };

      const res = await fetch('/api/admin/prescribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(rxPayload),
      });
      const data = await res.json();

      setPrescriptions((prev) => [data.prescription, ...prev]);
      setReports((prev) =>
        prev.map((r) => (r.id === selectedReportForRx.id ? { ...r, adminReviewed: true, adminNotes: rxNotes } : r))
      );

      setSelectedReportForRx(null);
    } catch (e) {
      console.error(e);
    } finally {
      setIsSubmittingRx(false);
    }
  };

  const handleSaveQrSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsUpdatingQr(true);
    try {
      await fetch('/api/admin/qr-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(qrSettings),
      });
      setQrSuccessMessage('Payment QR Code updated successfully!');
      setTimeout(() => setQrSuccessMessage(''), 3000);
    } catch (e) {
      console.error(e);
    } finally {
      setIsUpdatingQr(false);
    }
  };

  // 1. ADMIN LOGIN BARRIER
  if (!isAdminLoggedIn) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-zinc-950 border border-emerald-500/40 rounded-3xl p-8 shadow-2xl shadow-emerald-500/10">
          <div className="text-center mb-6">
            <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mx-auto mb-3">
              <Lock className="w-7 h-7" />
            </div>
            <h2 className="text-2xl font-black text-white">Cal AI Admin Portal</h2>
            <p className="text-xs text-zinc-400 mt-1">
              Restricted management portal for doctors, nutritionists & platform administrators.
            </p>
          </div>

          <form onSubmit={handleAdminLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1">Admin Email</label>
              <input
                type="email"
                required
                placeholder="admin@cal.ai"
                value={adminEmail}
                onChange={(e) => setAdminEmail(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-800 focus:border-emerald-500 focus:outline-none text-white text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1">Password or Admin PIN</label>
              <input
                type="password"
                required
                placeholder="Enter admin password / PIN"
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-800 focus:border-emerald-500 focus:outline-none text-white text-sm"
              />
              <div className="text-[10px] text-zinc-500 mt-1">Demo PIN: <strong>8899</strong> or admin@cal.ai / admin123</div>
            </div>

            {loginError && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{loginError}</span>
              </div>
            )}

            <button
              id="admin-login-btn"
              type="submit"
              className="w-full py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition-all active:scale-95"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Login to Admin Dashboard</span>
            </button>

            <button
              type="button"
              onClick={onExitAdmin}
              className="w-full py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-400 text-xs font-bold transition-colors"
            >
              Return to User App
            </button>
          </form>
        </div>
      </div>
    );
  }

  // 2. ADMIN DASHBOARD CONTENT
  return (
    <div id="cal-ai-admin-dashboard" className="min-h-screen bg-black text-white pb-16">
      
      {/* Top Navbar */}
      <header className="sticky top-0 z-30 bg-black/90 backdrop-blur-xl border-b border-zinc-800 px-4 sm:px-8 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-base font-black text-white">Cal AI Admin</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500 text-black">
                  SUPER ADMIN
                </span>
              </div>
              <p className="text-[10px] text-zinc-400">Dr. Arjun Mehta & Platform Operations</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsAdminLoggedIn(false)}
              className="px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-white text-xs font-bold flex items-center gap-1.5"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out</span>
            </button>

            <button
              type="button"
              onClick={onExitAdmin}
              className="px-3.5 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black text-xs font-bold transition-colors"
            >
              Back to User App
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-6 space-y-6">
        
        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 border-b border-zinc-800">
          <button
            type="button"
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
              activeTab === 'overview' ? 'bg-emerald-500 text-black shadow-md' : 'text-zinc-400 hover:text-white'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Platform Overview</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('reports')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
              activeTab === 'reports' ? 'bg-emerald-500 text-black shadow-md' : 'text-zinc-400 hover:text-white'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Medical Reports & AI Prescribe ({reports.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('orders')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
              activeTab === 'orders' ? 'bg-emerald-500 text-black shadow-md' : 'text-zinc-400 hover:text-white'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Customer Orders ({orders.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('products_qr')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
              activeTab === 'products_qr' ? 'bg-emerald-500 text-black shadow-md' : 'text-zinc-400 hover:text-white'
            }`}
          >
            <QrCode className="w-4 h-4" />
            <span>Payment QR & Products</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('reviews')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
              activeTab === 'reviews' ? 'bg-emerald-500 text-black shadow-md' : 'text-zinc-400 hover:text-white'
            }`}
          >
            <Star className="w-4 h-4" />
            <span>Reviews ({stats.totalReviews})</span>
          </button>
        </div>

        {/* TAB 1: OVERVIEW METRICS */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            
            {/* Stat Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              
              {/* Total Users */}
              <div className="p-5 rounded-2xl bg-zinc-900/70 border border-zinc-800 space-y-1">
                <div className="flex items-center justify-between text-zinc-400">
                  <span className="text-xs font-bold">Total Registered Users</span>
                  <Users className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="text-2xl font-black text-white">{stats.totalUsers.toLocaleString()}</div>
                <div className="text-[11px] text-emerald-400 flex items-center gap-1">
                  <span>+128 registered this week</span>
                </div>
              </div>

              {/* Pro Subscriptions vs Free */}
              <div className="p-5 rounded-2xl bg-zinc-900/70 border border-zinc-800 space-y-1">
                <div className="flex items-center justify-between text-zinc-400">
                  <span className="text-xs font-bold">Premium Pro Subscribers</span>
                  <Crown className="w-4 h-4 text-amber-400" />
                </div>
                <div className="text-2xl font-black text-amber-400">{stats.proUsers.toLocaleString()}</div>
                <div className="text-[11px] text-zinc-400">
                  {stats.freeUsers.toLocaleString()} Free Members ({( (stats.proUsers / stats.totalUsers) * 100 ).toFixed(1)}% Pro)
                </div>
              </div>

              {/* Product Buyers vs Non-Buyers */}
              <div className="p-5 rounded-2xl bg-zinc-900/70 border border-zinc-800 space-y-1">
                <div className="flex items-center justify-between text-zinc-400">
                  <span className="text-xs font-bold">Product Buyers</span>
                  <ShoppingBag className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="text-2xl font-black text-white">{stats.totalBuyers.toLocaleString()}</div>
                <div className="text-[11px] text-zinc-400">
                  {stats.nonBuyers.toLocaleString()} Non-buyers ({( (stats.totalBuyers / stats.totalUsers) * 100 ).toFixed(1)}% Conversion)
                </div>
              </div>

              {/* Total Revenue */}
              <div className="p-5 rounded-2xl bg-zinc-900/70 border border-zinc-800 space-y-1">
                <div className="flex items-center justify-between text-zinc-400">
                  <span className="text-xs font-bold">Gross Revenue</span>
                  <DollarSign className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="text-2xl font-black text-emerald-400">₹{(stats.totalRevenue / 100000).toFixed(2)} Lakhs</div>
                <div className="text-[11px] text-zinc-400">{stats.totalOrders} Completed Orders</div>
              </div>
            </div>

            {/* Visual Breakdown Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Subscription Breakdown */}
              <div className="p-6 rounded-3xl bg-zinc-950 border border-zinc-800 space-y-4">
                <h3 className="text-base font-black text-white">Subscription Status Breakdown</h3>
                
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between text-xs mb-1 font-bold">
                      <span className="text-amber-400">Pro Subscriptions (Paid)</span>
                      <span className="text-white">{stats.proUsers} users</span>
                    </div>
                    <div className="w-full h-3 rounded-full bg-zinc-800 overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-amber-500 to-emerald-500 rounded-full" 
                        style={{ width: `${(stats.proUsers / stats.totalUsers) * 100}%` }}
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs mb-1 font-bold">
                      <span className="text-zinc-400">Free Users (Unsubscribed)</span>
                      <span className="text-white">{stats.freeUsers} users</span>
                    </div>
                    <div className="w-full h-3 rounded-full bg-zinc-800 overflow-hidden">
                      <div 
                        className="h-full bg-zinc-600 rounded-full" 
                        style={{ width: `${(stats.freeUsers / stats.totalUsers) * 100}%` }}
                      />
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800/80 text-xs text-zinc-400 flex items-center justify-between">
                  <span>Pro users retain 4.8x longer and place 3x more supplement orders.</span>
                </div>
              </div>

              {/* E-commerce Buyer Conversion */}
              <div className="p-6 rounded-3xl bg-zinc-950 border border-zinc-800 space-y-4">
                <h3 className="text-base font-black text-white">Product Purchasing Metrics</h3>
                
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between text-xs mb-1 font-bold">
                      <span className="text-emerald-400">Purchased Products (Buyers)</span>
                      <span className="text-white">{stats.totalBuyers} users</span>
                    </div>
                    <div className="w-full h-3 rounded-full bg-zinc-800 overflow-hidden">
                      <div 
                        className="h-full bg-emerald-500 rounded-full" 
                        style={{ width: `${(stats.totalBuyers / stats.totalUsers) * 100}%` }}
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs mb-1 font-bold">
                      <span className="text-zinc-400">Browsed Only (Non-Buyers)</span>
                      <span className="text-white">{stats.nonBuyers} users</span>
                    </div>
                    <div className="w-full h-3 rounded-full bg-zinc-800 overflow-hidden">
                      <div 
                        className="h-full bg-zinc-600 rounded-full" 
                        style={{ width: `${(stats.nonBuyers / stats.totalUsers) * 100}%` }}
                      />
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800/80 text-xs text-zinc-400 flex items-center justify-between">
                  <span>Top product: Cal AI 100% Pure Whey Isolate (42% of all sales).</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: MEDICAL REPORTS & AI PRESCRIBE */}
        {activeTab === 'reports' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-black text-white">User Medical Reports & Doctor Prescriptions</h3>
                <p className="text-xs text-zinc-400">Review user uploaded blood/lipid lab tests, run AI scans, and prescribe medicines.</p>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {reports.map((report) => (
                <div 
                  key={report.id}
                  className="p-6 rounded-3xl bg-zinc-950 border border-zinc-800 space-y-4"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-zinc-800">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-base font-bold text-white">{report.userName}</span>
                        <span className="text-xs text-zinc-500 font-mono">({report.userId})</span>
                        {report.adminReviewed ? (
                          <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 text-[10px] font-bold">
                            Prescribed & Reviewed
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 text-[10px] font-bold">
                            Pending Doctor Review
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-zinc-400 mt-0.5">{report.reportName} • Uploaded {new Date(report.uploadedAt).toLocaleDateString('en-IN')}</p>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleScanReportWithAi(report.id!)}
                        disabled={isAiScanningReport === report.id}
                        className="px-3.5 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-emerald-400 text-xs font-bold flex items-center gap-1.5 transition-colors disabled:opacity-50"
                      >
                        {isAiScanningReport === report.id ? (
                          <div className="w-3.5 h-3.5 rounded-full border-2 border-emerald-400 border-t-transparent animate-spin" />
                        ) : (
                          <Sparkles className="w-3.5 h-3.5" />
                        )}
                        <span>Scan with Gemini AI</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleOpenRxModal(report)}
                        className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black text-xs font-extrabold flex items-center gap-1.5 shadow-md shadow-emerald-500/20"
                      >
                        <Stethoscope className="w-3.5 h-3.5" />
                        <span>Prescribe Medicines</span>
                      </button>
                    </div>
                  </div>

                  {/* Summary & Biomarkers */}
                  <div className="space-y-3">
                    <p className="text-xs text-zinc-300 leading-relaxed bg-zinc-900/50 p-3 rounded-xl border border-zinc-800/80">
                      <strong>Clinical Summary:</strong> {report.summary}
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
                      {report.biomarkers.map((b, i) => (
                        <div key={i} className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 text-xs">
                          <div className="flex justify-between items-center mb-1">
                            <span className="font-bold text-white line-clamp-1">{b.name}</span>
                            <span className={`text-[10px] font-black uppercase px-1.5 py-0.5 rounded ${
                              b.status === 'high' ? 'bg-rose-500/20 text-rose-400' : b.status === 'low' ? 'bg-amber-500/20 text-amber-300' : 'bg-emerald-500/20 text-emerald-400'
                            }`}>
                              {b.status}
                            </span>
                          </div>
                          <div className="text-sm font-black text-white">{b.value}</div>
                          <div className="text-[10px] text-zinc-500 mt-0.5">{b.impactOnDiet}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: CUSTOMER ORDERS */}
        {activeTab === 'orders' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-black text-white">Store Orders Management</h3>
                <p className="text-xs text-zinc-400">View customer purchases, payment verification, and update shipping statuses.</p>
              </div>
            </div>

            <div className="space-y-3">
              {orders.map((order) => (
                <div 
                  key={order.id}
                  className="p-5 rounded-2xl bg-zinc-950 border border-zinc-800 hover:border-zinc-700 transition-all space-y-3"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <span className="text-xs font-mono font-bold text-emerald-400">{order.id}</span>
                      <span className="text-sm font-bold text-white ml-2">{order.shippingAddress?.fullName}</span>
                      <span className="text-xs text-zinc-500 ml-2">({order.shippingAddress?.phone})</span>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="text-xs font-bold text-white">₹{order.total}</span>
                      <span className="text-[11px] px-2 py-0.5 rounded-full bg-zinc-800 text-zinc-300 capitalize">
                        {order.paymentMethod === 'qr_upi' ? 'UPI QR' : 'Razorpay'}
                      </span>

                      {/* Status Selector */}
                      <select
                        value={order.orderStatus}
                        onChange={(e) => handleStatusChange(order.id, e.target.value as any)}
                        className="px-3 py-1 rounded-lg bg-zinc-900 border border-zinc-700 text-xs font-bold text-emerald-400 focus:outline-none"
                      >
                        <option value="confirmed">Confirmed</option>
                        <option value="processing">Processing</option>
                        <option value="shipped">Shipped (In Transit)</option>
                        <option value="delivered">Delivered</option>
                      </select>
                    </div>
                  </div>

                  {/* Items */}
                  <div className="text-xs text-zinc-400 space-y-1">
                    {order.items.map((item, idx) => (
                      <div key={idx} className="flex justify-between">
                        <span>{item.quantity}x {item.product?.name}</span>
                        <span className="text-zinc-300 font-semibold">₹{(item.product?.discountPrice || item.product?.price || 0) * item.quantity}</span>
                      </div>
                    ))}
                  </div>

                  {/* Address */}
                  <div className="text-[11px] text-zinc-500 pt-2 border-t border-zinc-800/60">
                    Ship to: {order.shippingAddress?.streetAddress}, {order.shippingAddress?.city} - {order.shippingAddress?.pincode}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: PAYMENT QR & PRODUCTS SETTINGS */}
        {activeTab === 'products_qr' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* QR Code Config */}
            <div className="p-6 rounded-3xl bg-zinc-950 border border-zinc-800 space-y-4">
              <div className="flex items-center gap-2">
                <QrCode className="w-5 h-5 text-emerald-400" />
                <h3 className="text-base font-black text-white">Payment QR Code Settings</h3>
              </div>
              <p className="text-xs text-zinc-400">
                Upload or change the UPI QR code image and Merchant Details that users see during checkout.
              </p>

              <form onSubmit={handleSaveQrSettings} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1">QR Code Image URL</label>
                  <input
                    type="url"
                    required
                    value={qrSettings.qrImageUrl}
                    onChange={(e) => setQrSettings({ ...qrSettings, qrImageUrl: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-white text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1">UPI ID (VPA)</label>
                  <input
                    type="text"
                    required
                    value={qrSettings.upiId}
                    onChange={(e) => setQrSettings({ ...qrSettings, upiId: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-white text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1">Payee Name</label>
                  <input
                    type="text"
                    required
                    value={qrSettings.payeeName}
                    onChange={(e) => setQrSettings({ ...qrSettings, payeeName: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-white text-xs"
                  />
                </div>

                {qrSuccessMessage && (
                  <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-1.5">
                    <Check className="w-4 h-4" />
                    <span>{qrSuccessMessage}</span>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isUpdatingQr}
                  className="w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs shadow-lg shadow-emerald-500/20"
                >
                  Save QR Settings
                </button>
              </form>
            </div>

            {/* QR Live Preview */}
            <div className="p-6 rounded-3xl bg-zinc-950 border border-zinc-800 flex flex-col items-center justify-center text-center">
              <h4 className="text-xs font-bold text-zinc-400 uppercase tracking-wide mb-3">Live User QR Preview</h4>
              <div className="p-4 rounded-2xl bg-white shadow-xl">
                <img
                  src={qrSettings.qrImageUrl}
                  alt="QR Preview"
                  className="w-48 h-48 object-contain"
                />
              </div>
              <div className="mt-3 text-xs text-zinc-300 font-mono font-bold">{qrSettings.upiId}</div>
              <p className="text-[11px] text-zinc-500 mt-0.5">{qrSettings.payeeName}</p>
            </div>
          </div>
        )}

        {/* TAB 5: REVIEWS */}
        {activeTab === 'reviews' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-black text-white">Customer Reviews & Testimonials ({reviews.length})</h3>
                <p className="text-xs text-zinc-400">Real feedback from verified purchasers & report-analyzed members.</p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {reviews.map((rev) => (
                <div key={rev.id} className="p-5 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white text-sm">{rev.userName}</span>
                    <div className="flex items-center gap-1 text-amber-400">
                      {[...Array(rev.rating)].map((_, i) => (
                        <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
                      ))}
                    </div>
                  </div>
                  <p className="text-xs text-zinc-300 leading-relaxed italic">"{rev.comment}"</p>
                  <div className="text-[10px] text-emerald-400 font-medium pt-2 border-t border-zinc-800/80">
                    Product: {rev.productName} • {rev.date}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* DOCTOR PRESCRIPTION MODAL */}
      {selectedReportForRx && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-zinc-950 border border-emerald-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl my-8">
            <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <Stethoscope className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-white">Issue Clinical Prescription</h3>
                  <p className="text-xs text-zinc-400">Patient: <strong className="text-white">{selectedReportForRx.userName}</strong> ({selectedReportForRx.reportName})</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedReportForRx(null)}
                className="p-2 rounded-full bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitPrescription} className="space-y-4 py-4">
              <div>
                <label className="block text-xs font-bold text-zinc-300 mb-1">Diagnosis</label>
                <input
                  type="text"
                  required
                  value={rxDiagnosis}
                  onChange={(e) => setRxDiagnosis(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-white text-xs"
                />
              </div>

              {/* Medicine rows */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-zinc-300">Prescribed Medicines & Dosages</label>
                  <button
                    type="button"
                    onClick={handleAddMedicineRow}
                    className="text-xs text-emerald-400 font-bold hover:underline flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Medicine</span>
                  </button>
                </div>

                {rxMedicines.map((med, idx) => (
                  <div key={idx} className="p-3 rounded-2xl bg-zinc-900/70 border border-zinc-800 space-y-2">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      <input
                        type="text"
                        placeholder="Medicine name"
                        value={med.name}
                        onChange={(e) => {
                          const updated = [...rxMedicines];
                          updated[idx].name = e.target.value;
                          setRxMedicines(updated);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-zinc-950 border border-zinc-800 text-white text-xs"
                      />
                      <input
                        type="text"
                        placeholder="Dosage (e.g. 100mg)"
                        value={med.dosage}
                        onChange={(e) => {
                          const updated = [...rxMedicines];
                          updated[idx].dosage = e.target.value;
                          setRxMedicines(updated);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-zinc-950 border border-zinc-800 text-white text-xs"
                      />
                      <input
                        type="text"
                        placeholder="Frequency (e.g. 1-0-1)"
                        value={med.frequency}
                        onChange={(e) => {
                          const updated = [...rxMedicines];
                          updated[idx].frequency = e.target.value;
                          setRxMedicines(updated);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-zinc-950 border border-zinc-800 text-white text-xs"
                      />
                      <div className="flex items-center gap-1">
                        <input
                          type="text"
                          placeholder="Duration (e.g. 30 days)"
                          value={med.duration}
                          onChange={(e) => {
                            const updated = [...rxMedicines];
                            updated[idx].duration = e.target.value;
                            setRxMedicines(updated);
                          }}
                          className="w-full px-3 py-1.5 rounded-lg bg-zinc-950 border border-zinc-800 text-white text-xs"
                        />
                        {rxMedicines.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleRemoveMedicineRow(idx)}
                            className="p-1.5 rounded-lg text-rose-400 hover:bg-rose-500/20"
                          >
                            ✕
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-300 mb-1">Recommended Supplements & Store Products</label>
                <input
                  type="text"
                  value={rxSupplements}
                  onChange={(e) => setRxSupplements(e.target.value)}
                  placeholder="e.g. Cal AI Pure Whey Isolate, Triple Strength Omega-3"
                  className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-white text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-300 mb-1">Doctor's Clinical Notes</label>
                <textarea
                  rows={3}
                  value={rxNotes}
                  onChange={(e) => setRxNotes(e.target.value)}
                  placeholder="Additional lifestyle, hydration and test follow-up notes..."
                  className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-white text-xs resize-none"
                />
              </div>

              <div className="pt-3 border-t border-zinc-800 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setSelectedReportForRx(null)}
                  className="px-5 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-400 text-xs font-bold"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={isSubmittingRx}
                  className="px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs flex items-center gap-1.5 shadow-lg shadow-emerald-500/20"
                >
                  <Send className="w-4 h-4" />
                  <span>{isSubmittingRx ? 'Issuing...' : 'Issue & Attach to Patient Profile'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
