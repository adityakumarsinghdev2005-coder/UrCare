import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import { Sparkles, Trophy, ArrowRight, Flame, HeartPulse, Droplets, Target, ShieldCheck, Zap, Award } from 'lucide-react';
import { UserHealthProfile } from '../types';

interface WowCelebrationProps {
  profile: UserHealthProfile;
  onEnterDashboard: () => void;
}

export const WowCelebration: React.FC<WowCelebrationProps> = ({ profile, onEnterDashboard }) => {
  const [animatedScore, setAnimatedScore] = useState(0);
  const [animatedCals, setAnimatedCals] = useState(0);

  const { calculatedPlan, goal, currentWeightKg, targetWeightKg, reportAnalysis } = profile;

  useEffect(() => {
    // 1. Trigger celebratory confetti bursts in emerald, lime, gold, and white
    const duration = 3.5 * 1000;
    const end = Date.now() + duration;

    const frame = () => {
      confetti({
        particleCount: 4,
        angle: 60,
        spread: 55,
        origin: { x: 0, y: 0.7 },
        colors: ['#00E054', '#22C55E', '#10B981', '#FFFFFF', '#FACC15'],
      });
      confetti({
        particleCount: 4,
        angle: 120,
        spread: 55,
        origin: { x: 1, y: 0.7 },
        colors: ['#00E054', '#22C55E', '#10B981', '#FFFFFF', '#FACC15'],
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    };
    frame();

    // 2. Count up numbers smoothly
    const targetScore = calculatedPlan.healthScore || 94;
    const targetCals = calculatedPlan.targetCalories || 1850;

    let scoreInterval = setInterval(() => {
      setAnimatedScore((prev) => {
        if (prev >= targetScore) {
          clearInterval(scoreInterval);
          return targetScore;
        }
        return prev + 2;
      });
    }, 25);

    let calsInterval = setInterval(() => {
      setAnimatedCals((prev) => {
        if (prev >= targetCals) {
          clearInterval(calsInterval);
          return targetCals;
        }
        return prev + Math.ceil(targetCals / 40);
      });
    }, 20);

    return () => {
      clearInterval(scoreInterval);
      clearInterval(calsInterval);
    };
  }, [calculatedPlan]);

  const weightDelta = Math.abs(currentWeightKg - targetWeightKg);

  return (
    <div id="wow-celebration-screen" className="relative min-h-[90vh] flex flex-col items-center justify-center py-8 px-4 text-center overflow-hidden">
      {/* Background ambient glowing spheres */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-emerald-500/15 rounded-full blur-3xl pointer-events-none -z-10 animate-pulse" />
      <div className="absolute bottom-10 right-10 w-72 h-72 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="w-full max-w-2xl mx-auto space-y-7 z-10 animate-in fade-in zoom-in-95 duration-700">
        
        {/* Top WOW badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-emerald-500/20 via-emerald-400/30 to-emerald-500/20 border border-emerald-400/50 shadow-lg shadow-emerald-500/20 text-emerald-300 text-xs sm:text-sm font-black tracking-wider uppercase">
          <Sparkles className="w-4 h-4 text-emerald-400 animate-spin" />
          <span>✨ WOW! YOUR CAL AI BLUEPRINT IS UNLOCKED</span>
          <Sparkles className="w-4 h-4 text-emerald-400 animate-spin" />
        </div>

        {/* Main Headline */}
        <div className="space-y-2">
          <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight leading-tight">
            You're Ready To <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-emerald-300 to-green-400">Transform</span>
          </h1>
          <p className="text-zinc-400 text-sm sm:text-base max-w-lg mx-auto">
            We've calibrated your personalized metabolic blueprint based on your biometrics, daily habits{reportAnalysis ? ', and medical lab biomarkers' : ''}.
          </p>
        </div>

        {/* Main Radiant Calorie & Health Card */}
        <div className="relative p-6 sm:p-8 rounded-3xl bg-zinc-900/90 border border-emerald-500/50 shadow-2xl shadow-emerald-950 backdrop-blur-xl space-y-6">
          
          {/* Top Row: Daily Calorie Target + Health Readiness Score */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
            
            {/* Calorie Glow Box */}
            <div className="p-5 rounded-2xl bg-gradient-to-b from-emerald-950/60 to-black/80 border border-emerald-500/40 text-center relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-2 text-emerald-500/20">
                <Flame className="w-16 h-16" />
              </div>
              <span className="text-[11px] font-bold uppercase tracking-widest text-emerald-400 flex items-center justify-center gap-1.5 mb-1">
                <Flame className="w-3.5 h-3.5 text-emerald-400" />
                <span>Daily Calorie Target</span>
              </span>
              <div className="text-4xl sm:text-5xl font-black text-white tracking-tight flex items-baseline justify-center gap-1">
                <span>{animatedCals}</span>
                <span className="text-emerald-400 text-base font-semibold">kcal/day</span>
              </div>
              <p className="text-[11px] text-zinc-400 mt-1">
                {calculatedPlan.calorieDeficitOrSurplus < 0 
                  ? `${Math.abs(calculatedPlan.calorieDeficitOrSurplus)} kcal fat-burning deficit`
                  : calculatedPlan.calorieDeficitOrSurplus > 0
                  ? `${calculatedPlan.calorieDeficitOrSurplus} kcal lean muscle surplus`
                  : 'Balanced maintenance target'}
              </p>
            </div>

            {/* Health Score Gauge */}
            <div className="p-5 rounded-2xl bg-gradient-to-b from-zinc-950/80 to-black/80 border border-zinc-800 text-center relative">
              <span className="text-[11px] font-bold uppercase tracking-widest text-emerald-400 flex items-center justify-center gap-1.5 mb-1">
                <Award className="w-3.5 h-3.5 text-emerald-400" />
                <span>Cal AI Health Score</span>
              </span>
              <div className="text-4xl sm:text-5xl font-black text-white tracking-tight flex items-baseline justify-center gap-1">
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-300 to-green-400">{animatedScore}</span>
                <span className="text-zinc-500 text-base font-semibold">/ 100</span>
              </div>
              <p className="text-[11px] text-zinc-400 mt-1 flex items-center justify-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>High Metabolic Efficiency</span>
              </p>
            </div>
          </div>

          {/* 4 Glowing Macro Targets */}
          <div className="space-y-2 text-left">
            <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400">
              Your Daily Macronutrient Split
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              
              {/* Protein */}
              <div className="p-3.5 rounded-xl bg-zinc-950 border border-emerald-500/30">
                <span className="text-[10px] uppercase font-bold text-emerald-400 block">Protein</span>
                <span className="text-xl font-bold text-white">{calculatedPlan.proteinGrams}g</span>
                <span className="text-[10px] text-zinc-400 block mt-0.5">Muscle & Satiety</span>
              </div>

              {/* Carbs */}
              <div className="p-3.5 rounded-xl bg-zinc-950 border border-blue-500/30">
                <span className="text-[10px] uppercase font-bold text-blue-400 block">Carbs</span>
                <span className="text-xl font-bold text-white">{calculatedPlan.carbsGrams}g</span>
                <span className="text-[10px] text-zinc-400 block mt-0.5">Daily Energy</span>
              </div>

              {/* Fats */}
              <div className="p-3.5 rounded-xl bg-zinc-950 border border-amber-500/30">
                <span className="text-[10px] uppercase font-bold text-amber-400 block">Healthy Fats</span>
                <span className="text-xl font-bold text-white">{calculatedPlan.fatsGrams}g</span>
                <span className="text-[10px] text-zinc-400 block mt-0.5">Hormonal Balance</span>
              </div>

              {/* Hydration */}
              <div className="p-3.5 rounded-xl bg-zinc-950 border border-cyan-500/30">
                <span className="text-[10px] uppercase font-bold text-cyan-400 block">Water</span>
                <span className="text-xl font-bold text-white">{calculatedPlan.waterLiters}L</span>
                <span className="text-[10px] text-zinc-400 block mt-0.5">Hydration Goal</span>
              </div>
            </div>
          </div>

          {/* Goal Timeline Box */}
          <div className="p-4 rounded-2xl bg-emerald-950/30 border border-emerald-500/30 flex items-center justify-between flex-wrap gap-3 text-left">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center flex-shrink-0">
                <Target className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs text-zinc-400 block">Target Weight Milestone:</span>
                <span className="text-sm sm:text-base font-bold text-white">
                  Reach {targetWeightKg} kg by <span className="text-emerald-400 font-extrabold">{calculatedPlan.targetDate}</span>
                </span>
              </div>
            </div>
            <span className="text-xs px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 font-semibold border border-emerald-500/30">
              {calculatedPlan.weeklyChangeKg < 0 ? `-${Math.abs(calculatedPlan.weeklyChangeKg)} kg / week` : `+${calculatedPlan.weeklyChangeKg} kg / week`}
            </span>
          </div>

          {/* If Medical Report was processed */}
          {reportAnalysis && (
            <div className="p-3.5 rounded-xl bg-zinc-950/80 border border-emerald-500/30 text-left flex items-start gap-3 text-xs">
              <HeartPulse className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-white block">Medical Report Calibrated:</span>
                <span className="text-zinc-400">
                  {reportAnalysis.reportName} — Biomarkers integrated into your daily macro and micronutrient targets.
                </span>
              </div>
            </div>
          )}

          {/* Primary Big WOW CTA Button */}
          <button
            id="enter-dashboard-btn"
            type="button"
            onClick={onEnterDashboard}
            className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 via-emerald-400 to-green-500 hover:from-emerald-400 hover:to-green-400 text-black font-extrabold text-base sm:text-lg flex items-center justify-center gap-3 transition-all shadow-xl shadow-emerald-500/30 hover:scale-[1.02] active:scale-[0.99] group"
          >
            <span>Open My Cal AI Dashboard</span>
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Bottom Social Proof & Guarantee */}
        <p className="text-xs text-zinc-500 flex items-center justify-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-500" />
          <span>Backed by peer-reviewed Mifflin-St Jeor metabolic science and clinical AI.</span>
        </p>

      </div>
    </div>
  );
};
