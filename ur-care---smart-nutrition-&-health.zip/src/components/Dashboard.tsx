import React, { useState, useEffect } from 'react';
import { 
  Flame, Plus, Camera, HeartPulse, Droplets, Trophy, Settings, Target, 
  ChevronRight, Sparkles, Trash2, Calendar, ShieldCheck, Activity, Award, 
  Scale, RefreshCw, ShoppingBag, Lightbulb, Crown, Lock, Stethoscope, 
  Package, User, Languages
} from 'lucide-react';
import { UserHealthProfile, MealItem, UserAccount, MedicalReportAnalysis, Order, Prescription } from '../types';
import { FoodScannerModal } from './FoodScannerModal';
import { HealthReportModal } from './HealthReportModal';
import { SettingsModal } from './SettingsModal';
import { ProductsModule } from './ProductsModule';
import { RecommendationsView } from './RecommendationsView';
import { ProUpgradeModal } from './ProUpgradeModal';
import { MyOrdersModal } from './MyOrdersModal';
import { INITIAL_ORDERS, INITIAL_PRESCRIPTIONS } from '../data/mockAdminData';

interface DashboardProps {
  profile: UserHealthProfile;
  account: UserAccount;
  onUpdateProfile: (updated: UserHealthProfile) => void;
  onResetOnboarding: () => void;
  onOpenAdminPortal?: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  profile,
  account,
  onUpdateProfile,
  onResetOnboarding,
  onOpenAdminPortal,
}) => {
  // Navigation Tabs: 'diary' | 'recommendations' | 'store' | 'reports'
  const [activeTab, setActiveTab] = useState<'diary' | 'recommendations' | 'store' | 'reports'>('diary');

  // Meals state with realistic initial starter meal
  const [meals, setMeals] = useState<MealItem[]>([
    {
      id: 'meal_init_1',
      name: 'Oatmeal with Blueberries & Whey Protein',
      calories: 380,
      protein: 30,
      carbs: 48,
      fats: 6,
      fiber: 7,
      category: 'breakfast',
      timestamp: '08:30 AM',
      servingSize: '1 bowl',
    },
  ]);

  // Water intake state
  const [waterMl, setWaterMl] = useState<number>(1250);

  // Orders State
  const [userOrders, setUserOrders] = useState<Order[]>(INITIAL_ORDERS);
  const [isMyOrdersOpen, setIsMyOrdersOpen] = useState(false);

  // Prescriptions State
  const [prescriptions, setPrescriptions] = useState<Prescription[]>(INITIAL_PRESCRIPTIONS);

  // Modals
  const [isFoodScannerOpen, setIsFoodScannerOpen] = useState(false);
  const [foodScannerCategory, setFoodScannerCategory] = useState<'breakfast' | 'lunch' | 'dinner' | 'snack'>('lunch');
  const [isHealthReportOpen, setIsHealthReportOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isProUpgradeOpen, setIsProUpgradeOpen] = useState(false);
  const [proTriggerFeature, setProTriggerFeature] = useState('AI Food Camera Scanner');

  // Fetch user orders & prescriptions on mount
  useEffect(() => {
    fetch(`/api/orders/my?userId=${account.uid}`)
      .then((res) => res.json())
      .then((data) => {
        if (data && data.orders && data.orders.length > 0) {
          setUserOrders(data.orders);
        }
      })
      .catch(() => {});

    fetch(`/api/user/prescriptions?userId=${account.uid}`)
      .then((res) => res.json())
      .then((data) => {
        if (data && data.prescriptions && data.prescriptions.length > 0) {
          setPrescriptions(data.prescriptions);
        }
      })
      .catch(() => {});
  }, [account.uid]);

  // Target metrics from calculated plan
  const { calculatedPlan, targetWeightKg, currentWeightKg, reportAnalysis } = profile;
  const targetCalories = calculatedPlan.targetCalories || 1850;
  const targetProtein = calculatedPlan.proteinGrams || 140;
  const targetCarbs = calculatedPlan.carbsGrams || 175;
  const targetFats = calculatedPlan.fatsGrams || 55;
  const targetWaterMl = (calculatedPlan.waterLiters || 3.0) * 1000;

  // Aggregate totals
  const totalCaloriesConsumed = meals.reduce((acc, m) => acc + m.calories, 0);
  const totalProteinConsumed = meals.reduce((acc, m) => acc + m.protein, 0);
  const totalCarbsConsumed = meals.reduce((acc, m) => acc + m.carbs, 0);
  const totalFatsConsumed = meals.reduce((acc, m) => acc + m.fats, 0);
  const totalFiberConsumed = meals.reduce((acc, m) => acc + (m.fiber || 0), 0);

  const remainingCalories = Math.max(0, targetCalories - totalCaloriesConsumed);
  const caloriePercent = Math.min(100, Math.round((totalCaloriesConsumed / targetCalories) * 100));

  const handleAddMeal = (meal: MealItem) => {
    setMeals((prev) => [meal, ...prev]);
  };

  const handleDeleteMeal = (id: string) => {
    setMeals((prev) => prev.filter((m) => m.id !== id));
  };

  const handleAddWater = (amountMl: number) => {
    setWaterMl((prev) => Math.min(5000, prev + amountMl));
  };

  const handleUpdateReport = (newAnalysis: MedicalReportAnalysis) => {
    const updated = {
      ...profile,
      reportAnalysis: newAnalysis,
      updatedAt: new Date().toISOString(),
    };
    onUpdateProfile(updated);
  };

  const handleUpdateWeight = (newWeight: number) => {
    const updated = {
      ...profile,
      currentWeightKg: newWeight,
      updatedAt: new Date().toISOString(),
    };
    onUpdateProfile(updated);
  };

  const handleOrderPlaced = (newOrder: Order) => {
    setUserOrders((prev) => [newOrder, ...prev]);
  };

  const handleOpenProModalFor = (featureName: string) => {
    setProTriggerFeature(featureName);
    setIsProUpgradeOpen(true);
  };

  // Group meals by category
  const mealCategories: Array<{ id: 'breakfast' | 'lunch' | 'dinner' | 'snack'; label: string; icon: string }> = [
    { id: 'breakfast', label: 'Breakfast', icon: '🍳' },
    { id: 'lunch', label: 'Lunch', icon: '🥗' },
    { id: 'dinner', label: 'Dinner', icon: '🍲' },
    { id: 'snack', label: 'Snacks & Bites', icon: '🥑' },
  ];

  return (
    <div id="cal-ai-dashboard" className="min-h-screen bg-black text-white pb-24">
      
      {/* TOP HEADER */}
      <header className="sticky top-0 z-30 bg-black/85 backdrop-blur-xl border-b border-zinc-800/80 px-4 sm:px-6 py-3">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          
          {/* Logo & Brand */}
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 via-emerald-500 to-green-400 p-0.5 shadow-lg shadow-emerald-500/20">
              <div className="w-full h-full bg-black rounded-[10px] flex items-center justify-center">
                <Flame className="w-5 h-5 text-emerald-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-base font-black text-white tracking-tight">Cal AI</span>
                {account.isPro ? (
                  <span className="text-[10px] font-black px-1.5 py-0.5 rounded bg-emerald-500 text-black shadow-sm shadow-emerald-500/20">
                    PRO
                  </span>
                ) : (
                  <button
                    type="button"
                    onClick={() => handleOpenProModalFor('Cal AI Pro')}
                    className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30 transition-colors"
                  >
                    GO PRO ⚡
                  </button>
                )}
              </div>
              <p className="text-[10px] text-zinc-400">Hi, {profile.name.split(' ')[0]}</p>
            </div>
          </div>

          {/* Center Navigation Tabs (Desktop & Tablet) */}
          <div className="hidden md:flex items-center gap-1 p-1 bg-zinc-900/90 border border-zinc-800 rounded-2xl">
            <button
              id="nav-tab-diary"
              type="button"
              onClick={() => setActiveTab('diary')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'diary' ? 'bg-emerald-500 text-black shadow-md' : 'text-zinc-400 hover:text-white'
              }`}
            >
              📊 Diary
            </button>
            <button
              id="nav-tab-recommendations"
              type="button"
              onClick={() => setActiveTab('recommendations')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'recommendations' ? 'bg-emerald-500 text-black shadow-md' : 'text-zinc-400 hover:text-white'
              }`}
            >
              💡 Recommendations
            </button>
            <button
              id="nav-tab-store"
              type="button"
              onClick={() => setActiveTab('store')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'store' ? 'bg-emerald-500 text-black shadow-md' : 'text-zinc-400 hover:text-white'
              }`}
            >
              🛍️ Store
            </button>
            <button
              id="nav-tab-reports"
              type="button"
              onClick={() => setActiveTab('reports')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'reports' ? 'bg-emerald-500 text-black shadow-md' : 'text-zinc-400 hover:text-white'
              }`}
            >
              🩺 Medical Hub
            </button>
          </div>

          {/* Right Action Icons */}
          <div className="flex items-center gap-2">
            {/* My Orders Button */}
            <button
              id="header-my-orders-btn"
              type="button"
              onClick={() => setIsMyOrdersOpen(true)}
              className="p-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white text-xs font-bold flex items-center gap-1.5 transition-colors"
              title="My Orders"
            >
              <Package className="w-4 h-4 text-emerald-400" />
              <span className="hidden lg:inline">Orders</span>
            </button>

            {/* Admin Portal Button */}
            {onOpenAdminPortal && (
              <button
                id="header-admin-btn"
                type="button"
                onClick={onOpenAdminPortal}
                className="p-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-emerald-400 transition-colors"
                title="Admin Portal (Restricted)"
              >
                <ShieldCheck className="w-4 h-4" />
              </button>
            )}

            {/* Settings */}
            <button
              id="dash-settings-btn"
              type="button"
              onClick={() => setIsSettingsOpen(true)}
              className="p-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-white transition-colors"
              title="Settings"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* MOBILE BOTTOM NAVIGATION BAR */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-zinc-950/95 backdrop-blur-xl border-t border-zinc-800 px-2 py-2 flex items-center justify-around">
        <button
          type="button"
          onClick={() => setActiveTab('diary')}
          className={`flex flex-col items-center gap-1 py-1 px-2 rounded-xl text-[10px] font-bold ${
            activeTab === 'diary' ? 'text-emerald-400' : 'text-zinc-500'
          }`}
        >
          <Flame className="w-4 h-4" />
          <span>Diary</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('recommendations')}
          className={`flex flex-col items-center gap-1 py-1 px-2 rounded-xl text-[10px] font-bold ${
            activeTab === 'recommendations' ? 'text-emerald-400' : 'text-zinc-500'
          }`}
        >
          <Lightbulb className="w-4 h-4" />
          <span>Advice</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setFoodScannerCategory('lunch');
            setIsFoodScannerOpen(true);
          }}
          className="flex flex-col items-center -mt-5 bg-emerald-500 text-black p-3 rounded-full shadow-lg shadow-emerald-500/30"
        >
          <Camera className="w-5 h-5" />
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('store')}
          className={`flex flex-col items-center gap-1 py-1 px-2 rounded-xl text-[10px] font-bold ${
            activeTab === 'store' ? 'text-emerald-400' : 'text-zinc-500'
          }`}
        >
          <ShoppingBag className="w-4 h-4" />
          <span>Store</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('reports')}
          className={`flex flex-col items-center gap-1 py-1 px-2 rounded-xl text-[10px] font-bold ${
            activeTab === 'reports' ? 'text-emerald-400' : 'text-zinc-500'
          }`}
        >
          <HeartPulse className="w-4 h-4" />
          <span>Medical</span>
        </button>
      </div>

      {/* MAIN CONTAINER */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 pt-6 space-y-6">
        
        {/* PRO UPGRADE PROMOTIONAL CALLOUT (If not pro) */}
        {!account.isPro && (
          <div className="p-4 rounded-3xl bg-gradient-to-r from-amber-950/40 via-zinc-950 to-emerald-950/40 border border-amber-500/30 flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                <Crown className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="text-sm font-bold text-white">Unlock Cal AI Pro with AI Food Vision</h4>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold">
                    Special Offer
                  </span>
                </div>
                <p className="text-xs text-zinc-400 mt-0.5">
                  Scan meals with AI Camera, get clinical doctor prescriptions on lab reports, and save 60%.
                </p>
              </div>
            </div>
            <button
              id="upgrade-pro-banner-btn"
              type="button"
              onClick={() => handleOpenProModalFor('AI Food Vision & Doctor Guidance')}
              className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-extrabold text-xs flex items-center gap-1.5 shadow-md shadow-amber-500/20 transition-all active:scale-95"
            >
              <span>Upgrade to Pro (₹208/mo)</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* TAB 1: NUTRITION DIARY & CALORIE TRACKER */}
        {activeTab === 'diary' && (
          <div className="space-y-6">
            
            {/* Quick Action Button for Food Scanner */}
            <div className="flex items-center justify-between p-4 rounded-2xl bg-zinc-900/60 border border-zinc-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <Camera className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold text-white">Log Meals with Cal AI Vision</h3>
                    {!account.isPro && (
                      <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30">
                        PRO
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-zinc-400">Snap a meal photo or type to auto-calculate calories & macros</p>
                </div>
              </div>

              <button
                id="open-food-scanner-btn"
                type="button"
                onClick={() => {
                  setFoodScannerCategory('lunch');
                  setIsFoodScannerOpen(true);
                }}
                className="px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-500/20 transition-all active:scale-95"
              >
                <Camera className="w-4 h-4" />
                <span>Scan Food</span>
              </button>
            </div>

            {/* CALORIE & MACRO SUMMARY CARD */}
            <div className="p-6 rounded-3xl bg-zinc-950 border border-zinc-800 space-y-6">
              
              {/* Top Row: Calories Rings & Breakdown */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
                
                {/* Left: Calorie Goal & Consumed */}
                <div className="space-y-2">
                  <div className="text-xs text-zinc-400 font-bold uppercase tracking-wider">Calories Left</div>
                  <div className="text-4xl font-black text-white tracking-tight">
                    {remainingCalories} <span className="text-sm font-normal text-zinc-400">kcal</span>
                  </div>
                  <div className="text-xs text-zinc-400">
                    Consumed: <strong className="text-emerald-400">{totalCaloriesConsumed}</strong> / {targetCalories} kcal
                  </div>
                </div>

                {/* Center: Circular Progress bar representation */}
                <div className="flex flex-col items-center justify-center">
                  <div className="relative w-32 h-32 flex items-center justify-center">
                    <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                      <path
                        className="text-zinc-800"
                        strokeWidth="3.5"
                        stroke="currentColor"
                        fill="none"
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      />
                      <path
                        className="text-emerald-500"
                        strokeDasharray={`${caloriePercent}, 100`}
                        strokeWidth="3.5"
                        strokeLinecap="round"
                        stroke="currentColor"
                        fill="none"
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      />
                    </svg>
                    <div className="absolute flex flex-col items-center">
                      <span className="text-xl font-black text-white">{caloriePercent}%</span>
                      <span className="text-[10px] text-zinc-400">of daily goal</span>
                    </div>
                  </div>
                </div>

                {/* Right: Target & Goal info */}
                <div className="space-y-2 text-xs">
                  <div className="p-3 rounded-2xl bg-zinc-900/80 border border-zinc-800 space-y-1">
                    <div className="flex justify-between">
                      <span className="text-zinc-400">Target Weight:</span>
                      <span className="font-bold text-white">{targetWeightKg} kg</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-zinc-400">Current Weight:</span>
                      <span className="font-bold text-emerald-400">{currentWeightKg} kg</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-zinc-400">Target Date:</span>
                      <span className="font-bold text-zinc-300">{calculatedPlan.targetDate}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Bottom Row: Macronutrient Progress Bars */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-zinc-800/80">
                
                {/* Protein */}
                <div className="p-3.5 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-2">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-emerald-400">Protein</span>
                    <span className="text-white">{totalProteinConsumed} / {targetProtein}g</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-zinc-800 overflow-hidden">
                    <div 
                      className="h-full bg-emerald-500 rounded-full" 
                      style={{ width: `${Math.min(100, (totalProteinConsumed / targetProtein) * 100)}%` }}
                    />
                  </div>
                  <div className="text-[10px] text-zinc-400">
                    {Math.max(0, targetProtein - totalProteinConsumed)}g left to reach target
                  </div>
                </div>

                {/* Carbs */}
                <div className="p-3.5 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-2">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-blue-400">Carbs</span>
                    <span className="text-white">{totalCarbsConsumed} / {targetCarbs}g</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-zinc-800 overflow-hidden">
                    <div 
                      className="h-full bg-blue-500 rounded-full" 
                      style={{ width: `${Math.min(100, (totalCarbsConsumed / targetCarbs) * 100)}%` }}
                    />
                  </div>
                  <div className="text-[10px] text-zinc-400">
                    {Math.max(0, targetCarbs - totalCarbsConsumed)}g left to reach target
                  </div>
                </div>

                {/* Fats */}
                <div className="p-3.5 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-2">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-amber-400">Fats</span>
                    <span className="text-white">{totalFatsConsumed} / {targetFats}g</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-zinc-800 overflow-hidden">
                    <div 
                      className="h-full bg-amber-500 rounded-full" 
                      style={{ width: `${Math.min(100, (totalFatsConsumed / targetFats) * 100)}%` }}
                    />
                  </div>
                  <div className="text-[10px] text-zinc-400">
                    {Math.max(0, targetFats - totalFatsConsumed)}g left to reach target
                  </div>
                </div>
              </div>
            </div>

            {/* WATER TRACKER */}
            <div className="p-5 rounded-3xl bg-zinc-950 border border-zinc-800 flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-blue-500/20 text-blue-400 flex items-center justify-center">
                  <Droplets className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-white">Daily Hydration</div>
                  <div className="text-lg font-black text-blue-400">
                    {waterMl} <span className="text-xs font-normal text-zinc-400">/ {targetWaterMl} ml</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleAddWater(250)}
                  className="px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs font-bold text-white"
                >
                  +250ml (1 Glass)
                </button>
                <button
                  type="button"
                  onClick={() => handleAddWater(500)}
                  className="px-3 py-1.5 rounded-xl bg-blue-500 hover:bg-blue-400 text-black text-xs font-bold"
                >
                  +500ml (1 Bottle)
                </button>
              </div>
            </div>

            {/* MEALS LOGGED BY CATEGORY */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-black text-white">Today's Meals</h3>
                <span className="text-xs text-zinc-400">{meals.length} item(s) logged</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {mealCategories.map((cat) => {
                  const catMeals = meals.filter((m) => m.category === cat.id);
                  const catCals = catMeals.reduce((acc, m) => acc + m.calories, 0);

                  return (
                    <div key={cat.id} className="p-5 rounded-3xl bg-zinc-950 border border-zinc-800/90 space-y-3">
                      <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
                        <div className="flex items-center gap-2">
                          <span className="text-lg">{cat.icon}</span>
                          <span className="text-sm font-bold text-white">{cat.label}</span>
                          <span className="text-xs text-emerald-400 font-mono font-bold">({catCals} kcal)</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setFoodScannerCategory(cat.id);
                            setIsFoodScannerOpen(true);
                          }}
                          className="p-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-emerald-400 transition-colors"
                          title="Log Food"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>

                      {catMeals.length === 0 ? (
                        <div className="text-xs text-zinc-600 py-3 text-center italic">
                          No food logged for {cat.label.toLowerCase()} yet.
                        </div>
                      ) : (
                        <div className="space-y-2">
                          {catMeals.map((meal) => (
                            <div
                              key={meal.id}
                              className="p-3 rounded-2xl bg-zinc-900/60 border border-zinc-800/80 flex items-center justify-between gap-3 text-xs"
                            >
                              <div className="min-w-0 flex-1">
                                <div className="font-bold text-white truncate">{meal.name}</div>
                                <div className="text-[11px] text-zinc-400 mt-0.5">
                                  P: <strong className="text-emerald-400">{meal.protein}g</strong> • C: {meal.carbs}g • F: {meal.fats}g
                                </div>
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="font-black text-white text-sm">{meal.calories} kcal</span>
                                <button
                                  type="button"
                                  onClick={() => handleDeleteMeal(meal.id)}
                                  className="p-1 rounded text-zinc-500 hover:text-rose-400 transition-colors"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: AI RECOMMENDATIONS (What to eat, what to avoid, risks, preventions) */}
        {activeTab === 'recommendations' && (
          <RecommendationsView
            profile={profile}
            prescriptions={prescriptions}
            onOpenStore={() => setActiveTab('store')}
            onOpenReportHub={() => setIsHealthReportOpen(true)}
          />
        )}

        {/* TAB 3: PRODUCTS & SUPPLEMENTS STORE */}
        {activeTab === 'store' && (
          <ProductsModule
            account={account}
            onOrderPlaced={handleOrderPlaced}
            onOpenMyOrders={() => setIsMyOrdersOpen(true)}
          />
        )}

        {/* TAB 4: MEDICAL REPORT & CLINICAL HUB */}
        {activeTab === 'reports' && (
          <div className="space-y-6">
            <div className="p-6 rounded-3xl bg-zinc-950 border border-zinc-800 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h3 className="text-xl font-black text-white">Medical Laboratory Reports Hub</h3>
                  <p className="text-xs text-zinc-400 mt-1">Upload blood, lipid, thyroid or HbA1c panels to calibrate AI nutrition.</p>
                </div>
                <button
                  type="button"
                  onClick={() => setIsHealthReportOpen(true)}
                  className="px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-500/20"
                >
                  <HeartPulse className="w-4 h-4" />
                  <span>Upload / Scan Lab Report</span>
                </button>
              </div>

              {/* If analysis exists */}
              {reportAnalysis ? (
                <div className="p-5 rounded-2xl bg-zinc-900/60 border border-emerald-500/30 space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
                    <div>
                      <div className="text-base font-bold text-white">{reportAnalysis.reportName}</div>
                      <div className="text-xs text-zinc-400">Uploaded {new Date(reportAnalysis.uploadedAt).toLocaleDateString('en-IN')}</div>
                    </div>
                    <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 text-xs font-bold">
                      Report Analyzed
                    </span>
                  </div>

                  <p className="text-xs text-zinc-300 leading-relaxed bg-zinc-950 p-3 rounded-xl">
                    {reportAnalysis.summary}
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
                    {reportAnalysis.biomarkers?.map((b, i) => (
                      <div key={i} className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 text-xs">
                        <div className="flex justify-between items-center mb-1">
                          <span className="font-bold text-white">{b.name}</span>
                          <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded capitalize ${
                            b.status === 'high' ? 'bg-rose-500/20 text-rose-400' : b.status === 'low' ? 'bg-amber-500/20 text-amber-300' : 'bg-emerald-500/20 text-emerald-400'
                          }`}>
                            {b.status}
                          </span>
                        </div>
                        <div className="text-sm font-black text-white">{b.value}</div>
                        <div className="text-[10px] text-zinc-500 mt-0.5">{b.impactOnDiet}</div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center py-12 text-zinc-500">
                  <HeartPulse className="w-12 h-12 mx-auto mb-2 text-zinc-600" />
                  <p className="text-sm font-bold text-white">No Medical Reports Uploaded Yet</p>
                  <p className="text-xs text-zinc-400 mt-1 max-w-sm mx-auto">
                    Uploading a report is optional, but gives you precision dietary prescriptions for cholesterol, thyroid, and vitamin D.
                  </p>
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* MODALS */}
      {/* 1. Food Scanner Modal */}
      <FoodScannerModal
        isOpen={isFoodScannerOpen}
        onClose={() => setIsFoodScannerOpen(false)}
        onAddMeal={handleAddMeal}
        defaultCategory={foodScannerCategory}
        isPro={!!account.isPro}
        onOpenProUpgrade={() => handleOpenProModalFor('AI Food Camera Scanner')}
      />

      {/* 2. Health Report Modal */}
      <HealthReportModal
        isOpen={isHealthReportOpen}
        onClose={() => setIsHealthReportOpen(false)}
        currentAnalysis={reportAnalysis}
        onSaveAnalysis={handleUpdateReport}
      />

      {/* 3. Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        profile={profile}
        account={account}
        onUpdateWeight={handleUpdateWeight}
        onResetOnboarding={onResetOnboarding}
      />

      {/* 4. Pro Upgrade Modal */}
      <ProUpgradeModal
        isOpen={isProUpgradeOpen}
        onClose={() => setIsProUpgradeOpen(false)}
        account={account}
        featureTriggerName={proTriggerFeature}
        onUpgradeSuccess={(updatedAccount) => {
          // Update profile / account state
          try {
            localStorage.setItem('calai_user_account', JSON.stringify(updatedAccount));
          } catch (e) {}
        }}
      />

      {/* 5. My Orders Tracking Modal */}
      <MyOrdersModal
        isOpen={isMyOrdersOpen}
        onClose={() => setIsMyOrdersOpen(false)}
        orders={userOrders}
        onOpenStore={() => setActiveTab('store')}
      />
    </div>
  );
};
