import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowRight, ArrowLeft, Check, Sparkles, Flame, Target, User, HeartPulse, 
  Activity, ShieldCheck, Dumbbell, Apple, Clock, Scale, Zap, Lock, Globe,
  CheckCircle2, ChevronRight, Layers, Sparkle
} from 'lucide-react';
import { 
  GoalType, GenderType, ActivityLevel, GoalPace, 
  UserHealthProfile, MedicalReportAnalysis, UserAccount 
} from '../types';
import { calculateNutritionPlan } from '../utils/calculator';
import { ReportUploader } from './ReportUploader';
import { Language, translations } from '../utils/translations';

interface OnboardingFlowProps {
  onComplete: (profile: UserHealthProfile, account: UserAccount) => void;
  onOpenAdmin?: () => void;
}

export const OnboardingFlow: React.FC<OnboardingFlowProps> = ({ onComplete, onOpenAdmin }) => {
  const [lang, setLang] = useState<Language>('en');
  const t = translations[lang];

  // Steps: 0 to 12
  // 0: Intro Hero
  // 1: Goal
  // 2: Body Focus Area
  // 3: Gender
  // 4: Age
  // 5: Height & Weight (BMI)
  // 6: Target Goal Weight & Pace
  // 7: Daily Activity Level
  // 8: Diet Preference
  // 9: Obstacles / Challenges
  // 10: Medical / Blood Report (OPTIONAL)
  // 11: Account / Sign Up
  // 12: AI Plan Calculation Animation
  const [currentStep, setCurrentStep] = useState(0);

  // Form States
  const [goal, setGoal] = useState<GoalType>('lose_weight');
  const [focusArea, setFocusArea] = useState<string>('belly');
  const [gender, setGender] = useState<GenderType>('male');
  const [age, setAge] = useState<number>(26);
  const [unitSystem, setUnitSystem] = useState<'metric' | 'imperial'>('metric');
  const [heightCm, setHeightCm] = useState<number>(175);
  const [currentWeightKg, setCurrentWeightKg] = useState<number>(78);
  const [targetWeightKg, setTargetWeightKg] = useState<number>(68);
  const [pace, setPace] = useState<GoalPace>('steady');
  const [activity, setActivity] = useState<ActivityLevel>('moderately_active');
  const [dietaryPreference, setDietaryPreference] = useState<string>('Anything / Balanced');
  const [selectedObstacles, setSelectedObstacles] = useState<string[]>([
    'Late-night snacking',
    'Sugar & sweet cravings',
  ]);
  const [reportAnalysis, setReportAnalysis] = useState<MedicalReportAnalysis | undefined>(undefined);

  // Auth / Registration state
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [isSubmittingAuth, setIsSubmittingAuth] = useState(false);

  // Calculation Progress states
  const [calcProgress, setCalcProgress] = useState(0);
  const [calcStatus, setCalcStatus] = useState(t.calculatingBmr);

  const TOTAL_STEPS = 12;

  const nextStep = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setCurrentStep((prev) => Math.min(prev + 1, TOTAL_STEPS));
  };

  const prevStep = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setCurrentStep((prev) => Math.max(prev - 1, 0));
  };

  const toggleObstacle = (item: string) => {
    setSelectedObstacles((prev) =>
      prev.includes(item) ? prev.filter((i) => i !== item) : [...prev, item]
    );
  };

  const startCalculationSequence = async (registeredAccount: UserAccount) => {
    setCurrentStep(12);
    setCalcProgress(20);
    setCalcStatus(t.calculatingBmr);

    setTimeout(() => {
      setCalcProgress(55);
      setCalcStatus(t.calculatingMacros);
    }, 700);

    setTimeout(() => {
      setCalcProgress(85);
      setCalcStatus(t.calculatingTimeline);
    }, 1500);

    setTimeout(() => {
      setCalcProgress(100);
      setCalcStatus(t.calculatingDone);

      const finalPlan = calculateNutritionPlan(
        gender,
        age,
        heightCm,
        currentWeightKg,
        targetWeightKg,
        goal,
        activity,
        pace,
        reportAnalysis
      );

      const profile: UserHealthProfile = {
        name: name.trim() || (lang === 'hi' ? 'कैलोरी मेंबर' : 'Cal AI Member'),
        email: email.trim() || 'user@cal.ai',
        gender,
        age,
        heightCm,
        currentWeightKg,
        targetWeightKg,
        goal,
        activityLevel: activity,
        pace,
        obstacles: selectedObstacles,
        dietaryPreference,
        medicalConditions: reportAnalysis?.identifiedRisks || [],
        reportAnalysis,
        calculatedPlan: finalPlan,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      // Background persistence sync
      fetch('/api/sync-supabase', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: registeredAccount.uid, profile }),
      }).catch((e) => console.warn('Sync note:', e));

      onComplete(profile, registeredAccount);
    }, 2400);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setAuthError(lang === 'hi' ? 'कृपया ईमेल और पासवर्ड दोनों दर्ज करें।' : 'Please enter both email and password.');
      return;
    }
    setAuthError(null);
    setIsSubmittingAuth(true);

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          password,
          displayName: name || email.split('@')[0],
        }),
      });
      const data = await res.json();

      const account: UserAccount = {
        uid: data.user?.uid || 'usr_' + Date.now(),
        email: email,
        displayName: name || email.split('@')[0],
        authProvider: 'firebase',
        supabaseSynced: true,
        lastSyncedAt: new Date().toISOString(),
      };

      startCalculationSequence(account);
    } catch (err) {
      const account: UserAccount = {
        uid: 'usr_local_' + Date.now(),
        email: email,
        displayName: name || (lang === 'hi' ? 'Cal AI यूजर' : 'Cal AI User'),
        authProvider: 'firebase',
        supabaseSynced: true,
        lastSyncedAt: new Date().toISOString(),
      };
      startCalculationSequence(account);
    } finally {
      setIsSubmittingAuth(false);
    }
  };

  // BMI calculations
  const bmi = Number((currentWeightKg / Math.pow(heightCm / 100, 2)).toFixed(1));
  const getBmiCategory = (val: number) => {
    if (val < 18.5) return { label: lang === 'hi' ? 'कम वजन (Underweight)' : 'Underweight', color: 'text-blue-400' };
    if (val < 25) return { label: lang === 'hi' ? 'सामान्य व स्वस्थ (Healthy)' : 'Healthy / Normal', color: 'text-emerald-400' };
    if (val < 30) return { label: lang === 'hi' ? 'थोड़ा अधिक (Overweight)' : 'Overweight', color: 'text-amber-400' };
    return { label: lang === 'hi' ? 'मोटापा (Obese)' : 'Obese', color: 'text-rose-400' };
  };
  const bmiInfo = getBmiCategory(bmi);

  return (
    <div id="cal-ai-onboarding" className="min-h-screen bg-black text-white flex flex-col justify-between py-5 px-4 sm:px-6 relative overflow-x-hidden">
      
      {/* Top Header & Language Toggle */}
      <header className="w-full max-w-xl mx-auto flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-500 to-green-400 flex items-center justify-center p-0.5 shadow-md shadow-emerald-500/20">
            <div className="w-full h-full bg-black rounded-[10px] flex items-center justify-center">
              <Flame className="w-4 h-4 text-emerald-400" />
            </div>
          </div>
          <span className="text-xs font-black tracking-wider text-white">
            {t.appTag}
          </span>
        </div>

        {/* Language Switcher & Admin Portal */}
        <div className="flex items-center gap-2">
          {onOpenAdmin && (
            <button
              type="button"
              onClick={onOpenAdmin}
              className="p-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-emerald-400 text-xs font-bold flex items-center gap-1 transition-colors"
              title="Admin Portal"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span className="hidden sm:inline text-[11px]">Admin</span>
            </button>
          )}

          <div className="flex items-center gap-1 bg-zinc-900 border border-zinc-800 rounded-full p-1 text-xs">
            <button
              type="button"
              onClick={() => setLang('en')}
              className={`px-2.5 py-1 rounded-full font-bold transition-all ${lang === 'en' ? 'bg-emerald-500 text-black shadow-sm' : 'text-zinc-400 hover:text-white'}`}
            >
              EN
            </button>
            <button
              type="button"
              onClick={() => setLang('hi')}
              className={`px-2.5 py-1 rounded-full font-bold transition-all ${lang === 'hi' ? 'bg-emerald-500 text-black shadow-sm' : 'text-zinc-400 hover:text-white'}`}
            >
              हिंदी
            </button>
          </div>
        </div>
      </header>

      {/* Progress Bar (Visible from Step 1 to 11) */}
      {currentStep > 0 && currentStep < 12 && (
        <div className="w-full max-w-xl mx-auto mb-6 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <button
              id="onboarding-back-btn"
              type="button"
              onClick={prevStep}
              className="px-2.5 py-1 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white flex items-center gap-1 transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>{t.back}</span>
            </button>

            <span className="text-zinc-500 font-semibold">
              {t.stepOf} <strong className="text-emerald-400">{currentStep}</strong> {t.of} 11
            </span>

            {/* If on Step 10 (Medical report), show top quick skip */}
            {currentStep === 10 ? (
              <button
                type="button"
                onClick={nextStep}
                className="text-xs text-emerald-400 hover:text-emerald-300 font-bold underline"
              >
                {t.skip}
              </button>
            ) : (
              <div className="w-12" />
            )}
          </div>

          <div className="w-full h-1.5 bg-zinc-900 rounded-full overflow-hidden border border-zinc-800/80">
            <motion.div
              className="h-full bg-gradient-to-r from-emerald-500 to-green-400 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${(currentStep / 11) * 100}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>
        </div>
      )}

      {/* STEP CONTAINER WITH MOTION ANIMATION */}
      <main className="w-full max-w-xl mx-auto my-auto py-2">
        <AnimatePresence mode="wait">

          {/* STEP 0: HERO INTRO */}
          {currentStep === 0 && (
            <motion.div
              key="step-0"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="text-center space-y-7 py-4"
            >
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs font-bold shadow-md shadow-emerald-500/10">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>{t.heroBadge}</span>
              </div>

              <div className="space-y-3">
                <h1 className="text-4xl sm:text-5xl font-black text-white tracking-tight leading-tight">
                  {t.heroTitle1} <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-emerald-300 to-green-400">{t.heroTitle2}</span>
                </h1>
                <p className="text-zinc-400 text-sm sm:text-base max-w-md mx-auto leading-relaxed">
                  {t.heroSubtitle}
                </p>
              </div>

              {/* 3 Quick Visual Benefit Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-left">
                <div className="p-4 rounded-2xl bg-zinc-900/80 border border-zinc-800 hover:border-emerald-500/40 transition-all">
                  <Flame className="w-5 h-5 text-emerald-400 mb-2" />
                  <h4 className="text-xs font-bold text-white">Smart Calories</h4>
                  <p className="text-[11px] text-zinc-400 mt-0.5">Accurate BMR & Deficit</p>
                </div>
                <div className="p-4 rounded-2xl bg-zinc-900/80 border border-zinc-800 hover:border-emerald-500/40 transition-all">
                  <Apple className="w-5 h-5 text-emerald-400 mb-2" />
                  <h4 className="text-xs font-bold text-white">AI Food Scan</h4>
                  <p className="text-[11px] text-zinc-400 mt-0.5">Instant photo tracking</p>
                </div>
                <div className="p-4 rounded-2xl bg-zinc-900/80 border border-zinc-800 hover:border-emerald-500/40 transition-all">
                  <HeartPulse className="w-5 h-5 text-emerald-400 mb-2" />
                  <h4 className="text-xs font-bold text-white">Lab Reports</h4>
                  <p className="text-[11px] text-zinc-400 mt-0.5">Optional medical synergy</p>
                </div>
              </div>

              {/* Social Proof */}
              <div className="flex items-center justify-center gap-3 py-2 border-y border-zinc-900">
                <div className="flex -space-x-2">
                  {[
                    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=60',
                    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=60',
                    'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&auto=format&fit=crop&q=60',
                  ].map((src, i) => (
                    <img key={i} src={src} alt="User avatar" className="w-8 h-8 rounded-full border-2 border-black object-cover" />
                  ))}
                </div>
                <p className="text-xs text-zinc-400 font-medium">
                  <span className="text-white font-bold">{t.heroStat}</span>
                </p>
              </div>

              {/* Start Button */}
              <motion.button
                id="start-onboarding-btn"
                type="button"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={nextStep}
                className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 via-emerald-400 to-green-500 hover:from-emerald-400 hover:to-green-400 text-black font-extrabold text-base flex items-center justify-center gap-2 shadow-xl shadow-emerald-500/25 transition-all"
              >
                <span>{t.heroStartBtn}</span>
              </motion.button>
            </motion.div>
          )}

          {/* STEP 1: PRIMARY GOAL */}
          {currentStep === 1 && (
            <motion.div
              key="step-1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-5"
            >
              <div className="text-center space-y-1.5">
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white">{t.goalTitle}</h2>
                <p className="text-zinc-400 text-xs sm:text-sm">{t.goalSubtitle}</p>
              </div>

              <div className="space-y-3">
                {[
                  { id: 'lose_weight', item: t.goals.lose_weight, icon: Flame },
                  { id: 'build_muscle', item: t.goals.build_muscle, icon: Dumbbell },
                  { id: 'maintain_tone', item: t.goals.maintain_tone, icon: Scale },
                  { id: 'improve_health', item: t.goals.improve_health, icon: Zap },
                ].map(({ id, item, icon: IconComp }) => {
                  const isSelected = goal === id;
                  return (
                    <motion.button
                      key={id}
                      id={`goal-${id}`}
                      type="button"
                      whileTap={{ scale: 0.98 }}
                      onClick={() => {
                        setGoal(id as GoalType);
                        setTimeout(nextStep, 250);
                      }}
                      className={`w-full p-4 rounded-2xl border text-left flex items-center justify-between transition-all ${
                        isSelected
                          ? 'bg-emerald-950/60 border-emerald-500 text-white shadow-lg shadow-emerald-950/60 ring-2 ring-emerald-500/30'
                          : 'bg-zinc-900/80 border-zinc-800 hover:border-emerald-500/40 text-zinc-300'
                      }`}
                    >
                      <div className="flex items-center gap-3.5">
                        <div className={`w-11 h-11 rounded-xl flex items-center justify-center transition-colors ${isSelected ? 'bg-emerald-500 text-black shadow-md' : 'bg-zinc-800 text-zinc-400'}`}>
                          <IconComp className="w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="text-sm font-bold text-white">{item.title}</h4>
                          <p className="text-xs text-zinc-400 mt-0.5">{item.desc}</p>
                        </div>
                      </div>
                      <div className={`w-6 h-6 rounded-full border flex items-center justify-center transition-all ${isSelected ? 'bg-emerald-500 border-emerald-500 text-black scale-110' : 'border-zinc-700'}`}>
                        {isSelected && <Check className="w-4 h-4 stroke-[3]" />}
                      </div>
                    </motion.button>
                  );
                })}
              </div>
            </motion.div>
          )}

          {/* STEP 2: BODY FOCUS AREA */}
          {currentStep === 2 && (
            <motion.div
              key="step-2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-5"
            >
              <div className="text-center space-y-1.5">
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white">{t.focusTitle}</h2>
                <p className="text-zinc-400 text-xs sm:text-sm">{t.focusSubtitle}</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {[
                  { id: 'belly', item: t.focusAreas.belly, icon: '🔥' },
                  { id: 'upper', item: t.focusAreas.upper, icon: '💪' },
                  { id: 'lower', item: t.focusAreas.lower, icon: '🏃' },
                  { id: 'full', item: t.focusAreas.full, icon: '✨' },
                ].map(({ id, item, icon }) => {
                  const isSelected = focusArea === id;
                  return (
                    <motion.button
                      key={id}
                      id={`focus-${id}`}
                      type="button"
                      whileTap={{ scale: 0.98 }}
                      onClick={() => {
                        setFocusArea(id);
                        setTimeout(nextStep, 250);
                      }}
                      className={`p-5 rounded-2xl border text-left flex flex-col justify-between gap-3 transition-all ${
                        isSelected
                          ? 'bg-emerald-950/60 border-emerald-500 shadow-lg shadow-emerald-950/60 ring-2 ring-emerald-500/30'
                          : 'bg-zinc-900/80 border-zinc-800 hover:border-emerald-500/40 text-zinc-300'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-2xl">{icon}</span>
                        <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${isSelected ? 'bg-emerald-500 border-emerald-500 text-black' : 'border-zinc-700'}`}>
                          {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                        </div>
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-white">{item.title}</h4>
                        <p className="text-xs text-zinc-400 mt-1">{item.desc}</p>
                      </div>
                    </motion.button>
                  );
                })}
              </div>
            </motion.div>
          )}

          {/* STEP 3: BIOLOGICAL SEX */}
          {currentStep === 3 && (
            <motion.div
              key="step-3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="text-center space-y-1.5">
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white">{t.genderTitle}</h2>
                <p className="text-zinc-400 text-xs sm:text-sm">{t.genderSubtitle}</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {[
                  { id: 'male', item: t.genders.male, emoji: '👨' },
                  { id: 'female', item: t.genders.female, emoji: '👩' },
                ].map(({ id, item, emoji }) => {
                  const isSelected = gender === id;
                  return (
                    <motion.button
                      key={id}
                      id={`gender-${id}`}
                      type="button"
                      whileTap={{ scale: 0.98 }}
                      onClick={() => {
                        setGender(id as GenderType);
                        setTimeout(nextStep, 250);
                      }}
                      className={`p-7 rounded-3xl border text-center flex flex-col items-center justify-center gap-3 transition-all ${
                        isSelected
                          ? 'bg-emerald-950/60 border-emerald-500 shadow-xl shadow-emerald-950 ring-2 ring-emerald-500/30'
                          : 'bg-zinc-900/80 border-zinc-800 hover:border-zinc-700'
                      }`}
                    >
                      <span className="text-4xl">{emoji}</span>
                      <div>
                        <h4 className="text-base font-bold text-white">{item.title}</h4>
                        <p className="text-xs text-zinc-400 mt-0.5">{item.desc}</p>
                      </div>
                    </motion.button>
                  );
                })}
              </div>
            </motion.div>
          )}

          {/* STEP 4: AGE */}
          {currentStep === 4 && (
            <motion.div
              key="step-4"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="text-center space-y-1.5">
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white">{t.ageTitle}</h2>
                <p className="text-zinc-400 text-xs sm:text-sm">{t.ageSubtitle}</p>
              </div>

              <div className="p-8 rounded-3xl bg-zinc-900/90 border border-zinc-800 text-center space-y-6">
                <div className="text-6xl font-black text-white tracking-tight flex items-baseline justify-center gap-2">
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-400">
                    {age}
                  </span>
                  <span className="text-zinc-500 text-xl font-semibold">{t.years}</span>
                </div>

                <input
                  id="age-slider"
                  type="range"
                  min={16}
                  max={80}
                  value={age}
                  onChange={(e) => setAge(Number(e.target.value))}
                  className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                />

                <div className="flex justify-between text-xs text-zinc-500">
                  <span>18</span>
                  <span>35</span>
                  <span>50</span>
                  <span>75+</span>
                </div>
              </div>

              <button
                id="age-continue-btn"
                type="button"
                onClick={nextStep}
                className="w-full py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-sm transition-all shadow-lg shadow-emerald-500/20"
              >
                {t.continue}
              </button>
            </motion.div>
          )}

          {/* STEP 5: HEIGHT & WEIGHT */}
          {currentStep === 5 && (
            <motion.div
              key="step-5"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-5"
            >
              <div className="text-center space-y-1.5">
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white">{t.hwTitle}</h2>
                <p className="text-zinc-400 text-xs sm:text-sm">{t.hwSubtitle}</p>
              </div>

              {/* Unit Toggle */}
              <div className="flex justify-center">
                <div className="p-1 bg-zinc-900 rounded-xl border border-zinc-800 flex gap-1 text-xs font-semibold">
                  <button
                    type="button"
                    onClick={() => setUnitSystem('metric')}
                    className={`px-4 py-1.5 rounded-lg transition-all ${unitSystem === 'metric' ? 'bg-emerald-500 text-black font-bold' : 'text-zinc-400'}`}
                  >
                    Metric (kg / cm)
                  </button>
                  <button
                    type="button"
                    onClick={() => setUnitSystem('imperial')}
                    className={`px-4 py-1.5 rounded-lg transition-all ${unitSystem === 'imperial' ? 'bg-emerald-500 text-black font-bold' : 'text-zinc-400'}`}
                  >
                    Imperial (lbs / ft)
                  </button>
                </div>
              </div>

              {/* Height */}
              <div className="p-5 rounded-2xl bg-zinc-900/90 border border-zinc-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-zinc-400">{t.height}</span>
                  <span className="text-xl font-bold text-emerald-400">
                    {unitSystem === 'metric' ? `${heightCm} cm` : `${Math.floor(heightCm / 30.48)}' ${Math.round((heightCm % 30.48) / 2.54)}"`}
                  </span>
                </div>
                <input
                  id="height-slider"
                  type="range"
                  min={130}
                  max={220}
                  value={heightCm}
                  onChange={(e) => setHeightCm(Number(e.target.value))}
                  className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                />
              </div>

              {/* Weight */}
              <div className="p-5 rounded-2xl bg-zinc-900/90 border border-zinc-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-zinc-400">{t.weight}</span>
                  <span className="text-xl font-bold text-emerald-400">
                    {unitSystem === 'metric' ? `${currentWeightKg} kg` : `${Math.round(currentWeightKg * 2.20462)} lbs`}
                  </span>
                </div>
                <input
                  id="weight-slider"
                  type="range"
                  min={40}
                  max={160}
                  value={currentWeightKg}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    setCurrentWeightKg(val);
                    if (goal === 'lose_weight' && targetWeightKg >= val) {
                      setTargetWeightKg(Math.max(40, val - 8));
                    }
                  }}
                  className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                />
              </div>

              {/* BMI Indicator */}
              <div className="p-3.5 rounded-2xl bg-emerald-950/30 border border-emerald-500/30 flex items-center justify-between text-xs">
                <span className="text-zinc-300">{t.bmiLabel}:</span>
                <span className="font-bold text-white">
                  BMI {bmi} (<strong className={bmiInfo.color}>{bmiInfo.label}</strong>)
                </span>
              </div>

              <button
                id="hw-continue-btn"
                type="button"
                onClick={nextStep}
                className="w-full py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-sm transition-all shadow-lg shadow-emerald-500/20"
              >
                {t.continue}
              </button>
            </motion.div>
          )}

          {/* STEP 6: TARGET WEIGHT & PACE */}
          {currentStep === 6 && (
            <motion.div
              key="step-6"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-5"
            >
              <div className="text-center space-y-1.5">
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white">{t.targetTitle}</h2>
                <p className="text-zinc-400 text-xs sm:text-sm">{t.targetSubtitle}</p>
              </div>

              <div className="p-6 rounded-3xl bg-zinc-900/90 border border-zinc-800 text-center space-y-4">
                <span className="text-xs font-bold uppercase tracking-widest text-emerald-400">{t.targetLabel}</span>
                <div className="text-5xl font-black text-white tracking-tight flex items-baseline justify-center gap-1">
                  <span>{unitSystem === 'metric' ? targetWeightKg : Math.round(targetWeightKg * 2.20462)}</span>
                  <span className="text-emerald-400 text-lg font-semibold">{unitSystem === 'metric' ? 'kg' : 'lbs'}</span>
                </div>

                <input
                  id="target-weight-slider"
                  type="range"
                  min={40}
                  max={140}
                  value={targetWeightKg}
                  onChange={(e) => setTargetWeightKg(Number(e.target.value))}
                  className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                />

                <p className="text-xs text-zinc-400">
                  {lang === 'hi' ? 'कुल बदलाव:' : 'Total change:'}{' '}
                  <span className="text-emerald-400 font-bold">
                    {targetWeightKg - currentWeightKg > 0 ? `+${(targetWeightKg - currentWeightKg).toFixed(1)} kg` : `${(targetWeightKg - currentWeightKg).toFixed(1)} kg`}
                  </span>
                </p>
              </div>

              {/* Pace Selector */}
              <div className="space-y-2">
                <span className="text-xs font-bold uppercase tracking-wider text-zinc-400 block">
                  {t.paceTitle}
                </span>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'slow', item: t.paces.slow },
                    { id: 'steady', item: t.paces.steady },
                    { id: 'moderate', item: t.paces.moderate },
                  ].map(({ id, item }) => {
                    const isSelected = pace === id;
                    return (
                      <button
                        key={id}
                        type="button"
                        onClick={() => setPace(id as GoalPace)}
                        className={`p-3 rounded-2xl border text-center transition-all ${
                          isSelected
                            ? 'bg-emerald-950/70 border-emerald-500 text-white shadow-md'
                            : 'bg-zinc-900/80 border-zinc-800 text-zinc-400'
                        }`}
                      >
                        <span className="text-xs font-bold text-white block">{item.title}</span>
                        <span className="text-[11px] font-bold text-emerald-400 mt-0.5 block">{item.rate}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <button
                id="target-continue-btn"
                type="button"
                onClick={nextStep}
                className="w-full py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-sm transition-all shadow-lg shadow-emerald-500/20"
              >
                {t.continue}
              </button>
            </motion.div>
          )}

          {/* STEP 7: DAILY ACTIVITY LEVEL */}
          {currentStep === 7 && (
            <motion.div
              key="step-7"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-5"
            >
              <div className="text-center space-y-1.5">
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white">{t.activityTitle}</h2>
                <p className="text-zinc-400 text-xs sm:text-sm">{t.activitySubtitle}</p>
              </div>

              <div className="space-y-2.5">
                {[
                  { id: 'sedentary', item: t.activities.sedentary, icon: Clock },
                  { id: 'lightly_active', item: t.activities.lightly_active, icon: Activity },
                  { id: 'moderately_active', item: t.activities.moderately_active, icon: Dumbbell },
                  { id: 'very_active', item: t.activities.very_active, icon: Flame },
                ].map(({ id, item, icon: IconComp }) => {
                  const isSelected = activity === id;
                  return (
                    <motion.button
                      key={id}
                      id={`act-${id}`}
                      type="button"
                      whileTap={{ scale: 0.98 }}
                      onClick={() => {
                        setActivity(id as ActivityLevel);
                        setTimeout(nextStep, 250);
                      }}
                      className={`w-full p-4 rounded-2xl border text-left flex items-center justify-between transition-all ${
                        isSelected
                          ? 'bg-emerald-950/60 border-emerald-500 text-white shadow-lg ring-2 ring-emerald-500/30'
                          : 'bg-zinc-900/80 border-zinc-800 hover:border-zinc-700 text-zinc-300'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${isSelected ? 'bg-emerald-500 text-black' : 'bg-zinc-800 text-zinc-400'}`}>
                          <IconComp className="w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="text-sm font-bold text-white">{item.title}</h4>
                          <p className="text-xs text-zinc-400 mt-0.5">{item.desc}</p>
                        </div>
                      </div>
                      <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${isSelected ? 'bg-emerald-500 border-emerald-500 text-black' : 'border-zinc-700'}`}>
                        {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                      </div>
                    </motion.button>
                  );
                })}
              </div>
            </motion.div>
          )}

          {/* STEP 8: DIET PREFERENCE */}
          {currentStep === 8 && (
            <motion.div
              key="step-8"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-5"
            >
              <div className="text-center space-y-1.5">
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white">{t.dietTitle}</h2>
                <p className="text-zinc-400 text-xs sm:text-sm">{t.dietSubtitle}</p>
              </div>

              <div className="space-y-2.5">
                {t.diets.map((d) => {
                  const isSelected = dietaryPreference === d.id;
                  return (
                    <motion.button
                      key={d.id}
                      type="button"
                      whileTap={{ scale: 0.98 }}
                      onClick={() => {
                        setDietaryPreference(d.id);
                        setTimeout(nextStep, 250);
                      }}
                      className={`w-full p-4 rounded-2xl border text-left flex items-center justify-between transition-all ${
                        isSelected
                          ? 'bg-emerald-950/60 border-emerald-500 text-white shadow-lg ring-2 ring-emerald-500/30'
                          : 'bg-zinc-900/80 border-zinc-800 hover:border-zinc-700 text-zinc-300'
                      }`}
                    >
                      <div>
                        <h4 className="text-sm font-bold text-white">{d.title}</h4>
                        <p className="text-xs text-zinc-400 mt-0.5">{d.desc}</p>
                      </div>
                      <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${isSelected ? 'bg-emerald-500 border-emerald-500 text-black' : 'border-zinc-700'}`}>
                        {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                      </div>
                    </motion.button>
                  );
                })}
              </div>
            </motion.div>
          )}

          {/* STEP 9: BIGGEST OBSTACLES */}
          {currentStep === 9 && (
            <motion.div
              key="step-9"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-5"
            >
              <div className="text-center space-y-1.5">
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white">{t.obstacleTitle}</h2>
                <p className="text-zinc-400 text-xs sm:text-sm">{t.obstacleSubtitle}</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {t.obstaclesList.map((obs, i) => {
                  const isSelected = selectedObstacles.includes(obs);
                  return (
                    <button
                      key={i}
                      type="button"
                      onClick={() => toggleObstacle(obs)}
                      className={`p-3.5 rounded-2xl border text-left flex items-center justify-between transition-all ${
                        isSelected
                          ? 'bg-emerald-950/60 border-emerald-500 text-white'
                          : 'bg-zinc-900/80 border-zinc-800 text-zinc-400'
                      }`}
                    >
                      <span className="text-xs font-semibold">{obs}</span>
                      <div className={`w-5 h-5 rounded-md border flex items-center justify-center ${isSelected ? 'bg-emerald-500 border-emerald-500 text-black' : 'border-zinc-700'}`}>
                        {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                      </div>
                    </button>
                  );
                })}
              </div>

              <button
                id="obstacle-continue-btn"
                type="button"
                onClick={nextStep}
                className="w-full py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-sm transition-all shadow-lg shadow-emerald-500/20"
              >
                {t.continue}
              </button>
            </motion.div>
          )}

          {/* STEP 10: MEDICAL / BLOOD REPORT (100% OPTIONAL) */}
          {currentStep === 10 && (
            <motion.div
              key="step-10"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <ReportUploader
                lang={lang}
                currentAnalysis={reportAnalysis}
                onReportAnalyzed={(data) => {
                  setReportAnalysis(data);
                  nextStep();
                }}
                onSkip={nextStep}
              />
            </motion.div>
          )}

          {/* STEP 11: USER ACCOUNT REGISTRATION */}
          {currentStep === 11 && (
            <motion.div
              key="step-11"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-5"
            >
              <div className="text-center space-y-1.5">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto mb-2">
                  <Lock className="w-6 h-6" />
                </div>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white">{t.accountTitle}</h2>
                <p className="text-zinc-400 text-xs sm:text-sm">{t.accountSubtitle}</p>
              </div>

              <form onSubmit={handleRegister} className="space-y-4 bg-zinc-900/90 border border-zinc-800 p-6 rounded-3xl backdrop-blur-md shadow-xl">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-zinc-300">{t.fullName}</label>
                  <input
                    id="reg-name-input"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder={lang === 'hi' ? 'उदा. राहुल शर्मा' : 'e.g. Alex Sharma'}
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-emerald-500 rounded-xl px-4 py-3 text-sm text-white placeholder-zinc-500 focus:outline-none transition-colors"
                    required
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-zinc-300">{t.email}</label>
                  <input
                    id="reg-email-input"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="user@example.com"
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-emerald-500 rounded-xl px-4 py-3 text-sm text-white placeholder-zinc-500 focus:outline-none transition-colors"
                    required
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-zinc-300">{t.password}</label>
                  <input
                    id="reg-password-input"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-emerald-500 rounded-xl px-4 py-3 text-sm text-white placeholder-zinc-500 focus:outline-none transition-colors"
                    required
                  />
                </div>

                {authError && (
                  <p className="text-xs text-rose-400 bg-rose-950/40 p-2.5 rounded-lg border border-rose-500/30">
                    {authError}
                  </p>
                )}

                <button
                  id="submit-register-btn"
                  type="submit"
                  disabled={isSubmittingAuth}
                  className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-green-400 hover:from-emerald-400 hover:to-green-300 text-black font-extrabold text-sm transition-all shadow-lg shadow-emerald-500/25 active:scale-[0.99] flex items-center justify-center gap-2"
                >
                  <span>{isSubmittingAuth ? t.creatingBtn : t.createAccountBtn}</span>
                </button>

                <p className="text-[11px] text-zinc-500 text-center flex items-center justify-center gap-1.5 pt-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span>256-bit Secure • Firebase Auth & Supabase Database</span>
                </p>
              </form>
            </motion.div>
          )}

          {/* STEP 12: AI PLAN CALCULATION ANIMATION */}
          {currentStep === 12 && (
            <motion.div
              key="step-12"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center space-y-7 py-8"
            >
              <div className="relative w-24 h-24 mx-auto flex items-center justify-center">
                <div className="absolute inset-0 rounded-full border-4 border-emerald-500/20 animate-ping" />
                <div className="absolute inset-0 rounded-full border-4 border-t-emerald-500 border-r-emerald-400 border-b-transparent border-l-transparent animate-spin" />
                <Sparkles className="w-10 h-10 text-emerald-400" />
              </div>

              <div className="space-y-2">
                <h3 className="text-2xl sm:text-3xl font-black text-white">
                  {t.calculatingTitle}
                </h3>
                <p className="text-xs sm:text-sm text-emerald-400 font-bold animate-pulse">
                  {calcStatus}
                </p>
              </div>

              <div className="w-full bg-zinc-900 h-3 rounded-full overflow-hidden border border-zinc-800 p-0.5">
                <motion.div
                  className="bg-gradient-to-r from-emerald-500 to-green-300 h-full rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${calcProgress}%` }}
                  transition={{ duration: 0.5 }}
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5 text-left">
                <div className="p-3 rounded-xl bg-zinc-900/80 border border-zinc-800 text-xs flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span className="text-zinc-300">BMR & TDEE Calibrated</span>
                </div>
                <div className="p-3 rounded-xl bg-zinc-900/80 border border-zinc-800 text-xs flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span className="text-zinc-300">Macronutrients Split</span>
                </div>
                <div className="p-3 rounded-xl bg-zinc-900/80 border border-zinc-800 text-xs flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span className="text-zinc-300">Hydration Target Set</span>
                </div>
                <div className="p-3 rounded-xl bg-zinc-900/80 border border-zinc-800 text-xs flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span className="text-zinc-300">Milestone Projected</span>
                </div>
              </div>
            </motion.div>
          )}

        </AnimatePresence>
      </main>

      {/* Footer Branding */}
      <footer className="w-full text-center text-[11px] text-zinc-600 pt-4">
        <span>Cal AI • Smart Nutrition Intelligence</span>
      </footer>
    </div>
  );
};
