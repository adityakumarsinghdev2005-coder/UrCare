import React, { useState } from 'react';
import { 
  Crown, Sparkles, Check, QrCode, CreditCard, ShieldCheck, Zap, X, Copy, ExternalLink, ArrowRight, Lock
} from 'lucide-react';
import { UserAccount } from '../types';

interface ProUpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  account: UserAccount;
  onUpgradeSuccess: (updatedAccount: UserAccount) => void;
  featureTriggerName?: string;
}

export const ProUpgradeModal: React.FC<ProUpgradeModalProps> = ({
  isOpen,
  onClose,
  account,
  onUpgradeSuccess,
  featureTriggerName = 'AI Food Camera Scanner',
}) => {
  const [planType, setPlanType] = useState<'monthly' | 'yearly'>('yearly');
  const [paymentStep, setPaymentStep] = useState<'plan_select' | 'payment' | 'success'>('plan_select');
  const [paymentMethod, setPaymentMethod] = useState<'qr_upi' | 'razorpay'>('qr_upi');
  const [transactionId, setTransactionId] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [copiedUpi, setCopiedUpi] = useState(false);

  if (!isOpen) return null;

  const price = planType === 'yearly' ? 2499 : 499;
  const originalPrice = planType === 'yearly' ? 5999 : 899;
  const perMonthText = planType === 'yearly' ? '₹208/month' : '₹499/month';

  const upiId = 'calai.official@okhdfcbank';
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=upi://pay?pa=${upiId}&pn=CalAI%20Pro%20Subscription&am=${price}&cu=INR`;

  const proFeatures = [
    { title: 'AI Food Vision & Camera Scanner', desc: 'Scan any meal in 2 seconds to get instant calories & macros' },
    { title: 'Doctor & Nutritionist Prescriptions', desc: 'Clinical review of your lab reports with customized medicine & diet guidance' },
    { title: 'Unlimited Medical Report Uploads', desc: 'Blood, Thyroid, Lipid, HbA1c & Vitamin biomarker tracking' },
    { title: 'Personalized Daily & Weekly Blueprints', desc: 'Exact what-to-eat & what-to-avoid recommendations every morning' },
    { title: 'VIP Supplement Store Discount', desc: 'Extra 15% discount on all Cal AI whey, plant protein & vitamins' },
  ];

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(upiId);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2500);
  };

  const handleConfirmQrPayment = async () => {
    setIsProcessing(true);
    try {
      await fetch('/api/user/upgrade-pro', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: account.uid,
          planType,
          paymentMethod: 'qr_upi',
          transactionId: transactionId || 'UPI-' + Math.random().toString(36).substring(2, 10).toUpperCase(),
        }),
      });

      const updated: UserAccount = {
        ...account,
        isPro: true,
        proPlanType: planType,
        proExpiry: new Date(Date.now() + (planType === 'yearly' ? 365 : 30) * 24 * 60 * 60 * 1000).toISOString(),
      };

      try {
        localStorage.setItem('calai_user_account', JSON.stringify(updated));
      } catch (e) {}

      onUpgradeSuccess(updated);
      setPaymentStep('success');
    } catch (e) {
      console.error(e);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleRazorpayPayment = async () => {
    setIsProcessing(true);
    try {
      // 1. Create order on server
      const res = await fetch('/api/razorpay/order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: price,
          receipt: 'pro_sub_' + Date.now(),
        }),
      });
      const orderData = await res.json();

      // Simulated seamless checkout verification
      setTimeout(async () => {
        await fetch('/api/razorpay/verify', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            razorpay_order_id: orderData.id,
            razorpay_payment_id: 'pay_' + Math.random().toString(36).substring(2, 10),
          }),
        });

        await fetch('/api/user/upgrade-pro', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: account.uid,
            planType,
            paymentMethod: 'razorpay',
          }),
        });

        const updated: UserAccount = {
          ...account,
          isPro: true,
          proPlanType: planType,
          proExpiry: new Date(Date.now() + (planType === 'yearly' ? 365 : 30) * 24 * 60 * 60 * 1000).toISOString(),
        };

        try {
          localStorage.setItem('calai_user_account', JSON.stringify(updated));
        } catch (e) {}

        onUpgradeSuccess(updated);
        setIsProcessing(false);
        setPaymentStep('success');
      }, 1200);
    } catch (e) {
      setIsProcessing(false);
      console.error(e);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div 
        id="pro-upgrade-modal-card"
        className="relative w-full max-w-lg bg-zinc-950 border border-emerald-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-emerald-500/10 my-8"
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {paymentStep === 'plan_select' && (
          <div>
            {/* Crown Header */}
            <div className="text-center mb-6">
              <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 via-emerald-500 to-green-400 p-0.5 shadow-lg shadow-emerald-500/20 mb-3">
                <div className="w-full h-full bg-zinc-950 rounded-[14px] flex items-center justify-center">
                  <Crown className="w-7 h-7 text-amber-400" />
                </div>
              </div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold mb-2">
                <Lock className="w-3.5 h-3.5" />
                <span>Pro Feature: {featureTriggerName}</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                Unlock <span className="text-emerald-400">Cal AI PRO</span>
              </h2>
              <p className="text-sm text-zinc-400 mt-1 max-w-sm mx-auto">
                Scan food in seconds, get clinical doctor prescriptions, and personalized daily guidance.
              </p>
            </div>

            {/* Plan Selector */}
            <div className="grid grid-cols-2 gap-3 mb-6">
              <button
                type="button"
                onClick={() => setPlanType('yearly')}
                className={`relative p-4 rounded-2xl border text-left transition-all ${
                  planType === 'yearly'
                    ? 'bg-emerald-950/40 border-emerald-500 shadow-lg shadow-emerald-500/10'
                    : 'bg-zinc-900/60 border-zinc-800 hover:border-zinc-700 text-zinc-400'
                }`}
              >
                <div className="absolute -top-2.5 right-3 bg-gradient-to-r from-amber-500 to-emerald-500 text-black text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
                  Save 60%
                </div>
                <div className="text-xs font-bold text-emerald-400 uppercase tracking-wide">Annual Plan</div>
                <div className="text-xl font-black text-white mt-1">₹2,499<span className="text-xs font-normal text-zinc-400">/yr</span></div>
                <div className="text-[11px] text-zinc-400 mt-0.5">₹208 / month</div>
              </button>

              <button
                type="button"
                onClick={() => setPlanType('monthly')}
                className={`p-4 rounded-2xl border text-left transition-all ${
                  planType === 'monthly'
                    ? 'bg-emerald-950/40 border-emerald-500 shadow-lg shadow-emerald-500/10'
                    : 'bg-zinc-900/60 border-zinc-800 hover:border-zinc-700 text-zinc-400'
                }`}
              >
                <div className="text-xs font-bold text-zinc-400 uppercase tracking-wide">Monthly Plan</div>
                <div className="text-xl font-black text-white mt-1">₹499<span className="text-xs font-normal text-zinc-400">/mo</span></div>
                <div className="text-[11px] text-zinc-400 mt-0.5">Billed monthly</div>
              </button>
            </div>

            {/* Feature List */}
            <div className="space-y-3 mb-6 bg-zinc-900/50 rounded-2xl p-4 border border-zinc-800/80">
              {proFeatures.map((f, i) => (
                <div key={i} className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">{f.title}</h4>
                    <p className="text-[11px] text-zinc-400">{f.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* CTA Button */}
            <button
              id="proceed-pro-payment-btn"
              type="button"
              onClick={() => setPaymentStep('payment')}
              className="w-full py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-base flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25 transition-all transform active:scale-95"
            >
              <span>Continue to Pay ₹{price}</span>
              <ArrowRight className="w-5 h-5" />
            </button>

            <div className="flex items-center justify-center gap-4 mt-4 text-[11px] text-zinc-500">
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                7-Day Money Back Guarantee
              </span>
              <span>•</span>
              <span>Instant AI Unlock</span>
            </div>
          </div>
        )}

        {paymentStep === 'payment' && (
          <div>
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="text-xl font-black text-white">Choose Payment Method</h3>
                <p className="text-xs text-zinc-400">Total payable: <strong className="text-emerald-400">₹{price}</strong> ({planType === 'yearly' ? '1 Year Pro' : '1 Month Pro'})</p>
              </div>
              <button
                type="button"
                onClick={() => setPaymentStep('plan_select')}
                className="text-xs text-zinc-400 hover:text-white underline"
              >
                Change Plan
              </button>
            </div>

            {/* Payment Method Switcher */}
            <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-zinc-900 border border-zinc-800 mb-5">
              <button
                type="button"
                onClick={() => setPaymentMethod('qr_upi')}
                className={`py-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                  paymentMethod === 'qr_upi'
                    ? 'bg-emerald-500 text-black shadow-md'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                <QrCode className="w-4 h-4" />
                <span>UPI QR Code</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod('razorpay')}
                className={`py-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                  paymentMethod === 'razorpay'
                    ? 'bg-emerald-500 text-black shadow-md'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                <CreditCard className="w-4 h-4" />
                <span>Razorpay / Cards</span>
              </button>
            </div>

            {paymentMethod === 'qr_upi' ? (
              <div className="space-y-4">
                {/* QR Code Container */}
                <div className="p-4 rounded-2xl bg-white flex flex-col items-center justify-center text-center shadow-lg">
                  <img
                    src={qrUrl}
                    alt="UPI Payment QR"
                    className="w-44 h-44 object-contain rounded-lg"
                  />
                  <div className="mt-2 text-black">
                    <p className="text-xs font-bold">Scan with GPay, PhonePe, Paytm, BHIM</p>
                    <p className="text-xs text-zinc-600 font-mono mt-0.5">Amount: ₹{price}.00</p>
                  </div>
                </div>

                {/* Copy UPI ID */}
                <div className="flex items-center justify-between p-3 rounded-xl bg-zinc-900 border border-zinc-800">
                  <div>
                    <div className="text-[10px] text-zinc-400 uppercase font-bold">UPI ID</div>
                    <div className="text-xs font-mono font-bold text-white">{upiId}</div>
                  </div>
                  <button
                    type="button"
                    onClick={handleCopyUpi}
                    className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-emerald-400 text-xs font-bold flex items-center gap-1.5 transition-colors"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>{copiedUpi ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>

                {/* UTR input */}
                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1.5">
                    Enter UPI Ref / Transaction ID (UTR)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 423981092831"
                    value={transactionId}
                    onChange={(e) => setTransactionId(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-800 focus:border-emerald-500 focus:outline-none text-white text-sm"
                  />
                </div>

                {/* Confirm QR button */}
                <button
                  id="confirm-qr-pro-btn"
                  type="button"
                  onClick={handleConfirmQrPayment}
                  disabled={isProcessing}
                  className="w-full py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-sm flex items-center justify-center gap-2 transition-all disabled:opacity-50 shadow-lg shadow-emerald-500/20"
                >
                  {isProcessing ? (
                    <div className="w-5 h-5 rounded-full border-2 border-black border-t-transparent animate-spin" />
                  ) : (
                    <>
                      <span>I Have Paid ₹{price} via QR</span>
                      <Check className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="p-6 rounded-2xl bg-zinc-900 border border-zinc-800 text-center">
                  <div className="w-12 h-12 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center mx-auto mb-3">
                    <CreditCard className="w-6 h-6" />
                  </div>
                  <h4 className="text-base font-bold text-white">Razorpay Secure Gateway</h4>
                  <p className="text-xs text-zinc-400 mt-1">
                    Pay securely using UPI Apps, Credit/Debit Cards, NetBanking, or Wallets.
                  </p>
                </div>

                <button
                  id="pay-razorpay-pro-btn"
                  type="button"
                  onClick={handleRazorpayPayment}
                  disabled={isProcessing}
                  className="w-full py-3.5 rounded-xl bg-blue-500 hover:bg-blue-400 text-white font-extrabold text-sm flex items-center justify-center gap-2 transition-all disabled:opacity-50 shadow-lg shadow-blue-500/20"
                >
                  {isProcessing ? (
                    <div className="w-5 h-5 rounded-full border-2 border-white border-t-transparent animate-spin" />
                  ) : (
                    <>
                      <span>Pay ₹{price} with Razorpay</span>
                      <Zap className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            )}
          </div>
        )}

        {paymentStep === 'success' && (
          <div className="text-center py-6">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500 flex items-center justify-center mx-auto mb-4 animate-bounce">
              <Check className="w-8 h-8" />
            </div>
            <h3 className="text-2xl font-black text-white">Welcome to Cal AI PRO!</h3>
            <p className="text-sm text-zinc-400 mt-2 max-w-sm mx-auto">
              Your Pro membership is now active! All AI Food Scanner camera capabilities, doctor guidance, and unlimited features are unlocked.
            </p>
            <button
              type="button"
              onClick={onClose}
              className="mt-6 px-8 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-sm shadow-lg shadow-emerald-500/20 transition-all"
            >
              Start Using Pro Features
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
