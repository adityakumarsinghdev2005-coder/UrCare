import React, { useState } from 'react';
import { 
  CheckCircle2, AlertTriangle, ShieldCheck, Apple, Ban, Calendar, 
  Sparkles, Clock, Flame, Droplets, Target, ChevronRight, Activity, 
  Languages, HeartPulse, Stethoscope, FileText, ArrowRight
} from 'lucide-react';
import { UserHealthProfile, Prescription } from '../types';

interface RecommendationsViewProps {
  profile: UserHealthProfile;
  prescriptions?: Prescription[];
  onOpenStore?: () => void;
  onOpenReportHub?: () => void;
}

export const RecommendationsView: React.FC<RecommendationsViewProps> = ({
  profile,
  prescriptions = [],
  onOpenStore,
  onOpenReportHub,
}) => {
  const [selectedDay, setSelectedDay] = useState<'yesterday' | 'today' | 'tomorrow'>('today');
  const [timeframe, setTimeframe] = useState<'daily' | 'weekly' | 'monthly'>('daily');
  const [language, setLanguage] = useState<'en' | 'hi'>('en');

  const { calculatedPlan, goal, reportAnalysis } = profile;
  const targetCalories = calculatedPlan.targetCalories || 1850;
  const targetProtein = calculatedPlan.proteinGrams || 140;

  // Bilingual guidance strings
  const content = {
    en: {
      title: 'AI Health & Nutrition Protocol',
      subtitle: 'Daily customized what-to-eat, what-to-avoid, risk factors & prevention guide.',
      daily: 'Daily Protocol',
      weekly: 'Weekly Blueprint',
      monthly: 'Monthly Roadmap',
      yesterday: 'Yesterday',
      today: 'Today',
      tomorrow: 'Tomorrow',
      whatToEat: 'What to Eat (Recommended)',
      whatToAvoid: 'What NOT to Eat (Avoid)',
      risks: 'Health & Metabolic Risks',
      preventions: 'Preventions & Action Steps',
      doctorRx: 'Clinical Prescriptions & Doctor Guidance',
      viewReport: 'View Lab Analysis',
    },
    hi: {
      title: 'AI स्वास्थ्य एवं पोषण निर्देश',
      subtitle: 'क्या खाएं, क्या न खाएं, संभावित खतरे एवं रोकथाम की दैनिक सलाह।',
      daily: 'दैनिक नियम',
      weekly: 'साप्ताहिक योजना',
      monthly: 'मासिक रोडमैप',
      yesterday: 'कल (बीता हुआ)',
      today: 'आज',
      tomorrow: 'कल (आने वाला)',
      whatToEat: 'क्या खाएं (अनुशंसित आहार)',
      whatToAvoid: 'क्या न खाएं (परहेज करें)',
      risks: 'स्वास्थ्य एवं मेटाबोलिक जोखिम',
      preventions: 'रोकथाम एवं दैनिक उपाय',
      doctorRx: 'डॉक्टर द्वारा दी गई दवाइयां और सलाह',
      viewReport: 'लैब रिपोर्ट देखें',
    },
  }[language];

  // Specific food recommendations based on goal and user report
  const eatList = [
    {
      title: language === 'en' ? 'Lean High-Quality Protein' : 'उच्च गुणवत्ता वाला प्रोटीन',
      desc: language === 'en' 
        ? `Target ${targetProtein}g daily across 3-4 meals. Include Whey Isolate, egg whites, paneer/tofu, lentils (dal), and Greek yogurt.`
        : `रोजाना ${targetProtein} ग्राम प्रोटीन 3-4 भोजन में बांटकर लें। व्हे प्रोटीन, अंडे का सफेद भाग, पनीर/टोफू और दालें शामिल करें।`,
      icon: '🥩',
      calories: '40% of goal',
    },
    {
      title: language === 'en' ? 'Soluble Fiber & Whole Grains' : 'घुलनशील फाइबर एवं साबुत अनाज',
      desc: language === 'en'
        ? 'Rolled oats, chia seeds, brown rice, quinoa, and green vegetables (spinach, cucumber) to optimize lipid clearance.'
        : 'रोल्ड ओट्स, चिया बीज, भूरे चावल और हरी सब्जियां (पालक, खीरा) खाएं ताकि कोलेस्ट्रॉल नियंत्रित रहे।',
      icon: '🥗',
      calories: '35g Fiber',
    },
    {
      title: language === 'en' ? 'Cardio-Protective Healthy Fats' : 'हृदय के लिए गुणकारी वसा (हेल्दी फैट्स)',
      desc: language === 'en'
        ? 'Triple Strength Omega-3 fish oil or walnuts, flaxseeds, and 1 teaspoon cold-pressed olive or mustard oil.'
        : 'ओमेगा-3 फिश ऑयल, अखरोट, अलसी के बीज और शुद्ध कोल्ड-प्रेस्ड तेल का सीमित प्रयोग करें।',
      icon: '🥑',
      calories: 'MUFA & PUFA',
    },
    {
      title: language === 'en' ? 'Micronutrient Boosters' : 'विटामिन और मिनरल्स',
      desc: language === 'en'
        ? 'Vitamin D3 (early morning sunlight or drops), Vitamin C (amla, lemon water), and magnesium glycinate for sleep.'
        : 'विटामिन डी3 (सुबह की धूप), आंवला/नींबू पानी से विटामिन सी और बेहतर नींद के लिए मैग्नीशियम लें।',
      icon: '🍊',
      calories: 'Daily Essentials',
    },
  ];

  // What to avoid
  const avoidList = [
    {
      title: language === 'en' ? 'Deep Fried & Trans-Fat Snacks' : 'तली-भुनी चीजें और ट्रांस फैट',
      desc: language === 'en'
        ? 'Samosas, commercial bakery biscuits, palm oil fried snacks, and reheated cooking oils.'
        : 'समोसे, तली हुई नमकीन, बेकरी बिस्कुट और बार-बार गर्म किया हुआ तेल बिल्कुल न लें।',
      icon: '🍟',
    },
    {
      title: language === 'en' ? 'Liquid Sugars & High-Fructose Drinks' : 'मीठे पेय पदार्थ और कोल्ड ड्रिंक्स',
      desc: language === 'en'
        ? 'Packaged fruit juices, carbonated sodas, and excess sugar in tea/coffee. Causes visceral liver fat.'
        : 'पैकेट वाले जूस, कोल्ड ड्रिंक्स और अधिक चीनी वाली चाय/कॉफी से बचें। यह लिवर में फैट बढ़ाती है।',
      icon: '🥤',
    },
    {
      title: language === 'en' ? 'Ultra-Processed Refined Carbs' : 'मैदा और प्रोसेस्ड खाद्य पदार्थ',
      desc: language === 'en'
        ? 'White bread, instant noodles, and sugary breakfast cereals with high glycemic spikes.'
        : 'सफेद ब्रेड, मैगी/नूडल्स और मीठे पैकेज्ड अनाज जो ब्लड शुगर में अचानक तेजी लाते हैं।',
      icon: '🥐',
    },
    {
      title: language === 'en' ? 'Late-Night Heavy Sodium Meals' : 'देर रात का भारी और नमकीन भोजन',
      desc: language === 'en'
        ? 'Avoid heavy dining post 9:30 PM to prevent acid reflux, water retention, and sleep disruption.'
        : 'रात 9:30 बजे के बाद भारी और ज्यादा नमक वाला खाना न खाएं ताकि पाचन और नींद अच्छी रहे।',
      icon: '🧂',
    },
  ];

  // Identified risks
  const risksList: Array<{ risk: string; severity: 'high' | 'medium' | 'low'; note: string }> = [
    {
      risk: language === 'en' ? 'Elevated Lipid Profile (LDL/Triglycerides)' : 'बढ़ा हुआ कोलेस्ट्रॉल (LDL)',
      severity: 'medium',
      note: language === 'en'
        ? 'Common when dietary saturated fat exceeds 10% of total calories. Manageable with daily fiber and Omega-3.'
        : 'जब डाइट में अनहेल्दी फैट ज्यादा होता है तब होता है। फाइबर और ओमेगा-3 से आसानी से ठीक हो सकता है।',
    },
    {
      risk: language === 'en' ? 'Vitamin D3 & Sunlight Deficiency' : 'विटामिन डी3 की कमी',
      severity: 'low',
      note: language === 'en'
        ? 'Impairs muscle recovery, energy synthesis, and bone density. 15 mins morning sun + D3 drops recommended.'
        : 'मांसपेशियों की रिकवरी और ऊर्जा के लिए सुबह 15 मिनट धूप या विटामिन डी3 की खुराक जरूरी है।',
    },
    {
      risk: language === 'en' ? 'Afternoon Energy Slump & Sugar Cravings' : 'दोपहर में थकान और मीठे की तलब',
      severity: 'low',
      note: language === 'en'
        ? 'Caused by high carb lunch without sufficient protein. Keep lunch protein >= 30g.'
        : 'दोपहर के खाने में प्रोटीन कम होने से होता है। लंच में कम से कम 30 ग्राम प्रोटीन रखें।',
    },
  ];

  // Preventions and actions
  const preventionsList = [
    {
      action: language === 'en' ? 'Hydration Timing Protocol' : 'पानी पीने का सही समय',
      tip: language === 'en' ? 'Drink 500ml water immediately upon waking, and 1 glass 30 mins before each meal.' : 'सुबह उठते ही 500ml पानी पिएं और हर भोजन से 30 मिनट पहले 1 गिलास पानी पिएं।',
      timing: 'Morning & Pre-meals',
    },
    {
      action: language === 'en' ? '10-Minute Post Meal Walk' : 'भोजन के बाद 10 मिनट की वॉक',
      tip: language === 'en' ? 'Gentle stroll after lunch and dinner reduces postprandial glucose spike by up to 24%.' : 'लंच और डिनर के बाद 10 मिनट टहलने से ब्लड शुगर नियंत्रित रहता है।',
      timing: 'Post Lunch / Dinner',
    },
    {
      action: language === 'en' ? '7-8 Hours Deep Sleep Recovery' : '7-8 घंटे की गहरी नींद',
      tip: language === 'en' ? 'Crucial for cortisol reduction and GH (growth hormone) release for fat burning.' : 'फैट बर्न और तनाव कम करने के लिए रात को समय पर सोना आवश्यक है।',
      timing: '10:30 PM - 06:30 AM',
    },
  ];

  return (
    <div id="cal-ai-recommendations-hub" className="space-y-6">
      
      {/* Top Banner & Language Selector */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-6 rounded-3xl bg-gradient-to-r from-zinc-950 via-zinc-900 to-emerald-950/40 border border-emerald-500/30">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Clinical Precision</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white">{content.title}</h2>
          <p className="text-xs sm:text-sm text-zinc-400 mt-1">{content.subtitle}</p>
        </div>

        <div className="flex items-center gap-2">
          {/* Language toggle */}
          <button
            type="button"
            onClick={() => setLanguage(language === 'en' ? 'hi' : 'en')}
            className="px-3 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-xs font-bold text-emerald-400 flex items-center gap-1.5 transition-colors"
          >
            <Languages className="w-4 h-4" />
            <span>{language === 'en' ? 'हिंदी (Hindi)' : 'English'}</span>
          </button>
        </div>
      </div>

      {/* Date-wise Filter (Yesterday / Today / Tomorrow) & Period View (Daily / Weekly / Monthly) */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Day Switcher */}
        <div className="flex items-center gap-1 p-1 bg-zinc-900 border border-zinc-800 rounded-2xl">
          <button
            type="button"
            onClick={() => setSelectedDay('yesterday')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              selectedDay === 'yesterday' ? 'bg-emerald-500 text-black shadow-md' : 'text-zinc-400 hover:text-white'
            }`}
          >
            {content.yesterday}
          </button>
          <button
            type="button"
            onClick={() => setSelectedDay('today')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              selectedDay === 'today' ? 'bg-emerald-500 text-black shadow-md' : 'text-zinc-400 hover:text-white'
            }`}
          >
            {content.today}
          </button>
          <button
            type="button"
            onClick={() => setSelectedDay('tomorrow')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              selectedDay === 'tomorrow' ? 'bg-emerald-500 text-black shadow-md' : 'text-zinc-400 hover:text-white'
            }`}
          >
            {content.tomorrow}
          </button>
        </div>

        {/* Timeframe Scope */}
        <div className="flex items-center gap-1 p-1 bg-zinc-900 border border-zinc-800 rounded-2xl">
          <button
            type="button"
            onClick={() => setTimeframe('daily')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              timeframe === 'daily' ? 'bg-zinc-800 text-white' : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            {content.daily}
          </button>
          <button
            type="button"
            onClick={() => setTimeframe('weekly')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              timeframe === 'weekly' ? 'bg-zinc-800 text-white' : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            {content.weekly}
          </button>
          <button
            type="button"
            onClick={() => setTimeframe('monthly')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              timeframe === 'monthly' ? 'bg-zinc-800 text-white' : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            {content.monthly}
          </button>
        </div>
      </div>

      {/* 1. DOCTOR & CLINICAL PRESCRIPTIONS SECTION (If issued by Admin/Doctor) */}
      {prescriptions && prescriptions.length > 0 && (
        <div className="p-5 rounded-3xl bg-emerald-950/30 border border-emerald-500/40 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <Stethoscope className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-black text-white">{content.doctorRx}</h3>
                <p className="text-[11px] text-emerald-400">Prescribed by {prescriptions[0].doctorName}</p>
              </div>
            </div>
            {onOpenReportHub && (
              <button
                type="button"
                onClick={onOpenReportHub}
                className="text-xs text-emerald-400 font-bold hover:underline flex items-center gap-1"
              >
                <span>{content.viewReport}</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {prescriptions[0].medicines.map((med, idx) => (
              <div key={idx} className="p-3.5 rounded-2xl bg-zinc-900/80 border border-zinc-800 text-xs space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-sm">{med.name}</span>
                  <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-bold">{med.dosage}</span>
                </div>
                <div className="text-zinc-400 font-medium">Frequency: {med.frequency} ({med.duration})</div>
                {med.notes && <div className="text-[11px] text-zinc-500 italic">{med.notes}</div>}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 2 & 3: WHAT TO EAT & WHAT NOT TO EAT GRIDS */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* WHAT TO EAT */}
        <div className="p-6 rounded-3xl bg-zinc-950 border border-emerald-500/30 space-y-4">
          <div className="flex items-center gap-2.5 pb-2 border-b border-zinc-800">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <Apple className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-black text-white">{content.whatToEat}</h3>
              <p className="text-[11px] text-emerald-400">Targeting {targetCalories} kcal / {targetProtein}g protein</p>
            </div>
          </div>

          <div className="space-y-3">
            {eatList.map((item, index) => (
              <div key={index} className="p-3.5 rounded-2xl bg-zinc-900/60 border border-zinc-800/80 space-y-1">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{item.icon}</span>
                    <h4 className="text-xs font-bold text-white">{item.title}</h4>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-500/30">
                    {item.calories}
                  </span>
                </div>
                <p className="text-xs text-zinc-400 leading-relaxed pl-7">
                  {item.desc}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* WHAT TO AVOID */}
        <div className="p-6 rounded-3xl bg-zinc-950 border border-rose-500/30 space-y-4">
          <div className="flex items-center gap-2.5 pb-2 border-b border-zinc-800">
            <div className="w-8 h-8 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center">
              <Ban className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-black text-white">{content.whatToAvoid}</h3>
              <p className="text-[11px] text-rose-400">Inflammatory & high-glycemic triggers</p>
            </div>
          </div>

          <div className="space-y-3">
            {avoidList.map((item, index) => (
              <div key={index} className="p-3.5 rounded-2xl bg-zinc-900/60 border border-zinc-800/80 space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-lg">{item.icon}</span>
                  <h4 className="text-xs font-bold text-white">{item.title}</h4>
                </div>
                <p className="text-xs text-zinc-400 leading-relaxed pl-7">
                  {item.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 4 & 5: RISKS & PREVENTIONS */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* RISKS */}
        <div className="p-6 rounded-3xl bg-zinc-950 border border-amber-500/30 space-y-4">
          <div className="flex items-center gap-2.5 pb-2 border-b border-zinc-800">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-black text-white">{content.risks}</h3>
              <p className="text-[11px] text-amber-400">Identified from profile & lab biomarkers</p>
            </div>
          </div>

          <div className="space-y-3">
            {risksList.map((r, i) => (
              <div key={i} className="p-3.5 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-1">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-amber-300">{r.risk}</h4>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded capitalize ${
                    r.severity === 'high' ? 'bg-rose-500/20 text-rose-400' : 'bg-amber-500/20 text-amber-300'
                  }`}>
                    {r.severity} Risk
                  </span>
                </div>
                <p className="text-xs text-zinc-400 leading-relaxed">{r.note}</p>
              </div>
            ))}
          </div>
        </div>

        {/* PREVENTIONS & ACTION STEPS */}
        <div className="p-6 rounded-3xl bg-zinc-950 border border-emerald-500/30 space-y-4">
          <div className="flex items-center gap-2.5 pb-2 border-b border-zinc-800">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-black text-white">{content.preventions}</h3>
              <p className="text-[11px] text-emerald-400">Clinical preventative wellness protocol</p>
            </div>
          </div>

          <div className="space-y-3">
            {preventionsList.map((p, i) => (
              <div key={i} className="p-3.5 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-1">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-emerald-300">{p.action}</h4>
                  <span className="text-[10px] font-bold text-zinc-400">{p.timing}</span>
                </div>
                <p className="text-xs text-zinc-400 leading-relaxed">{p.tip}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
