import React, { useState } from 'react';
import { X, HeartPulse, ShieldCheck, Activity, Plus, RefreshCw, Sparkles, FileText, CheckCircle2 } from 'lucide-react';
import { MedicalReportAnalysis } from '../types';
import { ReportUploader } from './ReportUploader';

interface HealthReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  reportAnalysis?: MedicalReportAnalysis;
  onUpdateReport: (analysis: MedicalReportAnalysis) => void;
}

export const HealthReportModal: React.FC<HealthReportModalProps> = ({
  isOpen,
  onClose,
  reportAnalysis,
  onUpdateReport,
}) => {
  const [isUploadingNew, setIsUploadingNew] = useState(!reportAnalysis);

  if (!isOpen) return null;

  return (
    <div id="health-report-modal-backdrop" className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div id="health-report-modal" className="w-full max-w-2xl bg-zinc-950 border border-emerald-500/40 rounded-3xl p-6 text-white shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <HeartPulse className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-white">Medical & Biomarker Health Hub</h3>
              <p className="text-xs text-zinc-400">Clinical lab report extraction & nutrition synergy</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {!isUploadingNew && reportAnalysis ? (
          <div className="space-y-5">
            
            {/* Top Report Info card */}
            <div className="p-4 rounded-2xl bg-emerald-950/30 border border-emerald-500/30 flex items-center justify-between flex-wrap gap-2">
              <div>
                <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-bold uppercase tracking-wider mb-0.5">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Active Report Calibrated</span>
                </div>
                <h4 className="text-base font-bold text-white">{reportAnalysis.reportName}</h4>
                <p className="text-xs text-zinc-400">Uploaded {new Date(reportAnalysis.uploadedAt).toLocaleDateString()}</p>
              </div>
              <button
                type="button"
                onClick={() => setIsUploadingNew(true)}
                className="py-2 px-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs font-semibold text-white flex items-center gap-1.5 transition-colors"
              >
                <Plus className="w-3.5 h-3.5 text-emerald-400" />
                <span>Upload New Report</span>
              </button>
            </div>

            {/* Summary */}
            <div className="p-3.5 rounded-xl bg-zinc-900/80 border border-zinc-800 text-xs text-zinc-300">
              <span className="font-bold text-white block mb-1">Clinical AI Summary:</span>
              <p>{reportAnalysis.summary}</p>
            </div>

            {/* Biomarkers list */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5" />
                <span>Extracted Biomarkers ({reportAnalysis.biomarkers?.length || 0})</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {reportAnalysis.biomarkers?.map((b, i) => (
                  <div
                    key={i}
                    className={`p-3 rounded-xl border text-xs space-y-1 ${
                      b.status === 'high' || b.status === 'critical'
                        ? 'bg-amber-950/20 border-amber-500/40 text-amber-200'
                        : b.status === 'low'
                        ? 'bg-blue-950/20 border-blue-500/40 text-blue-200'
                        : 'bg-emerald-950/20 border-emerald-500/30 text-emerald-200'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white">{b.name}</span>
                      <span className="text-[10px] px-2 py-0.5 rounded font-bold uppercase bg-black/40">
                        {b.value}
                      </span>
                    </div>
                    <p className="text-[11px] text-zinc-400">{b.impactOnDiet}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Recommendations */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Dietary Directives</span>
              </h4>
              <ul className="space-y-1.5 text-xs text-zinc-300 bg-zinc-900/60 p-3.5 rounded-xl border border-zinc-800">
                {reportAnalysis.dietaryRecommendations?.map((rec, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-emerald-400 font-bold">•</span>
                    <span>{rec}</span>
                  </li>
                ))}
              </ul>
            </div>

          </div>
        ) : (
          <div className="space-y-4">
            {reportAnalysis && (
              <button
                type="button"
                onClick={() => setIsUploadingNew(false)}
                className="text-xs text-zinc-400 hover:text-white flex items-center gap-1 mb-2"
              >
                ← Back to active report
              </button>
            )}
            <ReportUploader
              standalone
              onReportAnalyzed={(data) => {
                onUpdateReport(data);
                setIsUploadingNew(false);
              }}
            />
          </div>
        )}

      </div>
    </div>
  );
};
