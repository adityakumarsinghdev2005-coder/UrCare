import React, { useState } from 'react';
import { 
  ShoppingBag, Star, Plus, Minus, Check, ArrowRight, ShieldCheck, 
  Truck, QrCode, CreditCard, Sparkles, MapPin, X, Copy, Zap, 
  Package, ChevronRight, Filter, Info, HeartHandshake
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Product, CartItem, ShippingAddress, Order, UserAccount } from '../types';
import { INITIAL_PRODUCTS } from '../data/products';

interface ProductsModuleProps {
  account: UserAccount;
  onOrderPlaced?: (newOrder: Order) => void;
  onOpenMyOrders?: () => void;
}

export const ProductsModule: React.FC<ProductsModuleProps> = ({
  account,
  onOrderPlaced,
  onOpenMyOrders,
}) => {
  const [products] = useState<Product[]>(INITIAL_PRODUCTS);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedProductDetails, setSelectedProductDetails] = useState<Product | null>(null);

  // Checkout flow states: 'cart' | 'address' | 'payment' | 'order_confirmed'
  const [checkoutStep, setCheckoutStep] = useState<'none' | 'address' | 'payment' | 'order_confirmed'>('none');
  const [shippingAddress, setShippingAddress] = useState<ShippingAddress>({
    fullName: account.displayName || '',
    phone: '',
    streetAddress: '',
    city: '',
    state: 'Maharashtra',
    pincode: '',
  });

  const [paymentMethod, setPaymentMethod] = useState<'qr_upi' | 'razorpay'>('qr_upi');
  const [transactionId, setTransactionId] = useState('');
  const [isProcessingOrder, setIsProcessingOrder] = useState(false);
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);
  const [copiedUpi, setCopiedUpi] = useState(false);

  // Cart calculations
  const totalCartItems = cart.reduce((acc, item) => acc + item.quantity, 0);
  const cartSubtotal = cart.reduce((acc, item) => acc + (item.product.discountPrice || item.product.price) * item.quantity, 0);
  const deliveryFee = cartSubtotal > 1500 || cartSubtotal === 0 ? 0 : 99;
  const cartTotal = cartSubtotal + deliveryFee;

  const upiId = 'calai.official@okhdfcbank';
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=upi://pay?pa=${upiId}&pn=CalAI%20Health%20Store&am=${cartTotal}&cu=INR`;

  const handleAddToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
  };

  const handleUpdateQuantity = (productId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(upiId);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2500);
  };

  const handleAddressSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!shippingAddress.fullName || !shippingAddress.phone || !shippingAddress.streetAddress || !shippingAddress.city || !shippingAddress.pincode) {
      alert('Please fill in all address fields to proceed.');
      return;
    }
    setCheckoutStep('payment');
  };

  const handleFinalizeOrder = async () => {
    setIsProcessingOrder(true);
    try {
      const orderPayload = {
        userId: account.uid,
        userName: shippingAddress.fullName,
        userEmail: account.email,
        items: cart,
        shippingAddress,
        subtotal: cartSubtotal,
        discount: 0,
        total: cartTotal,
        paymentMethod,
        transactionId: transactionId || 'TXN-' + Math.random().toString(36).substring(2, 10).toUpperCase(),
      };

      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderPayload),
      });

      const data = await res.json();
      const orderPlaced: Order = data.order || {
        ...orderPayload,
        id: 'ORD-' + Math.floor(100000 + Math.random() * 900000),
        paymentStatus: 'paid',
        orderStatus: 'confirmed',
        createdAt: new Date().toISOString(),
        estimatedDelivery: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      };

      setConfirmedOrder(orderPlaced);
      if (onOrderPlaced) onOrderPlaced(orderPlaced);

      // Trigger celebration confetti
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#10b981', '#34d399', '#ffffff', '#fbbf24'],
        });
      } catch (e) {}

      // Clear cart
      setCart([]);
      setIsCartOpen(false);
      setCheckoutStep('order_confirmed');
    } catch (e) {
      console.error('Order creation error:', e);
    } finally {
      setIsProcessingOrder(false);
    }
  };

  const handleRazorpayCheckout = async () => {
    setIsProcessingOrder(true);
    try {
      const res = await fetch('/api/razorpay/order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: cartTotal,
          receipt: 'ord_rcpt_' + Date.now(),
        }),
      });
      const orderData = await res.json();

      setTimeout(() => {
        handleFinalizeOrder();
      }, 1000);
    } catch (e) {
      console.error(e);
      setIsProcessingOrder(false);
    }
  };

  const categories = [
    { id: 'all', label: 'All Products' },
    { id: 'protein', label: 'Whey & Plant Protein' },
    { id: 'vitamins', label: 'Vitamins & D3' },
    { id: 'superfoods', label: 'Supergreens' },
    { id: 'snacks', label: 'Protein Bars' },
    { id: 'accessories', label: 'Smart Shakers' },
  ];

  const filteredProducts = selectedCategory === 'all'
    ? products
    : products.filter((p) => p.category === selectedCategory);

  return (
    <div id="cal-ai-products-store" className="space-y-6">
      
      {/* Store Header Banner */}
      <div className="relative rounded-3xl bg-gradient-to-r from-emerald-950/80 via-zinc-950 to-zinc-900 border border-emerald-500/30 p-6 sm:p-8 overflow-hidden">
        <div className="relative z-10 max-w-xl">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Doctor & Nutritionist Approved Formulations</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            Cal AI <span className="text-emerald-400">Nutritional Store</span>
          </h2>
          <p className="text-sm text-zinc-400 mt-2">
            Targeted whey isolates, organic plant proteins, Omega-3s, and clinical vitamins tailored to your metabolic report and daily goals.
          </p>

          <div className="flex flex-wrap items-center gap-4 mt-5 text-xs text-zinc-300">
            <span className="flex items-center gap-1.5">
              <Truck className="w-4 h-4 text-emerald-400" />
              Free Express Delivery on ₹1,500+
            </span>
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              100% Labdoor Certified Purity
            </span>
            {onOpenMyOrders && (
              <button
                type="button"
                onClick={onOpenMyOrders}
                className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-emerald-400 font-bold flex items-center gap-1 transition-colors"
              >
                <Package className="w-3.5 h-3.5" />
                <span>My Orders</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Category Tabs & Cart Trigger */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-2">
        <div className="flex items-center gap-2 overflow-x-auto py-1 max-w-full scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                selectedCategory === cat.id
                  ? 'bg-emerald-500 text-black shadow-lg shadow-emerald-500/20'
                  : 'bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-700'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Cart Button */}
        <button
          id="open-cart-btn"
          type="button"
          onClick={() => setIsCartOpen(true)}
          className="relative px-4 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-white text-xs font-bold flex items-center gap-2 transition-all shrink-0"
        >
          <ShoppingBag className="w-4 h-4 text-emerald-400" />
          <span>Cart</span>
          {totalCartItems > 0 && (
            <span className="w-5 h-5 rounded-full bg-emerald-500 text-black text-[11px] font-black flex items-center justify-center">
              {totalCartItems}
            </span>
          )}
        </button>
      </div>

      {/* Product Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {filteredProducts.map((product) => (
          <div
            key={product.id}
            id={`product-card-${product.id}`}
            className="group flex flex-col justify-between rounded-2xl bg-zinc-900/60 border border-zinc-800/80 hover:border-emerald-500/40 p-4 transition-all duration-200 hover:shadow-xl hover:shadow-emerald-500/5"
          >
            <div>
              {/* Product Image */}
              <div 
                className="relative w-full h-44 rounded-xl overflow-hidden bg-zinc-950 mb-3 cursor-pointer"
                onClick={() => setSelectedProductDetails(product)}
              >
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                {product.featured && (
                  <span className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-emerald-500 text-black text-[10px] font-black uppercase tracking-wider">
                    Best Seller
                  </span>
                )}
                <div className="absolute bottom-2 right-2 flex items-center gap-1 px-2 py-0.5 rounded bg-black/70 backdrop-blur-md text-[11px] font-bold text-amber-300">
                  <Star className="w-3 h-3 fill-amber-300 text-amber-300" />
                  <span>{product.rating}</span>
                  <span className="text-zinc-400 text-[10px]">({product.reviewsCount})</span>
                </div>
              </div>

              {/* Title & Desc */}
              <h3 
                className="text-sm font-bold text-white line-clamp-1 group-hover:text-emerald-400 transition-colors cursor-pointer"
                onClick={() => setSelectedProductDetails(product)}
              >
                {product.name}
              </h3>
              <p className="text-xs text-zinc-400 line-clamp-2 mt-1 mb-2.5">
                {product.description}
              </p>

              {/* Key Benefits Pills */}
              <div className="flex flex-wrap gap-1 mb-3">
                {product.benefits.slice(0, 2).map((b, i) => (
                  <span key={i} className="text-[10px] px-2 py-0.5 rounded-full bg-zinc-800/70 text-zinc-300">
                    {b}
                  </span>
                ))}
              </div>
            </div>

            {/* Price & Add to Cart */}
            <div className="pt-3 border-t border-zinc-800/60 flex items-center justify-between">
              <div>
                <div className="text-base font-black text-white">₹{product.discountPrice}</div>
                <div className="text-[11px] text-zinc-500 line-through">₹{product.price}</div>
              </div>

              <button
                id={`add-to-cart-btn-${product.id}`}
                type="button"
                onClick={() => handleAddToCart(product)}
                className="px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-black font-extrabold text-xs flex items-center gap-1.5 transition-all shadow-md shadow-emerald-500/10"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add to Cart</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* CART DRAWER / MODAL */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/75 backdrop-blur-sm">
          <div 
            id="cart-drawer-panel"
            className="w-full max-w-md bg-zinc-950 border-l border-zinc-800 h-full flex flex-col p-6 shadow-2xl overflow-y-auto"
          >
            <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-emerald-400" />
                <h3 className="text-lg font-black text-white">Your Cart ({totalCartItems})</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsCartOpen(false)}
                className="p-2 rounded-full bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Cart Items List */}
            <div className="flex-1 overflow-y-auto py-4 space-y-3">
              {cart.length === 0 ? (
                <div className="text-center py-16 text-zinc-500">
                  <ShoppingBag className="w-12 h-12 mx-auto mb-2 opacity-30" />
                  <p className="text-sm font-semibold">Your cart is empty</p>
                  <p className="text-xs text-zinc-600 mt-1">Add items from the store to checkout</p>
                </div>
              ) : (
                cart.map((item) => (
                  <div key={item.product.id} className="flex items-center gap-3 p-3 rounded-xl bg-zinc-900/60 border border-zinc-800">
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-14 h-14 rounded-lg object-cover bg-zinc-950 shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-bold text-white truncate">{item.product.name}</h4>
                      <div className="text-xs font-bold text-emerald-400 mt-0.5">₹{item.product.discountPrice}</div>
                    </div>

                    {/* Quantity controls */}
                    <div className="flex items-center gap-2 bg-zinc-950 border border-zinc-800 rounded-lg p-1">
                      <button
                        type="button"
                        onClick={() => handleUpdateQuantity(item.product.id, -1)}
                        className="w-6 h-6 rounded flex items-center justify-center text-zinc-400 hover:text-white"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="text-xs font-bold text-white px-1">{item.quantity}</span>
                      <button
                        type="button"
                        onClick={() => handleUpdateQuantity(item.product.id, 1)}
                        className="w-6 h-6 rounded flex items-center justify-center text-zinc-400 hover:text-white"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Cart Footer / Checkout Trigger */}
            {cart.length > 0 && (
              <div className="pt-4 border-t border-zinc-800 space-y-3">
                <div className="space-y-1.5 text-xs text-zinc-400">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span className="text-white font-bold">₹{cartSubtotal}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Express Delivery</span>
                    <span className={deliveryFee === 0 ? 'text-emerald-400 font-bold' : 'text-white'}>
                      {deliveryFee === 0 ? 'FREE' : `₹${deliveryFee}`}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm font-extrabold text-white pt-2 border-t border-zinc-800">
                    <span>Total Amount</span>
                    <span className="text-emerald-400 text-base">₹{cartTotal}</span>
                  </div>
                </div>

                <button
                  id="proceed-checkout-btn"
                  type="button"
                  onClick={() => {
                    setIsCartOpen(false);
                    setCheckoutStep('address');
                  }}
                  className="w-full py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition-all active:scale-95"
                >
                  <span>Proceed to Enter Address</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ADDRESS FORM MODAL (Step 1 of checkout) */}
      {checkoutStep === 'address' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-lg bg-zinc-950 border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-2xl my-8">
            <button
              type="button"
              onClick={() => setCheckoutStep('none')}
              className="absolute top-4 right-4 p-2 rounded-full bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <MapPin className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xl font-black text-white">Delivery Address</h3>
                <p className="text-xs text-zinc-400">Where should we deliver your order?</p>
              </div>
            </div>

            <form onSubmit={handleAddressSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-zinc-300 mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Rahul Verma"
                  value={shippingAddress.fullName}
                  onChange={(e) => setShippingAddress({ ...shippingAddress, fullName: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 focus:border-emerald-500 focus:outline-none text-white text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-300 mb-1">Phone Number *</label>
                <input
                  type="tel"
                  required
                  placeholder="e.g. +91 98765 43210"
                  value={shippingAddress.phone}
                  onChange={(e) => setShippingAddress({ ...shippingAddress, phone: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 focus:border-emerald-500 focus:outline-none text-white text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-300 mb-1">Street Address / House No / Area *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Flat 402, Green Valley Heights, Andheri West"
                  value={shippingAddress.streetAddress}
                  onChange={(e) => setShippingAddress({ ...shippingAddress, streetAddress: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 focus:border-emerald-500 focus:outline-none text-white text-sm"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1">City *</label>
                  <input
                    type="text"
                    required
                    placeholder="Mumbai"
                    value={shippingAddress.city}
                    onChange={(e) => setShippingAddress({ ...shippingAddress, city: e.target.value })}
                    className="w-full px-3 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 focus:border-emerald-500 focus:outline-none text-white text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1">State *</label>
                  <input
                    type="text"
                    required
                    placeholder="Maharashtra"
                    value={shippingAddress.state}
                    onChange={(e) => setShippingAddress({ ...shippingAddress, state: e.target.value })}
                    className="w-full px-3 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 focus:border-emerald-500 focus:outline-none text-white text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1">Pincode *</label>
                  <input
                    type="text"
                    required
                    placeholder="400053"
                    value={shippingAddress.pincode}
                    onChange={(e) => setShippingAddress({ ...shippingAddress, pincode: e.target.value })}
                    className="w-full px-3 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 focus:border-emerald-500 focus:outline-none text-white text-sm"
                  />
                </div>
              </div>

              <div className="pt-3">
                <button
                  id="confirm-address-btn"
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20"
                >
                  <span>Proceed to Payment (₹{cartTotal})</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PAYMENT MODAL (Step 2 of checkout: QR Code or Razorpay) */}
      {checkoutStep === 'payment' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-lg bg-zinc-950 border border-emerald-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl my-8">
            <button
              type="button"
              onClick={() => setCheckoutStep('address')}
              className="absolute top-4 right-4 p-2 rounded-full bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="mb-5">
              <h3 className="text-xl font-black text-white">Payment Method</h3>
              <p className="text-xs text-zinc-400">Total payable for order: <strong className="text-emerald-400 text-sm">₹{cartTotal}</strong></p>
            </div>

            {/* Toggle Payment Option */}
            <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-zinc-900 border border-zinc-800 mb-5">
              <button
                type="button"
                onClick={() => setPaymentMethod('qr_upi')}
                className={`py-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                  paymentMethod === 'qr_upi'
                    ? 'bg-emerald-500 text-black shadow-md'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                <QrCode className="w-4 h-4" />
                <span>UPI QR Code</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod('razorpay')}
                className={`py-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                  paymentMethod === 'razorpay'
                    ? 'bg-emerald-500 text-black shadow-md'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                <CreditCard className="w-4 h-4" />
                <span>Razorpay Gateway</span>
              </button>
            </div>

            {paymentMethod === 'qr_upi' ? (
              <div className="space-y-4">
                {/* QR Code */}
                <div className="p-4 rounded-2xl bg-white flex flex-col items-center justify-center text-center shadow-lg">
                  <img
                    src={qrUrl}
                    alt="Payment QR"
                    className="w-44 h-44 object-contain rounded-lg"
                  />
                  <div className="mt-2 text-black">
                    <p className="text-xs font-bold">Scan with GPay, PhonePe, Paytm, BHIM</p>
                    <p className="text-xs text-zinc-600 font-mono mt-0.5">Amount: ₹{cartTotal}.00</p>
                  </div>
                </div>

                {/* UPI copy */}
                <div className="flex items-center justify-between p-3 rounded-xl bg-zinc-900 border border-zinc-800">
                  <div>
                    <div className="text-[10px] text-zinc-400 uppercase font-bold">UPI ID</div>
                    <div className="text-xs font-mono font-bold text-white">{upiId}</div>
                  </div>
                  <button
                    type="button"
                    onClick={handleCopyUpi}
                    className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-emerald-400 text-xs font-bold flex items-center gap-1.5"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>{copiedUpi ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>

                {/* UTR reference input */}
                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1.5">
                    Enter UPI Reference / UTR Number
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 423981092831"
                    value={transactionId}
                    onChange={(e) => setTransactionId(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 focus:border-emerald-500 focus:outline-none text-white text-sm"
                  />
                </div>

                <button
                  id="confirm-payment-order-btn"
                  type="button"
                  onClick={handleFinalizeOrder}
                  disabled={isProcessingOrder}
                  className="w-full py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 disabled:opacity-50"
                >
                  {isProcessingOrder ? (
                    <div className="w-5 h-5 rounded-full border-2 border-black border-t-transparent animate-spin" />
                  ) : (
                    <>
                      <span>I Have Paid ₹{cartTotal} via QR</span>
                      <Check className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="p-6 rounded-2xl bg-zinc-900 border border-zinc-800 text-center">
                  <div className="w-12 h-12 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center mx-auto mb-3">
                    <CreditCard className="w-6 h-6" />
                  </div>
                  <h4 className="text-base font-bold text-white">Razorpay Secure Checkout</h4>
                  <p className="text-xs text-zinc-400 mt-1">
                    Pay securely using Cards, NetBanking, UPI, or Wallets with instant payment confirmation.
                  </p>
                </div>

                <button
                  id="pay-razorpay-order-btn"
                  type="button"
                  onClick={handleRazorpayCheckout}
                  disabled={isProcessingOrder}
                  className="w-full py-3.5 rounded-xl bg-blue-500 hover:bg-blue-400 text-white font-extrabold text-sm flex items-center justify-center gap-2 transition-all disabled:opacity-50 shadow-lg shadow-blue-500/20"
                >
                  {isProcessingOrder ? (
                    <div className="w-5 h-5 rounded-full border-2 border-white border-t-transparent animate-spin" />
                  ) : (
                    <>
                      <span>Pay ₹{cartTotal} via Razorpay</span>
                      <Zap className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ORDER PLACED CONFIRMATION MODAL */}
      {checkoutStep === 'order_confirmed' && confirmedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-lg bg-zinc-950 border border-emerald-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl text-center my-8">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500 flex items-center justify-center mx-auto mb-4 animate-bounce">
              <Check className="w-8 h-8" />
            </div>

            <h3 className="text-2xl font-black text-white">Order Placed Successfully!</h3>
            <p className="text-xs text-emerald-400 font-mono font-bold mt-1">Order ID: {confirmedOrder.id}</p>
            <p className="text-xs text-zinc-400 mt-2 max-w-sm mx-auto">
              Thank you for ordering with Cal AI. Your order is confirmed and will be delivered by <strong className="text-white">{confirmedOrder.estimatedDelivery}</strong>.
            </p>

            {/* Delivery address snapshot */}
            <div className="mt-4 p-4 rounded-2xl bg-zinc-900/70 border border-zinc-800 text-left text-xs space-y-1">
              <div className="font-bold text-zinc-300">Delivering to:</div>
              <div className="text-zinc-400 font-medium">{confirmedOrder.shippingAddress.fullName} ({confirmedOrder.shippingAddress.phone})</div>
              <div className="text-zinc-500">{confirmedOrder.shippingAddress.streetAddress}, {confirmedOrder.shippingAddress.city} - {confirmedOrder.shippingAddress.pincode}</div>
            </div>

            <div className="grid grid-cols-2 gap-3 mt-6">
              <button
                type="button"
                onClick={() => {
                  setCheckoutStep('none');
                  if (onOpenMyOrders) onOpenMyOrders();
                }}
                className="py-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-white font-bold text-xs transition-colors flex items-center justify-center gap-1.5"
              >
                <Package className="w-4 h-4 text-emerald-400" />
                <span>Track My Order</span>
              </button>

              <button
                type="button"
                onClick={() => setCheckoutStep('none')}
                className="py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs shadow-lg shadow-emerald-500/20 transition-all"
              >
                Continue Shopping
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PRODUCT DETAILS MODAL */}
      {selectedProductDetails && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-lg bg-zinc-950 border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-2xl my-8">
            <button
              type="button"
              onClick={() => setSelectedProductDetails(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <img
              src={selectedProductDetails.image}
              alt={selectedProductDetails.name}
              className="w-full h-56 rounded-2xl object-cover bg-zinc-900 mb-4"
            />

            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xl font-black text-white">{selectedProductDetails.name}</h3>
              <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-bold">
                <Star className="w-3.5 h-3.5 fill-amber-300" />
                <span>{selectedProductDetails.rating}</span>
              </div>
            </div>

            <p className="text-xs text-zinc-400 mb-4 leading-relaxed">
              {selectedProductDetails.description}
            </p>

            {/* Nutrition info table if available */}
            {selectedProductDetails.nutritionInfo && (
              <div className="p-3.5 rounded-xl bg-zinc-900 border border-zinc-800 mb-4">
                <div className="text-xs font-bold text-zinc-300 mb-2">Nutrition Facts ({selectedProductDetails.nutritionInfo.servingSize})</div>
                <div className="grid grid-cols-4 gap-2 text-center text-xs">
                  <div className="p-2 rounded bg-zinc-950">
                    <div className="text-[10px] text-zinc-500">Calories</div>
                    <div className="font-bold text-emerald-400">{selectedProductDetails.nutritionInfo.calories}</div>
                  </div>
                  <div className="p-2 rounded bg-zinc-950">
                    <div className="text-[10px] text-zinc-500">Protein</div>
                    <div className="font-bold text-white">{selectedProductDetails.nutritionInfo.protein}g</div>
                  </div>
                  <div className="p-2 rounded bg-zinc-950">
                    <div className="text-[10px] text-zinc-500">Carbs</div>
                    <div className="font-bold text-white">{selectedProductDetails.nutritionInfo.carbs}g</div>
                  </div>
                  <div className="p-2 rounded bg-zinc-950">
                    <div className="text-[10px] text-zinc-500">Fats</div>
                    <div className="font-bold text-white">{selectedProductDetails.nutritionInfo.fats}g</div>
                  </div>
                </div>
              </div>
            )}

            <div className="flex items-center justify-between pt-3 border-t border-zinc-800">
              <div>
                <div className="text-xl font-black text-white">₹{selectedProductDetails.discountPrice}</div>
                <div className="text-xs text-zinc-500 line-through">₹{selectedProductDetails.price}</div>
              </div>

              <button
                type="button"
                onClick={() => {
                  handleAddToCart(selectedProductDetails);
                  setSelectedProductDetails(null);
                  setIsCartOpen(true);
                }}
                className="px-6 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-black text-xs flex items-center gap-2 shadow-lg shadow-emerald-500/20"
              >
                <Plus className="w-4 h-4" />
                <span>Add to Cart & Checkout</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
