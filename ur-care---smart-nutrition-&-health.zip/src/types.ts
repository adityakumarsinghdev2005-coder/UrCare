export type GoalType = 'lose_weight' | 'build_muscle' | 'maintain_tone' | 'improve_health' | 'reverse_condition';

export type GenderType = 'male' | 'female' | 'other';

export type ActivityLevel = 'sedentary' | 'lightly_active' | 'moderately_active' | 'very_active' | 'athlete';

export type GoalPace = 'slow' | 'steady' | 'moderate' | 'fast';

export interface UserHealthProfile {
  id?: string;
  name: string;
  email: string;
  gender: GenderType;
  age: number;
  heightCm: number;
  currentWeightKg: number;
  targetWeightKg: number;
  goal: GoalType;
  activityLevel: ActivityLevel;
  pace: GoalPace;
  obstacles: string[];
  dietaryPreference: string;
  medicalConditions: string[];
  reportAnalysis?: MedicalReportAnalysis;
  calculatedPlan: CalculatedPlan;
  prescriptions?: Prescription[];
  createdAt: string;
  updatedAt: string;
}

export interface Biomarker {
  name: string;
  value: string;
  status: 'normal' | 'low' | 'high' | 'critical';
  referenceRange: string;
  impactOnDiet: string;
}

export interface MedicalReportAnalysis {
  id?: string;
  userId?: string;
  userName?: string;
  reportName: string;
  uploadedAt: string;
  summary: string;
  biomarkers: Biomarker[];
  identifiedRisks: string[];
  dietaryRecommendations: string[];
  macroAdjustments: {
    proteinMultiplier?: number;
    carbAdjustment?: string;
    fatAdjustment?: string;
    keyNutrientsToBoost: string[];
    foodsToAvoid: string[];
  };
  adminReviewed?: boolean;
  adminNotes?: string;
}

export interface CalculatedPlan {
  bmr: number;
  tdee: number;
  targetCalories: number;
  proteinGrams: number;
  carbsGrams: number;
  fatsGrams: number;
  waterLiters: number;
  targetDate: string;
  weeklyChangeKg: number;
  healthScore: number;
  calorieDeficitOrSurplus: number;
}

export interface MealItem {
  id: string;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  fiber?: number;
  servingSize?: string;
  category: 'breakfast' | 'lunch' | 'dinner' | 'snack';
  timestamp: string;
  imageUrl?: string;
  confidence?: number;
}

export interface DailyLog {
  date: string;
  meals: MealItem[];
  waterMl: number;
  notes?: string;
}

export interface UserAccount {
  uid: string;
  email: string;
  displayName: string;
  authProvider: 'firebase' | 'email' | 'google';
  supabaseSynced: boolean;
  isPro?: boolean;
  proPlanType?: 'monthly' | 'yearly';
  proExpiry?: string;
  hasPurchasedProducts?: boolean;
  lastSyncedAt?: string;
}

// Product & Store Types
export interface Product {
  id: string;
  name: string;
  category: 'protein' | 'vitamins' | 'superfoods' | 'accessories' | 'snacks';
  price: number;
  discountPrice: number;
  rating: number;
  reviewsCount: number;
  image: string;
  description: string;
  benefits: string[];
  nutritionInfo?: {
    servingSize: string;
    calories: number;
    protein: number;
    carbs: number;
    fats: number;
  };
  inStock: boolean;
  featured?: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface ShippingAddress {
  fullName: string;
  phone: string;
  streetAddress: string;
  city: string;
  state: string;
  pincode: string;
}

export interface Order {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  items: CartItem[];
  shippingAddress: ShippingAddress;
  subtotal: number;
  discount: number;
  total: number;
  paymentMethod: 'qr_upi' | 'razorpay';
  paymentStatus: 'paid' | 'pending' | 'verified';
  orderStatus: 'confirmed' | 'processing' | 'shipped' | 'delivered';
  transactionId?: string;
  createdAt: string;
  estimatedDelivery: string;
}

// Prescription issued by Admin/Doctor based on lab report
export interface PrescriptionMedicine {
  name: string;
  dosage: string;
  frequency: string;
  duration: string;
  notes?: string;
}

export interface Prescription {
  id: string;
  userId: string;
  userName: string;
  reportId?: string;
  doctorName: string;
  date: string;
  diagnosis: string;
  medicines: PrescriptionMedicine[];
  recommendedSupplements: string[];
  dietaryAdjustments: string[];
  notes: string;
}

// Admin stats
export interface AdminStats {
  totalUsers: number;
  proUsers: number;
  freeUsers: number;
  totalBuyers: number;
  nonBuyers: number;
  totalReviews: number;
  totalRevenue: number;
  totalOrders: number;
  pendingReportsCount: number;
}

export interface UserReview {
  id: string;
  userId: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
  productId?: string;
  productName?: string;
  verified: boolean;
}

export interface DayRecommendation {
  date: string;
  dayLabel: 'yesterday' | 'today' | 'tomorrow' | 'custom';
  formattedDate: string;
  targetCalories: number;
  whatToEat: { title: string; desc: string; icon: string }[];
  whatToAvoid: { title: string; desc: string; icon: string }[];
  healthRisks: { risk: string; severity: 'low' | 'medium' | 'high'; note: string }[];
  preventions: { action: string; tip: string; timing: string }[];
}
