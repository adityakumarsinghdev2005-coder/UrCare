import React, { useState, useEffect } from 'react';
import { UserHealthProfile, UserAccount } from './types';
import { OnboardingFlow } from './components/OnboardingFlow';
import { WowCelebration } from './components/WowCelebration';
import { Dashboard } from './components/Dashboard';
import { AdminDashboard } from './components/AdminDashboard';

export default function App() {
  const [profile, setProfile] = useState<UserHealthProfile | null>(null);
  const [account, setAccount] = useState<UserAccount | null>(null);
  const [showWowCelebration, setShowWowCelebration] = useState(false);
  const [isAdminPortalOpen, setIsAdminPortalOpen] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);

  // Restore stored session if exists
  useEffect(() => {
    try {
      const storedProfile = localStorage.getItem('calai_user_profile');
      const storedAccount = localStorage.getItem('calai_user_account');
      if (storedProfile && storedAccount) {
        setProfile(JSON.parse(storedProfile));
        setAccount(JSON.parse(storedAccount));
      }
    } catch (e) {
      console.warn('Could not load local session:', e);
    } finally {
      setIsInitialized(true);
    }
  }, []);

  const handleOnboardingComplete = (completedProfile: UserHealthProfile, registeredAccount: UserAccount) => {
    setProfile(completedProfile);
    setAccount(registeredAccount);
    setShowWowCelebration(true);

    try {
      localStorage.setItem('calai_user_profile', JSON.stringify(completedProfile));
      localStorage.setItem('calai_user_account', JSON.stringify(registeredAccount));
    } catch (e) {
      console.warn('Could not save local session:', e);
    }
  };

  const handleUpdateProfile = (updatedProfile: UserHealthProfile) => {
    setProfile(updatedProfile);
    try {
      localStorage.setItem('calai_user_profile', JSON.stringify(updatedProfile));
    } catch (e) {
      console.warn('Could not save updated session:', e);
    }
  };

  const handleResetOnboarding = () => {
    setProfile(null);
    setAccount(null);
    setShowWowCelebration(false);
    try {
      localStorage.removeItem('calai_user_profile');
      localStorage.removeItem('calave_user_account');
      localStorage.removeItem('calai_user_account');
    } catch (e) {
      console.warn('Could not clear local session:', e);
    }
  };

  if (!isInitialized) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center text-emerald-400">
        <div className="w-8 h-8 rounded-full border-2 border-emerald-500 border-t-transparent animate-spin" />
      </div>
    );
  }

  // 1. If Admin Portal is opened
  if (isAdminPortalOpen) {
    return (
      <div className="min-h-screen bg-black selection:bg-emerald-500 selection:text-black">
        <AdminDashboard onExitAdmin={() => setIsAdminPortalOpen(false)} />
      </div>
    );
  }

  // 2. If user just completed onboarding, show the requested WOW celebration screen
  if (profile && account && showWowCelebration) {
    return (
      <div className="min-h-screen bg-black selection:bg-emerald-500 selection:text-black">
        <WowCelebration
          profile={profile}
          onEnterDashboard={() => setShowWowCelebration(false)}
        />
      </div>
    );
  }

  // 3. If user is logged in & onboarding complete, show Dashboard
  if (profile && account) {
    return (
      <div className="min-h-screen bg-black selection:bg-emerald-500 selection:text-black">
        <Dashboard
          profile={profile}
          account={account}
          onUpdateProfile={handleUpdateProfile}
          onResetOnboarding={handleResetOnboarding}
          onOpenAdminPortal={() => setIsAdminPortalOpen(true)}
        />
      </div>
    );
  }

  // 4. Otherwise show the Cal AI onboarding flow
  return (
    <div className="min-h-screen bg-black selection:bg-emerald-500 selection:text-black">
      <OnboardingFlow 
        onComplete={handleOnboardingComplete}
        onOpenAdmin={() => setIsAdminPortalOpen(true)}
      />
    </div>
  );
}
