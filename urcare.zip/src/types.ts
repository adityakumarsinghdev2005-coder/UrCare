export type GoalType = 'lose_weight' | 'build_muscle' | 'maintain_tone' | 'improve_health' | 'reverse_condition';

export type GenderType = 'male' | 'female' | 'other';

export type ActivityLevel = 'sedentary' | 'lightly_active' | 'moderately_active' | 'very_active' | 'athlete';

export type GoalPace = 'slow' | 'steady' | 'moderate' | 'fast';

export interface UserPreferences {
  enableNotifications: boolean;
  colorBurnsBack: boolean;
  rolloverCalories: boolean;
  workoutDaysPerWeek: '0-2' | '3-5' | '6+';
  heardFrom: string;
  triedOtherApps: boolean;
  worksWithTrainerOrDietitian: boolean;
  birthYear: number;
  birthMonth: number;
  birthDay: number;
  accomplishments: string[];
  referralCode?: string;
  customDietNote?: string;
  trialTier?: '3_day' | '7_day' | 'pro_annual' | 'free';
  autoPayEnabled?: boolean;
}

export interface UserHealthProfile {
  id?: string;
  name: string;
  email: string;
  phone?: string;
  gender: GenderType;
  age: number;
  heightCm: number;
  currentWeightKg: number;
  targetWeightKg: number;
  goal: GoalType;
  activityLevel: ActivityLevel;
  pace: GoalPace;
  obstacles: string[];
  dietaryPreference: string;
  medicalConditions: string[];
  reportAnalysis?: MedicalReportAnalysis;
  calculatedPlan: CalculatedPlan;
  prescriptions?: Prescription[];
  preferences?: UserPreferences;
  createdAt: string;
  updatedAt: string;
}

export interface Biomarker {
  name: string;
  value: string;
  status: 'normal' | 'low' | 'high' | 'critical';
  referenceRange: string;
  impactOnDiet: string;
}

export interface MedicalReportAnalysis {
  id?: string;
  userId?: string;
  userName?: string;
  reportName: string;
  uploadedAt: string;
  summary: string;
  biomarkers: Biomarker[];
  identifiedRisks: string[];
  dietaryRecommendations: string[];
  macroAdjustments: {
    proteinMultiplier?: number;
    carbAdjustment?: string;
    fatAdjustment?: string;
    keyNutrientsToBoost: string[];
    foodsToAvoid: string[];
  };
  adminReviewed?: boolean;
  adminNotes?: string;
}

export interface CalculatedPlan {
  bmr: number;
  tdee: number;
  targetCalories: number;
  proteinGrams: number;
  carbsGrams: number;
  fatsGrams: number;
  waterLiters: number;
  targetDate: string;
  weeklyChangeKg: number;
  healthScore: number;
  calorieDeficitOrSurplus: number;
  bmi?: number;
}

export interface MealItem {
  id: string;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  fiber?: number;
  servingSize?: string;
  category: 'breakfast' | 'lunch' | 'dinner' | 'snack';
  timestamp: string;
  imageUrl?: string;
  confidence?: number;
  aiSuggested?: boolean;
  completed?: boolean;
}

export interface BurnActivity {
  id: string;
  name: string;
  caloriesBurned: number;
  durationMinutes: number;
  timestamp: string;
  type: 'walk' | 'run' | 'gym' | 'cycling' | 'yoga' | 'sports' | 'custom';
  aiSuggested?: boolean;
  completed?: boolean;
}

export interface MedicationLogItem {
  id: string;
  name: string;
  dosage: string;
  frequency: string;
  timing: 'morning' | 'afternoon' | 'evening' | 'night';
  taken: boolean;
  takenAt?: string;
  prescribedBy?: string;
  notes?: string;
  aiSuggested?: boolean;
}

export interface DailyLog {
  date: string;
  meals: MealItem[];
  waterMl: number;
  burnedActivities: BurnActivity[];
  medications: MedicationLogItem[];
  notes?: string;
}

export interface FeedbackSubmission {
  id: string;
  userId: string;
  userName: string;
  dayCycleNumber: number; // e.g. Day 3 or Day 6
  energyRating: number; // 1 to 5
  digestionRating: number; // 1 to 5
  adherencePercentage: number; // e.g. 85
  satietyLevel: 'low' | 'optimal' | 'excessive';
  improvementSuggestions: string;
  createdAt: string;
}

export interface UserAccount {
  uid: string;
  email: string;
  displayName: string;
  phoneNumber?: string;
  authProvider: 'firebase' | 'email' | 'google';
  supabaseSynced: boolean;
  isPro?: boolean;
  proPlanType?: 'monthly' | 'yearly' | 'trial_7day' | 'trial_3day';
  proExpiry?: string;
  hasPurchasedProducts?: boolean;
  lastSyncedAt?: string;
}

// Product & Store Types
export interface Product {
  id: string;
  name: string;
  category: 'protein' | 'vitamins' | 'superfoods' | 'accessories' | 'snacks';
  price: number;
  discountPrice: number;
  rating: number;
  reviewsCount: number;
  image: string;
  description: string;
  benefits: string[];
  nutritionInfo?: {
    servingSize: string;
    calories: number;
    protein: number;
    carbs: number;
    fats: number;
  };
  inStock: boolean;
  featured?: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface ShippingAddress {
  fullName: string;
  phone: string;
  streetAddress: string;
  city: string;
  state: string;
  pincode: string;
}

export interface Order {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  items: CartItem[];
  shippingAddress: ShippingAddress;
  subtotal: number;
  discount: number;
  total: number;
  paymentMethod: 'qr_upi' | 'razorpay' | 'autopay' | 'trial_checkout' | 'card_netbanking';
  paymentStatus: 'paid' | 'pending' | 'verified';
  orderStatus: 'confirmed' | 'processing' | 'shipped' | 'delivered';
  transactionId?: string;
  receiptImageUrl?: string;
  receiptUploadedAt?: string;
  createdAt: string;
  estimatedDelivery: string;
}

export interface PrescriptionMedicine {
  name: string;
  dosage: string;
  frequency: string;
  duration: string;
  notes?: string;
}

export interface Prescription {
  id: string;
  userId: string;
  userName: string;
  reportId?: string;
  doctorName: string;
  doctorPhone?: string;
  date: string;
  diagnosis: string;
  medicines: PrescriptionMedicine[];
  recommendedSupplements: string[];
  dietaryAdjustments: string[];
  notes: string;
}

export interface DoctorContact {
  name: string;
  qualification: string;
  specialization: string;
  registrationNumber: string;
  phone: string;
  directDialNumber: string;
  availability: string;
  hospitalAffiliation: string;
}

export interface AdminStats {
  totalUsers: number;
  proUsers: number;
  freeUsers: number;
  totalBuyers: number;
  nonBuyers: number;
  totalReviews: number;
  totalRevenue: number;
  totalOrders: number;
  pendingReportsCount: number;
}

export interface UserReview {
  id: string;
  userId: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
  productId?: string;
  productName?: string;
  verified: boolean;
}

export interface DayRecommendation {
  date: string;
  dayLabel: 'today';
  formattedDate: string;
  targetCalories: number;
  whatToEat: { title: string; desc: string }[];
  whatToAvoid: { title: string; desc: string }[];
  healthRisks: { risk: string; severity: 'low' | 'medium' | 'high'; note: string }[];
  preventions: { action: string; tip: string; timing: string }[];
}
