import React, { useState } from 'react';
import { 
  Plus, Settings, 
  ChevronRight, Sparkles, Trash2, Calendar, ShieldCheck, Activity, 
  ShoppingBag, Lightbulb, Stethoscope, 
  Package, User, Check, PhoneCall, FileText, CheckCircle2,
  LogOut, MessageSquare, AlertCircle, LayoutGrid,
  Dna, Flame, Scale, Heart, Droplets, Target, UserCheck, Edit3, ChevronDown, ChevronUp
} from 'lucide-react';
import { 
  UserHealthProfile, MealItem, UserAccount, MedicalReportAnalysis, 
  Order, Prescription, BurnActivity, MedicationLogItem 
} from '../types';
import { DailyTracker } from './DailyTracker';
import { HealthReportModal } from './HealthReportModal';
import { SettingsModal } from './SettingsModal';
import { ProductsModule } from './ProductsModule';
import { RecommendationsView } from './RecommendationsView';
import { ProUpgradeModal } from './ProUpgradeModal';
import { MyOrdersModal } from './MyOrdersModal';
import { DoctorConsultModal } from './DoctorConsultModal';
import { ClinicalFeedbackModal } from './ClinicalFeedbackModal';
import { INITIAL_ORDERS, INITIAL_PRESCRIPTIONS } from '../data/mockAdminData';
import { Logo } from './Logo';
import { logoutFirebaseUser } from '../utils/firebase';

interface DashboardProps {
  profile: UserHealthProfile;
  account: UserAccount;
  onUpdateProfile: (updated: UserHealthProfile) => void;
  onResetOnboarding: () => void;
  onOpenAdminPortal?: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  profile,
  account,
  onUpdateProfile,
  onResetOnboarding,
  onOpenAdminPortal,
}) => {
  // Profile Section Expansion
  const [isProfileExpanded, setIsProfileExpanded] = useState<boolean>(true);

  // Navigation Tabs: 'daily' | 'recommendations' | 'store' | 'reports'
  const [activeTab, setActiveTab] = useState<'daily' | 'recommendations' | 'store' | 'reports'>('daily');

  // Daily target macros
  const targetCalories = profile.calculatedPlan?.targetCalories || 1850;
  const targetProtein = profile.calculatedPlan?.proteinGrams || 130;
  const targetCarbs = profile.calculatedPlan?.carbsGrams || 180;
  const targetFats = profile.calculatedPlan?.fatsGrams || 50;
  const targetWater = profile.calculatedPlan?.waterLiters || 3.2;

  // Initialized automatic meal plan
  const [meals, setMeals] = useState<MealItem[]>([
    {
      id: 'meal_1',
      name: 'High-Protein Oats with Almond Milk & Chia Seeds',
      calories: Math.round(targetCalories * 0.25),
      protein: Math.round(targetProtein * 0.25),
      carbs: Math.round(targetCarbs * 0.3),
      fats: Math.round(targetFats * 0.25),
      category: 'breakfast',
      timestamp: '08:30 AM',
      servingSize: '1 standard bowl (320g)',
      completed: true,
    },
    {
      id: 'meal_2',
      name: profile.dietaryPreference === 'Vegetarian' || profile.dietaryPreference === 'vegetarian'
        ? 'Sprouted Moong & Paneer Protein Bowl with Brown Rice'
        : 'Herbed Grilled Chicken Breast with Quinoa & Steamed Greens',
      calories: Math.round(targetCalories * 0.35),
      protein: Math.round(targetProtein * 0.38),
      carbs: Math.round(targetCarbs * 0.35),
      fats: Math.round(targetFats * 0.3),
      category: 'lunch',
      timestamp: '01:15 PM',
      servingSize: '1 clinical plate',
      completed: false,
    },
    {
      id: 'meal_3',
      name: 'Greek Yogurt Bowl with Crushed Walnuts & Blueberries',
      calories: Math.round(targetCalories * 0.15),
      protein: Math.round(targetProtein * 0.15),
      carbs: Math.round(targetCarbs * 0.15),
      fats: Math.round(targetFats * 0.2),
      category: 'snack',
      timestamp: '05:00 PM',
      servingSize: '1 bowl (180g)',
      completed: false,
    },
    {
      id: 'meal_4',
      name: profile.dietaryPreference === 'Vegetarian' || profile.dietaryPreference === 'vegetarian'
        ? 'Tofu & Broccoli Stir-fry with Garlic Infused Millet'
        : 'Pan-Seared Salmon Fillet with Asparagus & Sweet Potato Mash',
      calories: Math.round(targetCalories * 0.25),
      protein: Math.round(targetProtein * 0.22),
      carbs: Math.round(targetCarbs * 0.2),
      fats: Math.round(targetFats * 0.25),
      category: 'dinner',
      timestamp: '08:15 PM',
      servingSize: '1 dinner plate',
      completed: false,
    },
  ]);

  // Water tracking
  const [waterMl, setWaterMl] = useState<number>(1750);

  // Exercise and calories burned
  const [burnActivities, setBurnActivities] = useState<BurnActivity[]>([
    {
      id: 'burn_1',
      name: 'Morning Metabolic Cardio & Brisk Walk',
      caloriesBurned: 240,
      durationMinutes: 35,
      type: 'cardio',
      timestamp: '07:00 AM',
      completed: true,
    },
  ]);

  // Doctor Prescriptions
  const [prescriptions, setPrescriptions] = useState<Prescription[]>(INITIAL_PRESCRIPTIONS);

  // User Orders
  const [userOrders, setUserOrders] = useState<Order[]>(INITIAL_ORDERS);

  // Modals state
  const [isHealthReportOpen, setIsHealthReportOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isProUpgradeOpen, setIsProUpgradeOpen] = useState(false);
  const [proTriggerFeature, setProTriggerFeature] = useState('Pro Membership');
  const [isMyOrdersOpen, setIsMyOrdersOpen] = useState(false);
  const [isDoctorConsultOpen, setIsDoctorConsultOpen] = useState(false);
  const [doctorConsultReason, setDoctorConsultReason] = useState<string>('');
  const [isFeedbackOpen, setIsFeedbackOpen] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  // Handlers for meals
  const handleAddMeal = (meal: MealItem) => {
    setMeals((prev) => [meal, ...prev]);
  };

  const handleDeleteMeal = (id: string) => {
    setMeals((prev) => prev.filter((m) => m.id !== id));
  };

  const handleToggleMealCompleted = (id: string) => {
    setMeals((prev) =>
      prev.map((m) => (m.id === id ? { ...m, completed: !m.completed } : m))
    );
  };

  // Water Handlers
  const handleAddWater = (amount: number) => {
    setWaterMl((prev) => Math.min(prev + amount, Math.round(targetWater * 1000) + 1500));
  };

  const handleResetWater = () => {
    setWaterMl(0);
  };

  // Burn Handlers
  const handleAddBurnActivity = (act: BurnActivity) => {
    setBurnActivities((prev) => [act, ...prev]);
  };

  const handleDeleteBurnActivity = (id: string) => {
    setBurnActivities((prev) => prev.filter((b) => b.id !== id));
  };

  const handleToggleActivityCompleted = (id: string) => {
    setBurnActivities((prev) =>
      prev.map((b) => (b.id === id ? { ...b, completed: !b.completed } : b))
    );
  };

  // Store Order Placement
  const handleOrderPlaced = (newOrder: Order) => {
    setUserOrders((prev) => [newOrder, ...prev]);
  };

  const handleOpenProModalFor = (featureName: string) => {
    setProTriggerFeature(featureName);
    setIsProUpgradeOpen(true);
  };

  const handleUpdateReport = (newAnalysis: MedicalReportAnalysis) => {
    const updated = {
      ...profile,
      reportAnalysis: newAnalysis,
      updatedAt: new Date().toISOString(),
    };
    onUpdateProfile(updated);
  };

  const handleLogout = async () => {
    await logoutFirebaseUser();
    setShowLogoutConfirm(false);
    onResetOnboarding();
  };

  const handleOpenDoctorConsult = (reason?: string) => {
    setDoctorConsultReason(reason || 'Clinical consultation regarding metabolic diet and medical biomarkers.');
    setIsDoctorConsultOpen(true);
  };

  // Pure Light Mode Style Constants
  const cardClass = 'bg-white border border-zinc-200/90 shadow-sm';
  const subCardClass = 'bg-zinc-50 border border-zinc-200/80';
  const activeTabClass = 'bg-emerald-600 text-white font-black shadow-md shadow-emerald-600/20';
  const inactiveTabClass = 'text-zinc-600 hover:text-zinc-950 hover:bg-zinc-100';

  const navItems = [
    { id: 'daily', label: "Today's Log", icon: Activity },
    { id: 'recommendations', label: 'Diet & Protocols', icon: Lightbulb },
    { id: 'store', label: 'Clinical Store', icon: ShoppingBag },
    { id: 'reports', label: 'Lab Reports', icon: FileText },
  ];

  return (
    <div id="yourcare-dashboard-root" className="w-full min-h-screen bg-[#F8FAFC] text-zinc-900 pb-24 md:pb-12">
      
      {/* 1. STATIC SIDEBAR NAVIGATION (DESKTOP) */}
      <aside className="hidden md:flex flex-col justify-between w-64 fixed left-0 top-0 bottom-0 z-40 bg-white border-r border-zinc-200 p-5 shadow-xs">
        <div className="space-y-6">
          
          {/* Logo & Brand */}
          <div className="pb-4 border-b border-zinc-100">
            <Logo size="sm" showSubtitle={true} />
          </div>

          {/* User Quick Info */}
          <div className="p-3 rounded-2xl bg-emerald-50/60 border border-emerald-200/70 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-black text-sm shrink-0 shadow-sm">
              {profile.name ? profile.name.slice(0, 2).toUpperCase() : 'YC'}
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-black truncate text-zinc-950">{profile.name || 'Member'}</span>
                {account.isPro && (
                  <span className="text-[8px] font-black px-1.5 py-0.5 rounded bg-emerald-600 text-white uppercase">
                    PRO
                  </span>
                )}
              </div>
              <p className="text-[10px] text-zinc-500 truncate font-semibold">{profile.phone || profile.email || account.email}</p>
            </div>
          </div>

          {/* Main Navigation Tabs */}
          <nav className="space-y-1.5">
            {navItems.map((item) => {
              const ItemIcon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab(item.id as any)}
                  className={`w-full px-3.5 py-3 rounded-2xl text-xs font-black uppercase tracking-wider flex items-center gap-3 transition-all cursor-pointer ${
                    isActive ? activeTabClass : inactiveTabClass
                  }`}
                >
                  <ItemIcon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Direct Doctor Hotline Banner in Sidebar */}
          <div className="p-3.5 rounded-2xl bg-teal-50 border border-teal-200/80 text-teal-950 space-y-2">
            <div className="flex items-center gap-2">
              <Stethoscope className="w-4 h-4 text-teal-600" />
              <span className="text-[11px] font-black uppercase tracking-wider text-teal-900">Doctor Line</span>
            </div>
            <p className="text-[10px] text-teal-700 leading-tight font-medium">Board-certified clinical supervision available.</p>
            <button
              type="button"
              onClick={() => handleOpenDoctorConsult()}
              className="w-full py-1.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-black text-[10px] uppercase tracking-wider flex items-center justify-center gap-1 shadow-sm transition-all cursor-pointer"
            >
              <PhoneCall className="w-3 h-3" />
              <span>Call MD</span>
            </button>
          </div>

        </div>

        {/* Sidebar Footer Controls */}
        <div className="pt-4 border-t border-zinc-100 space-y-3">
          <div className="flex items-center justify-between">
            <button
              type="button"
              onClick={() => setIsMyOrdersOpen(true)}
              className="p-2.5 rounded-xl text-xs font-bold bg-zinc-100 text-zinc-700 hover:text-black hover:bg-zinc-200 border border-zinc-200 transition-all cursor-pointer"
              title="Orders & Receipts"
            >
              <Package className="w-4 h-4 text-emerald-600" />
            </button>

            <button
              type="button"
              onClick={() => setIsSettingsOpen(true)}
              className="p-2.5 rounded-xl text-xs font-bold bg-zinc-100 text-zinc-700 hover:text-black hover:bg-zinc-200 border border-zinc-200 transition-all cursor-pointer"
              title="Settings & Profile"
            >
              <Settings className="w-4 h-4 text-zinc-700" />
            </button>

            {onOpenAdminPortal && (
              <button
                type="button"
                onClick={onOpenAdminPortal}
                className="p-2.5 rounded-xl text-xs font-bold bg-zinc-100 text-zinc-700 hover:text-black hover:bg-zinc-200 border border-zinc-200 transition-all cursor-pointer"
                title="Admin Portal"
              >
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
              </button>
            )}

            <button
              type="button"
              onClick={() => setShowLogoutConfirm(true)}
              className="p-2.5 rounded-xl text-xs font-bold text-rose-600 hover:bg-rose-50 border border-rose-200 transition-all cursor-pointer"
              title="Sign Out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* 2. MOBILE TOP HEADER */}
      <header className="md:hidden sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-zinc-200 px-4 py-3 flex items-center justify-between">
        <Logo size="sm" showSubtitle={false} />
        
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setIsMyOrdersOpen(true)}
            className="p-2 rounded-xl text-xs font-bold bg-zinc-100 text-zinc-700 border border-zinc-200"
          >
            <Package className="w-4 h-4 text-emerald-600" />
          </button>

          <button
            type="button"
            onClick={() => setIsSettingsOpen(true)}
            className="p-2 rounded-xl text-xs font-bold bg-zinc-100 text-zinc-700 border border-zinc-200"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* 3. MOBILE BOTTOM NAVIGATION DOCK */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-zinc-200 px-2 py-1.5 flex items-center justify-around">
        {navItems.map((item) => {
          const ItemIcon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveTab(item.id as any)}
              className={`flex flex-col items-center gap-1 py-1.5 px-3 rounded-xl transition-all cursor-pointer ${
                isActive ? 'text-emerald-600 font-extrabold' : 'text-zinc-500 font-medium'
              }`}
            >
              <ItemIcon className="w-4 h-4" />
              <span className="text-[10px] tracking-tight">{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* 4. MAIN CONTENT CONTAINER (Desktop pl-64) */}
      <div className="md:pl-64 w-full">
        <main className="w-full max-w-6xl mx-auto px-4 sm:px-8 py-6">
        
        {/* ========================================================================= */}
        {/* EXECUTIVE PATIENT PROFILE SECTION (AT THE TOP OF DASHBOARD)               */}
        {/* ========================================================================= */}
        <section className={`p-5 sm:p-6 rounded-3xl ${cardClass} mb-6 space-y-4`}>
          <div className="flex items-center justify-between pb-3 border-b border-zinc-100">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 border border-emerald-200 flex items-center justify-center font-black text-base shrink-0 shadow-xs">
                {profile.name ? profile.name.slice(0, 2).toUpperCase() : 'YC'}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg sm:text-xl font-black text-zinc-950">
                    {profile.name || 'Your Care Member'}
                  </h2>
                  <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                    Verified Profile
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-500 mt-0.5 font-medium">
                  {profile.phone && <span>Phone: <strong className="font-mono text-zinc-700">{profile.phone}</strong></span>}
                  <span>•</span>
                  <span>{profile.gender || 'Not specified'}</span>
                  <span>•</span>
                  <span>{profile.age} Years Old</span>
                  <span>•</span>
                  <span>Goal: <strong className="text-emerald-600 uppercase font-black">{profile.goal?.replace('_', ' ')}</strong></span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsSettingsOpen(true)}
                className="px-3 py-1.5 rounded-xl bg-zinc-100 hover:bg-zinc-200 text-xs font-bold text-zinc-800 flex items-center gap-1.5 transition-all border border-zinc-200"
                title="Edit Health Parameters"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Edit Profile</span>
              </button>

              <button
                type="button"
                onClick={() => setIsProfileExpanded(!isProfileExpanded)}
                className="p-1.5 rounded-xl text-zinc-400 hover:text-zinc-800 hover:bg-zinc-100"
                title={isProfileExpanded ? 'Collapse Profile Details' : 'Expand Profile Details'}
              >
                {isProfileExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Expanded Profile Uploaded Data Grid */}
          {isProfileExpanded && (
            <div className="space-y-4 pt-1 animate-in fade-in duration-200">
              
              {/* Primary Biometrics Row */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className={`p-3.5 rounded-2xl ${subCardClass} space-y-1`}>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase text-zinc-400">Weight & Height</span>
                    <Scale className="w-3.5 h-3.5 text-emerald-600" />
                  </div>
                  <div className="text-sm font-black font-mono text-zinc-900">
                    {profile.currentWeightKg} kg <span className="text-zinc-500 text-xs font-normal">({profile.heightCm} cm)</span>
                  </div>
                  <div className="text-[11px] text-zinc-500">Target: {profile.targetWeightKg ? `${profile.targetWeightKg} kg` : 'Maintenance'}</div>
                </div>

                <div className={`p-3.5 rounded-2xl ${subCardClass} space-y-1`}>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase text-zinc-400">Calculated BMI</span>
                    <Activity className="w-3.5 h-3.5 text-blue-600" />
                  </div>
                  <div className="text-sm font-black font-mono text-emerald-600">
                    {Number((profile.currentWeightKg / Math.pow(profile.heightCm / 100, 2)).toFixed(1))} <span className="text-[10px] uppercase font-bold text-emerald-700">Optimal</span>
                  </div>
                  <div className="text-[11px] text-zinc-500">BMR: ~{profile.calculatedPlan?.bmr || 1650} kcal</div>
                </div>

                <div className={`p-3.5 rounded-2xl ${subCardClass} space-y-1`}>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase text-zinc-400">Daily Caloric Goal</span>
                    <Flame className="w-3.5 h-3.5 text-orange-500" />
                  </div>
                  <div className="text-sm font-black font-mono text-orange-600">
                    {targetCalories} <span className="text-xs text-zinc-500">kcal/day</span>
                  </div>
                  <div className="text-[11px] text-zinc-500">P: {targetProtein}g • C: {targetCarbs}g • F: {targetFats}g</div>
                </div>

                <div className={`p-3.5 rounded-2xl ${subCardClass} space-y-1`}>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase text-zinc-400">Diet & Hydration</span>
                    <Droplets className="w-3.5 h-3.5 text-teal-600" />
                  </div>
                  <div className="text-sm font-black capitalize text-zinc-900">
                    {profile.dietaryPreference || 'Balanced'}
                  </div>
                  <div className="text-[11px] text-zinc-500 font-mono">Water: {targetWater} L/day</div>
                </div>
              </div>

              {/* DNA Matrix Profile Section (If configured) */}
              {profile.dnaProfile && (
                <div className="p-3.5 rounded-2xl border bg-emerald-50/50 border-emerald-200 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-emerald-700">
                      <Dna className="w-4 h-4 text-emerald-600" />
                      <span className="text-xs font-black uppercase tracking-wider">DNA Matrix Genomic Phenotype</span>
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-300">
                      Synchronized
                    </span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                    <div>
                      <span className="text-[10px] text-zinc-500 uppercase block font-semibold">Carb Sensitivity</span>
                      <strong className="font-bold text-zinc-900 capitalize">{profile.dnaProfile.carbSensitivity}</strong>
                    </div>
                    <div>
                      <span className="text-[10px] text-zinc-500 uppercase block font-semibold">Lactose Tolerance</span>
                      <strong className="font-bold text-zinc-900 capitalize">{profile.dnaProfile.lactoseTolerance}</strong>
                    </div>
                    <div>
                      <span className="text-[10px] text-zinc-500 uppercase block font-semibold">Caffeine Oxidation</span>
                      <strong className="font-bold text-zinc-900 capitalize">{profile.dnaProfile.caffeineMetabolism}</strong>
                    </div>
                    <div>
                      <span className="text-[10px] text-zinc-500 uppercase block font-semibold">Methylation</span>
                      <strong className="font-bold text-zinc-900 capitalize">Standard Normal</strong>
                    </div>
                  </div>
                </div>
              )}

              {/* Medical Conditions & Blood Labs Badge */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-zinc-100 text-xs">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-zinc-500 font-semibold">Conditions Tracked:</span>
                  {profile.medicalConditions && profile.medicalConditions.length > 0 ? (
                    profile.medicalConditions.map((cond, idx) => (
                      <span key={idx} className="px-2 py-0.5 rounded-lg bg-zinc-100 text-zinc-800 font-bold text-[11px] border border-zinc-200">
                        {cond}
                      </span>
                    ))
                  ) : (
                    <span className="text-emerald-600 font-bold text-[11px]">None Reported (Healthy Baseline)</span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-zinc-500 text-[11px]">Lab Reports:</span>
                  {profile.reportAnalysis ? (
                    <span className="text-emerald-600 font-bold text-[11px] flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      <span>{profile.reportAnalysis.reportName}</span>
                    </span>
                  ) : (
                    <span className="text-zinc-400 text-[11px]">No Lab Attached</span>
                  )}
                </div>
              </div>

            </div>
          )}
        </section>

        {/* ========================================================================= */}
        {/* TAB VIEWS CONTENT                                                         */}
        {/* ========================================================================= */}

        {/* TAB 1: TODAY'S CLINICAL TRACKER */}
        {activeTab === 'daily' && (
          <DailyTracker
            profile={profile}
            account={account}
            meals={meals}
            waterMl={waterMl}
            burnActivities={burnActivities}
            prescriptions={prescriptions}
            onAddMeal={handleAddMeal}
            onDeleteMeal={handleDeleteMeal}
            onToggleMealCompleted={handleToggleMealCompleted}
            onAddWater={handleAddWater}
            onResetWater={handleResetWater}
            onAddBurnActivity={handleAddBurnActivity}
            onDeleteBurnActivity={handleDeleteBurnActivity}
            onToggleActivityCompleted={handleToggleActivityCompleted}
            onOpenConsultDoctor={handleOpenDoctorConsult}
            onOpenFeedbackModal={() => setIsFeedbackOpen(true)}
          />
        )}

        {/* TAB 2: RECOMMENDATIONS & DIET PROTOCOLS */}
        {activeTab === 'recommendations' && (
          <RecommendationsView
            profile={profile}
            prescriptions={prescriptions}
            onOpenStore={() => setActiveTab('store')}
            onOpenReportHub={() => setIsHealthReportOpen(true)}
            onOpenConsultDoctor={handleOpenDoctorConsult}
            onOpenProModal={handleOpenProModalFor}
          />
        )}

        {/* TAB 3: CLINICAL HEALTH STORE */}
        {activeTab === 'store' && (
          <ProductsModule
            account={account}
            onOrderPlaced={handleOrderPlaced}
            onOpenMyOrders={() => setIsMyOrdersOpen(true)}
          />
        )}

        {/* TAB 4: LAB REPORTS & BIOMARKERS */}
        {activeTab === 'reports' && (
          <div className="space-y-6 text-left">
            <div className={`p-6 rounded-3xl ${cardClass} flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4`}>
              <div>
                <div className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-emerald-600" />
                  <h3 className="text-xl font-black text-zinc-950">Biomarker & Blood Lab Analysis</h3>
                </div>
                <p className="text-xs text-zinc-500 mt-0.5">Upload lipid panels, HbA1c, Vitamin D3/B12 to recalibrate daily caloric & micronutrient targets.</p>
              </div>
              <button
                type="button"
                onClick={() => setIsHealthReportOpen(true)}
                className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md shadow-emerald-600/20 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Upload Lab PDF</span>
              </button>
            </div>

            {profile.reportAnalysis ? (
              <div className={`p-6 rounded-3xl ${cardClass} space-y-4`}>
                <div className="flex items-center justify-between pb-3 border-b border-zinc-100">
                  <div>
                    <h4 className="text-base font-extrabold text-zinc-950">{profile.reportAnalysis.reportName}</h4>
                    <span className="text-xs text-emerald-600 font-bold">Biomarkers Synchronized</span>
                  </div>
                  <span className="text-xs text-zinc-400">{profile.reportAnalysis.uploadedAt.split('T')[0]}</span>
                </div>
                <p className="text-xs text-zinc-600 leading-relaxed font-medium">{profile.reportAnalysis.summary}</p>
                
                {/* Biomarkers Table */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  {profile.reportAnalysis.biomarkers.map((b, idx) => (
                    <div key={idx} className={`p-3.5 rounded-2xl border ${subCardClass} text-xs space-y-1`}>
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-zinc-900">{b.name}</span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                          b.status === 'normal' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {b.status}
                        </span>
                      </div>
                      <div className="font-mono text-emerald-600 font-bold">{b.value} <span className="text-zinc-400 text-[10px]">({b.referenceRange})</span></div>
                      <p className="text-[11px] text-zinc-500">{b.impactOnDiet}</p>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className={`p-12 rounded-3xl ${cardClass} text-center space-y-2`}>
                <Stethoscope className="w-10 h-10 mx-auto text-emerald-600 opacity-60" />
                <p className="text-sm font-black text-zinc-900">No Diagnostic Reports Uploaded</p>
                <p className="text-xs max-w-sm mx-auto text-zinc-500">Upload a blood or lipid panel to receive personalized clinical dietary recommendations.</p>
              </div>
            )}
          </div>
        )}

      </main>
      </div>

      {/* MODALS */}
      {isHealthReportOpen && (
        <HealthReportModal
          isOpen={isHealthReportOpen}
          onClose={() => setIsHealthReportOpen(false)}
          onReportAnalyzed={(analysis) => {
            handleUpdateReport(analysis);
            setIsHealthReportOpen(false);
          }}
        />
      )}

      {isSettingsOpen && (
        <SettingsModal
          isOpen={isSettingsOpen}
          profile={profile}
          account={account}
          onClose={() => setIsSettingsOpen(false)}
          onUpdateProfile={onUpdateProfile}
          onResetOnboarding={onResetOnboarding}
          onOpenAdminPortal={onOpenAdminPortal}
        />
      )}

      {isProUpgradeOpen && (
        <ProUpgradeModal
          isOpen={isProUpgradeOpen}
          featureName={proTriggerFeature}
          onClose={() => setIsProUpgradeOpen(false)}
          onUpgradeSuccess={() => {
            setIsProUpgradeOpen(false);
          }}
        />
      )}

      {isMyOrdersOpen && (
        <MyOrdersModal
          isOpen={isMyOrdersOpen}
          onClose={() => setIsMyOrdersOpen(false)}
          orders={userOrders}
        />
      )}

      {isDoctorConsultOpen && (
        <DoctorConsultModal
          isOpen={isDoctorConsultOpen}
          onClose={() => setIsDoctorConsultOpen(false)}
          profile={profile}
          reason={doctorConsultReason}
        />
      )}

      {isFeedbackOpen && (
        <ClinicalFeedbackModal
          isOpen={isFeedbackOpen}
          onClose={() => setIsFeedbackOpen(false)}
          userId={account.uid || 'usr_active'}
          userName={profile.name || account.displayName || 'Valued Member'}
          dayCycleNumber={4}
        />
      )}

      {/* LOGOUT CONFIRMATION MODAL */}
      {showLogoutConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md animate-in fade-in">
          <div className={`w-full max-w-sm p-6 rounded-3xl ${cardClass} space-y-4 text-left`}>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center shrink-0 border border-rose-200">
                <AlertCircle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-black text-zinc-950">Sign Out</h3>
                <p className="text-xs text-zinc-500">Are you sure you want to log out of your session?</p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowLogoutConfirm(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-zinc-100 hover:bg-zinc-200 text-zinc-700 transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleLogout}
                className="px-4 py-2 rounded-xl text-xs font-black bg-rose-600 hover:bg-rose-500 text-white uppercase tracking-wider transition-colors shadow-sm"
              >
                Sign Out
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
