import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, Users, Crown, ShoppingBag, Star, FileText, 
  DollarSign, CheckCircle2, AlertTriangle, Eye, Plus, Send, 
  QrCode, Edit, ArrowRight, Lock, LogOut, Sparkles, Filter, 
  Truck, Check, Stethoscope, Search, ExternalLink, RefreshCw, Upload, X,
  Zap, ChevronRight, HelpCircle
} from 'lucide-react';
import { 
  AdminStats, MedicalReportAnalysis, Order, Prescription, 
  UserReview, Product, Biomarker 
} from '../types';
import { 
  INITIAL_ADMIN_STATS, INITIAL_USER_REPORTS_FOR_ADMIN, 
  INITIAL_PRESCRIPTIONS, INITIAL_REVIEWS, INITIAL_ORDERS 
} from '../data/mockAdminData';
import { INITIAL_PRODUCTS } from '../data/products';
import { Logo } from './Logo';

interface AdminDashboardProps {
  onExitAdmin: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onExitAdmin }) => {
  // Authentication State (Admin Only Barrier)
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  // Active Tab
  const [activeTab, setActiveTab] = useState<'overview' | 'reports' | 'orders' | 'products_qr' | 'reviews'>('overview');

  // Stats & Data
  const [stats, setStats] = useState<AdminStats>(INITIAL_ADMIN_STATS);
  const [reports, setReports] = useState<MedicalReportAnalysis[]>(INITIAL_USER_REPORTS_FOR_ADMIN);
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  const [prescriptions, setPrescriptions] = useState<Prescription[]>(INITIAL_PRESCRIPTIONS);
  const [reviews, setReviews] = useState<UserReview[]>(INITIAL_REVIEWS);
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);

  // QR Code Settings
  const [qrSettings, setQrSettings] = useState({
    qrImageUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=upi://pay?pa=yourcare.official@okhdfcbank&pn=Your%20Care%20Nutrition&mc=5411&cu=INR',
    upiId: 'yourcare.official@okhdfcbank',
    payeeName: 'Your Care Health & Nutrition Inc.',
    merchantNote: 'Scan & Pay via any UPI App (GPay, PhonePe, Paytm, BHIM)',
  });
  const [isUpdatingQr, setIsUpdatingQr] = useState(false);
  const [qrSuccessMessage, setQrSuccessMessage] = useState('');

  // Prescription modal state
  const [selectedReportForRx, setSelectedReportForRx] = useState<MedicalReportAnalysis | null>(null);
  const [rxDiagnosis, setRxDiagnosis] = useState('');
  const [rxMedicines, setRxMedicines] = useState<{ name: string; dosage: string; frequency: string; duration: string; notes: string }[]>([
    { name: '', dosage: '', frequency: '', duration: '', notes: '' }
  ]);
  const [rxSupplements, setRxSupplements] = useState<string>('Your Care 100% Pure Whey Isolate, Triple Strength Omega-3');
  const [rxNotes, setRxNotes] = useState('');
  const [isSubmittingRx, setIsSubmittingRx] = useState(false);

  // AI Scanning state
  const [isAiScanningReport, setIsAiScanningReport] = useState<string | null>(null);

  // Load latest from backend if available
  useEffect(() => {
    fetch('/api/admin/stats')
      .then((res) => res.json())
      .then((data) => {
        if (data && data.totalUsers) setStats((prev) => ({ ...prev, ...data }));
      })
      .catch(() => {});

    fetch('/api/admin/orders')
      .then((res) => res.json())
      .then((data) => {
        if (data && data.orders && data.orders.length > 0) setOrders(data.orders);
      })
      .catch(() => {});

    fetch('/api/admin/qr-settings')
      .then((res) => res.json())
      .then((data) => {
        if (data && data.qrImageUrl) setQrSettings(data);
      })
      .catch(() => {});
  }, []);

  const handleAdminLogin = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const emailNorm = adminEmail.trim().toLowerCase();
    const pass = adminPassword.trim();

    // Accepted admin emails and passwords
    const validEmails = ['admin@yourcare.app', 'admin@yourcare.com', 'admin@cal.ai', 'admin@urcare.com', 'admin'];
    const validPasswords = ['admin123', '8899', 'yourcare2025', 'admin', '123456'];

    if (
      validPasswords.includes(pass) ||
      (validEmails.includes(emailNorm) && (pass === 'admin123' || pass === '8899' || pass === 'admin')) ||
      emailNorm.includes('admin')
    ) {
      setIsAdminLoggedIn(true);
      setLoginError('');
    } else {
      setLoginError('Access restricted: Invalid admin credentials. Use admin@yourcare.app with password admin123 or PIN 8899.');
    }
  };

  const handle1ClickDemoLogin = () => {
    setAdminEmail('admin@yourcare.app');
    setAdminPassword('admin123');
    setIsAdminLoggedIn(true);
    setLoginError('');
  };

  const handleStatusChange = async (orderId: string, newStatus: 'confirmed' | 'processing' | 'shipped' | 'delivered') => {
    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, orderStatus: newStatus } : o))
    );
    try {
      await fetch(`/api/admin/orders/${orderId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderStatus: newStatus }),
      });
    } catch (e) {}
  };

  const handleScanReportWithAi = async (reportId: string) => {
    setIsAiScanningReport(reportId);
    try {
      const report = reports.find((r) => r.id === reportId);
      const res = await fetch('/api/analyze-report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          reportText: report?.summary || 'Comprehensive blood and lipid panel',
          reportType: report?.reportName || 'Blood Test',
        }),
      });
      const data = await res.json();
      setReports((prev) =>
        prev.map((r) =>
          r.id === reportId
            ? {
                ...r,
                summary: data.summary || r.summary,
                biomarkers: data.biomarkers || r.biomarkers,
                identifiedRisks: data.identifiedRisks || r.identifiedRisks,
                dietaryRecommendations: data.dietaryRecommendations || r.dietaryRecommendations,
              }
            : r
        )
      );
    } catch (e) {
      console.error(e);
    } finally {
      setIsAiScanningReport(null);
    }
  };

  const handleOpenRxModal = (report: MedicalReportAnalysis) => {
    setSelectedReportForRx(report);
    setRxDiagnosis(report.identifiedRisks?.join(', ') || 'Metabolic Optimization & Nutrient Support');
    setRxMedicines([
      { name: 'Ferrous Ascorbate + Folic Acid', dosage: '100mg', frequency: 'Once daily after lunch', duration: '30 Days', notes: 'Take with lemon water for high absorption' },
      { name: 'Vitamin D3 Cholecalciferol', dosage: '60,000 IU', frequency: 'Once weekly for 8 weeks', duration: '8 Weeks', notes: 'Supports bone density and metabolism' },
    ]);
    setRxNotes('Patient advised to follow daily protein target and take omega-3 supplements.');
  };

  const handleAddMedicineRow = () => {
    setRxMedicines((prev) => [...prev, { name: '', dosage: '', frequency: '', duration: '', notes: '' }]);
  };

  const handleRemoveMedicineRow = (index: number) => {
    setRxMedicines((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmitPrescription = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedReportForRx) return;
    setIsSubmittingRx(true);
    try {
      const rxPayload = {
        userId: selectedReportForRx.userId,
        userName: selectedReportForRx.userName,
        reportId: selectedReportForRx.id,
        doctorName: 'Dr. Arjun Mehta, MD Clinical Nutrition',
        diagnosis: rxDiagnosis,
        medicines: rxMedicines.filter((m) => m.name.trim() !== ''),
        recommendedSupplements: rxSupplements.split(',').map((s) => s.trim()),
        dietaryAdjustments: selectedReportForRx.dietaryRecommendations || [],
        notes: rxNotes,
      };

      const res = await fetch('/api/admin/prescribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(rxPayload),
      });
      const data = await res.json();

      setPrescriptions((prev) => [data.prescription, ...prev]);
      setReports((prev) =>
        prev.map((r) => (r.id === selectedReportForRx.id ? { ...r, adminReviewed: true, adminNotes: rxNotes } : r))
      );

      setSelectedReportForRx(null);
    } catch (e) {
      console.error(e);
    } finally {
      setIsSubmittingRx(false);
    }
  };

  const handleSaveQrSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsUpdatingQr(true);
    try {
      await fetch('/api/admin/qr-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(qrSettings),
      });
      setQrSuccessMessage('Payment QR Code updated successfully!');
      setTimeout(() => setQrSuccessMessage(''), 3000);
    } catch (e) {
      console.error(e);
    } finally {
      setIsUpdatingQr(false);
    }
  };

  // Pure Light Mode Style Constants
  const cardClass = 'bg-white border border-zinc-200/90 shadow-sm';
  const subCardClass = 'bg-zinc-50 border border-zinc-200/80';

  // 1. ADMIN LOGIN BARRIER
  if (!isAdminLoggedIn) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-white border border-zinc-200 rounded-3xl p-8 shadow-xl space-y-6 text-left relative overflow-hidden">
          
          {/* Top Emerald Ribbon */}
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600" />

          <div className="text-center space-y-2">
            <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-emerald-600 border border-emerald-200 flex items-center justify-center mx-auto shadow-xs">
              <ShieldCheck className="w-7 h-7" />
            </div>
            <h2 className="text-2xl font-black text-zinc-950">Your Care Admin Portal</h2>
            <p className="text-xs text-zinc-500">
              Restricted medical supervision and operations console for doctors, clinical staff & platform administrators.
            </p>
          </div>

          {/* Quick Access Credentials Banner */}
          <div className="p-3.5 rounded-2xl bg-emerald-50/70 border border-emerald-200/80 space-y-1.5 text-xs">
            <div className="flex items-center gap-1.5 text-emerald-900 font-extrabold text-[11px] uppercase tracking-wider">
              <Zap className="w-3.5 h-3.5 text-emerald-600" />
              <span>Admin Access Credentials</span>
            </div>
            <div className="text-[11px] text-zinc-700 space-y-0.5 font-medium">
              <div>Email: <strong className="font-mono text-emerald-700">admin@yourcare.app</strong></div>
              <div>Password: <strong className="font-mono text-emerald-700">admin123</strong> or PIN: <strong className="font-mono text-emerald-700">8899</strong></div>
            </div>
          </div>

          <form onSubmit={handleAdminLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-zinc-700 mb-1">Admin Email</label>
              <input
                type="email"
                required
                placeholder="admin@yourcare.app"
                value={adminEmail}
                onChange={(e) => setAdminEmail(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-zinc-50 border border-zinc-200 focus:border-emerald-600 focus:bg-white focus:outline-none text-zinc-900 text-xs font-medium transition-all"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-700 mb-1">Password or Admin PIN</label>
              <input
                type="password"
                required
                placeholder="admin123 or 8899"
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-zinc-50 border border-zinc-200 focus:border-emerald-600 focus:bg-white focus:outline-none text-zinc-900 text-xs font-medium transition-all"
              />
            </div>

            {loginError && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{loginError}</span>
              </div>
            )}

            {/* Direct Login Button */}
            <button
              id="admin-login-btn"
              type="submit"
              className="w-full py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 active:scale-98 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/25 transition-all cursor-pointer"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Login to Admin Dashboard</span>
            </button>

            {/* 1-Click Instant Demo Login */}
            <button
              type="button"
              onClick={handle1ClickDemoLogin}
              className="w-full py-2.5 rounded-xl bg-emerald-50 hover:bg-emerald-100/80 border border-emerald-200 text-emerald-800 text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
            >
              <Zap className="w-3.5 h-3.5 text-emerald-600" />
              <span>1-Click Instant Demo Admin Access</span>
            </button>

            <button
              type="button"
              onClick={onExitAdmin}
              className="w-full py-2.5 rounded-xl bg-zinc-100 hover:bg-zinc-200 text-zinc-600 text-xs font-bold transition-colors cursor-pointer"
            >
              Return to User App
            </button>
          </form>

        </div>
      </div>
    );
  }

  // 2. ADMIN DASHBOARD CONTENT (LIGHT THEME)
  return (
    <div id="yourcare-admin-dashboard" className="min-h-screen bg-[#F8FAFC] text-zinc-900 pb-16">
      
      {/* Top Navbar */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-zinc-200 px-4 sm:px-8 py-3.5 shadow-xs">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-600 border border-emerald-200 flex items-center justify-center shadow-xs">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-base font-black text-zinc-950">Your Care Admin</span>
                <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                  SUPER ADMIN
                </span>
              </div>
              <p className="text-[10px] text-zinc-500 font-medium">Dr. Arjun Mehta & Clinical Operations Portal</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsAdminLoggedIn(false)}
              className="px-3 py-1.5 rounded-xl bg-zinc-100 hover:bg-zinc-200 border border-zinc-200 text-zinc-600 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Sign Out</span>
            </button>

            <button
              type="button"
              onClick={onExitAdmin}
              className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black uppercase tracking-wider shadow-sm transition-all cursor-pointer"
            >
              Back to User App
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-6 space-y-6">
        
        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 border-b border-zinc-200">
          <button
            type="button"
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2.5 rounded-2xl text-xs font-black uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'overview' ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20' : 'text-zinc-600 hover:text-zinc-950 hover:bg-zinc-100'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Platform Overview</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('reports')}
            className={`px-4 py-2.5 rounded-2xl text-xs font-black uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'reports' ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20' : 'text-zinc-600 hover:text-zinc-950 hover:bg-zinc-100'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Medical Reports & Prescriptions ({reports.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('orders')}
            className={`px-4 py-2.5 rounded-2xl text-xs font-black uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'orders' ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20' : 'text-zinc-600 hover:text-zinc-950 hover:bg-zinc-100'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Store Orders ({orders.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('products_qr')}
            className={`px-4 py-2.5 rounded-2xl text-xs font-black uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'products_qr' ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20' : 'text-zinc-600 hover:text-zinc-950 hover:bg-zinc-100'
            }`}
          >
            <QrCode className="w-4 h-4" />
            <span>Payment QR & Merchandising</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('reviews')}
            className={`px-4 py-2.5 rounded-2xl text-xs font-black uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'reviews' ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20' : 'text-zinc-600 hover:text-zinc-950 hover:bg-zinc-100'
            }`}
          >
            <Star className="w-4 h-4" />
            <span>Reviews ({stats.totalReviews})</span>
          </button>
        </div>

        {/* TAB 1: OVERVIEW METRICS */}
        {activeTab === 'overview' && (
          <div className="space-y-6 text-left">
            
            {/* Stat Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              
              {/* Total Users */}
              <div className={`p-5 rounded-3xl ${cardClass} space-y-1.5`}>
                <div className="flex items-center justify-between text-zinc-500">
                  <span className="text-xs font-bold uppercase tracking-wider">Total Registered Users</span>
                  <Users className="w-4 h-4 text-emerald-600" />
                </div>
                <div className="text-2xl sm:text-3xl font-black font-mono text-zinc-950">{stats.totalUsers.toLocaleString()}</div>
                <div className="text-[11px] text-emerald-600 font-bold flex items-center gap-1">
                  <span>+128 verified this week</span>
                </div>
              </div>

              {/* Pro Subscriptions vs Free */}
              <div className={`p-5 rounded-3xl ${cardClass} space-y-1.5`}>
                <div className="flex items-center justify-between text-zinc-500">
                  <span className="text-xs font-bold uppercase tracking-wider">Pro Members</span>
                  <Crown className="w-4 h-4 text-amber-500" />
                </div>
                <div className="text-2xl sm:text-3xl font-black font-mono text-amber-600">{stats.proUsers.toLocaleString()}</div>
                <div className="text-[11px] text-zinc-500">
                  {stats.freeUsers.toLocaleString()} Free ({(stats.totalUsers > 0 ? (stats.proUsers / stats.totalUsers) * 100 : 0).toFixed(1)}% Conversion)
                </div>
              </div>

              {/* Product Buyers vs Non-Buyers */}
              <div className={`p-5 rounded-3xl ${cardClass} space-y-1.5`}>
                <div className="flex items-center justify-between text-zinc-500">
                  <span className="text-xs font-bold uppercase tracking-wider">Store Buyers</span>
                  <ShoppingBag className="w-4 h-4 text-emerald-600" />
                </div>
                <div className="text-2xl sm:text-3xl font-black font-mono text-zinc-950">{stats.totalBuyers.toLocaleString()}</div>
                <div className="text-[11px] text-zinc-500">
                  {stats.nonBuyers.toLocaleString()} Non-buyers ({(stats.totalUsers > 0 ? (stats.totalBuyers / stats.totalUsers) * 100 : 0).toFixed(1)}% Checkout Rate)
                </div>
              </div>

              {/* Total Revenue */}
              <div className={`p-5 rounded-3xl ${cardClass} space-y-1.5`}>
                <div className="flex items-center justify-between text-zinc-500">
                  <span className="text-xs font-bold uppercase tracking-wider">Gross Platform Revenue</span>
                  <DollarSign className="w-4 h-4 text-emerald-600" />
                </div>
                <div className="text-2xl sm:text-3xl font-black font-mono text-emerald-600">₹{((stats.totalRevenue || 0) / 100000).toFixed(2)} Lakhs</div>
                <div className="text-[11px] text-zinc-500 font-medium">{stats.totalOrders} Fulfilled Orders</div>
              </div>
            </div>

            {/* Visual Breakdown Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Subscription Breakdown */}
              <div className={`p-6 rounded-3xl ${cardClass} space-y-4`}>
                <h3 className="text-base font-black text-zinc-950">Subscription Status Breakdown</h3>
                
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between text-xs mb-1.5 font-bold">
                      <span className="text-amber-600">Pro Subscriptions (Active Paid)</span>
                      <span className="text-zinc-950">{stats.proUsers} users</span>
                    </div>
                    <div className="w-full h-3 rounded-full bg-zinc-100 overflow-hidden border border-zinc-200">
                      <div 
                        className="h-full bg-gradient-to-r from-amber-500 to-emerald-500 rounded-full" 
                        style={{ width: `${(stats.proUsers / stats.totalUsers) * 100}%` }}
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs mb-1.5 font-bold">
                      <span className="text-zinc-500">Free Baseline Users</span>
                      <span className="text-zinc-950">{stats.freeUsers} users</span>
                    </div>
                    <div className="w-full h-3 rounded-full bg-zinc-100 overflow-hidden border border-zinc-200">
                      <div 
                        className="h-full bg-zinc-400 rounded-full" 
                        style={{ width: `${(stats.freeUsers / stats.totalUsers) * 100}%` }}
                      />
                    </div>
                  </div>
                </div>

                <div className={`p-4 rounded-2xl ${subCardClass} text-xs text-zinc-600 flex items-center justify-between font-medium`}>
                  <span>Pro users log 4.8x more daily meals and order 3x more clinical supplements.</span>
                </div>
              </div>

              {/* E-commerce Buyer Conversion */}
              <div className={`p-6 rounded-3xl ${cardClass} space-y-4`}>
                <h3 className="text-base font-black text-zinc-950">Product Purchasing Conversion</h3>
                
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between text-xs mb-1.5 font-bold">
                      <span className="text-emerald-600">Purchased Products (Buyers)</span>
                      <span className="text-zinc-950">{stats.totalBuyers} users</span>
                    </div>
                    <div className="w-full h-3 rounded-full bg-zinc-100 overflow-hidden border border-zinc-200">
                      <div 
                        className="h-full bg-emerald-600 rounded-full" 
                        style={{ width: `${(stats.totalBuyers / stats.totalUsers) * 100}%` }}
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs mb-1.5 font-bold">
                      <span className="text-zinc-500">Browsed Store (Prospects)</span>
                      <span className="text-zinc-950">{stats.nonBuyers} users</span>
                    </div>
                    <div className="w-full h-3 rounded-full bg-zinc-100 overflow-hidden border border-zinc-200">
                      <div 
                        className="h-full bg-zinc-400 rounded-full" 
                        style={{ width: `${(stats.nonBuyers / stats.totalUsers) * 100}%` }}
                      />
                    </div>
                  </div>
                </div>

                <div className={`p-4 rounded-2xl ${subCardClass} text-xs text-zinc-600 flex items-center justify-between font-medium`}>
                  <span>Top Product: Your Care 100% Pure Whey Isolate (42% of all order volume).</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: MEDICAL REPORTS & AI PRESCRIBE */}
        {activeTab === 'reports' && (
          <div className="space-y-6 text-left">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-black text-zinc-950">User Lab Reports & Clinical Prescriptions</h3>
                <p className="text-xs text-zinc-500">Review blood/lipid diagnostic tests, run Gemini AI biomarker analysis, and issue official prescriptions.</p>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {reports.map((report) => (
                <div 
                  key={report.id}
                  className={`p-6 rounded-3xl ${cardClass} space-y-4`}
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-zinc-100">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-base font-extrabold text-zinc-950">{report.userName}</span>
                        <span className="text-xs text-zinc-400 font-mono">({report.userId})</span>
                        {report.adminReviewed ? (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black uppercase border border-emerald-200">
                            Prescribed & Reviewed
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10px] font-black uppercase border border-amber-200">
                            Pending Doctor Review
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-zinc-500 mt-0.5">{report.reportName} • Uploaded {new Date(report.uploadedAt).toLocaleDateString('en-IN')}</p>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleScanReportWithAi(report.id!)}
                        disabled={isAiScanningReport === report.id}
                        className="px-3.5 py-2 rounded-xl bg-zinc-100 hover:bg-zinc-200 border border-zinc-200 text-emerald-700 text-xs font-bold flex items-center gap-1.5 transition-colors disabled:opacity-50 cursor-pointer"
                      >
                        {isAiScanningReport === report.id ? (
                          <div className="w-3.5 h-3.5 rounded-full border-2 border-emerald-600 border-t-transparent animate-spin" />
                        ) : (
                          <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                        )}
                        <span>Scan with AI</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleOpenRxModal(report)}
                        className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black uppercase tracking-wider flex items-center gap-1.5 shadow-md shadow-emerald-600/20 cursor-pointer"
                      >
                        <Stethoscope className="w-3.5 h-3.5" />
                        <span>Issue Prescription</span>
                      </button>
                    </div>
                  </div>

                  {/* Summary & Biomarkers */}
                  <div className="space-y-3">
                    <p className={`text-xs text-zinc-700 leading-relaxed ${subCardClass} p-3 rounded-2xl font-medium`}>
                      <strong className="text-zinc-950">Clinical Summary:</strong> {report.summary}
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
                      {report.biomarkers.map((b, i) => (
                        <div key={i} className={`p-3 rounded-2xl ${subCardClass} text-xs space-y-1`}>
                          <div className="flex justify-between items-center">
                            <span className="font-bold text-zinc-900 line-clamp-1">{b.name}</span>
                            <span className={`text-[10px] font-black uppercase px-1.5 py-0.5 rounded ${
                              b.status === 'high' ? 'bg-rose-100 text-rose-800' : b.status === 'low' ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'
                            }`}>
                              {b.status}
                            </span>
                          </div>
                          <div className="text-sm font-black font-mono text-emerald-600">{b.value}</div>
                          <div className="text-[10px] text-zinc-500 mt-0.5">{b.impactOnDiet}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: CUSTOMER ORDERS */}
        {activeTab === 'orders' && (
          <div className="space-y-6 text-left">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-black text-zinc-950">Store Order Fulfillment</h3>
                <p className="text-xs text-zinc-500">Track user supplement purchases, verify UPI QR payments, and manage shipment dispatch.</p>
              </div>
            </div>

            <div className="space-y-3">
              {orders.map((order) => (
                <div 
                  key={order.id}
                  className={`p-5 rounded-3xl ${cardClass} space-y-3`}
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <span className="text-xs font-mono font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-200">{order.id}</span>
                      <span className="text-sm font-bold text-zinc-950 ml-2">{order.shippingAddress?.fullName}</span>
                      <span className="text-xs text-zinc-500 ml-2">({order.shippingAddress?.phone})</span>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="text-sm font-black text-zinc-900">₹{order.total}</span>
                      <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-zinc-100 text-zinc-700 font-bold border border-zinc-200 capitalize">
                        {order.paymentMethod === 'qr_upi' ? 'UPI QR' : 'Online Gateway'}
                      </span>

                      {/* Status Selector */}
                      <select
                        value={order.orderStatus}
                        onChange={(e) => handleStatusChange(order.id, e.target.value as any)}
                        className="px-3 py-1.5 rounded-xl bg-zinc-50 border border-zinc-200 text-xs font-bold text-emerald-700 focus:outline-none cursor-pointer"
                      >
                        <option value="confirmed">Confirmed</option>
                        <option value="processing">Processing</option>
                        <option value="shipped">Shipped (In Transit)</option>
                        <option value="delivered">Delivered</option>
                      </select>
                    </div>
                  </div>

                  {/* Items */}
                  <div className="text-xs text-zinc-600 space-y-1">
                    {order.items.map((item, idx) => (
                      <div key={idx} className="flex justify-between font-medium">
                        <span>{item.quantity}x {item.product?.name}</span>
                        <span className="text-zinc-900 font-bold">₹{(item.product?.discountPrice || item.product?.price || 0) * item.quantity}</span>
                      </div>
                    ))}
                  </div>

                  {/* Address */}
                  <div className="text-[11px] text-zinc-500 pt-2 border-t border-zinc-100">
                    Ship to: {order.shippingAddress?.streetAddress}, {order.shippingAddress?.city} - {order.shippingAddress?.pincode}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: PAYMENT QR & PRODUCTS SETTINGS */}
        {activeTab === 'products_qr' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
            
            {/* QR Code Config */}
            <div className={`p-6 rounded-3xl ${cardClass} space-y-4`}>
              <div className="flex items-center gap-2">
                <QrCode className="w-5 h-5 text-emerald-600" />
                <h3 className="text-base font-black text-zinc-950">Payment QR Code Settings</h3>
              </div>
              <p className="text-xs text-zinc-500">
                Update the official UPI QR code and merchant details shown to patients during store checkout.
              </p>

              <form onSubmit={handleSaveQrSettings} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-zinc-700 mb-1">QR Code Image URL</label>
                  <input
                    type="url"
                    required
                    value={qrSettings.qrImageUrl}
                    onChange={(e) => setQrSettings({ ...qrSettings, qrImageUrl: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl bg-zinc-50 border border-zinc-200 text-zinc-900 text-xs font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-700 mb-1">UPI ID (VPA)</label>
                  <input
                    type="text"
                    required
                    value={qrSettings.upiId}
                    onChange={(e) => setQrSettings({ ...qrSettings, upiId: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl bg-zinc-50 border border-zinc-200 text-zinc-900 text-xs font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-700 mb-1">Payee Name</label>
                  <input
                    type="text"
                    required
                    value={qrSettings.payeeName}
                    onChange={(e) => setQrSettings({ ...qrSettings, payeeName: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl bg-zinc-50 border border-zinc-200 text-zinc-900 text-xs font-medium"
                  />
                </div>

                {qrSuccessMessage && (
                  <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center gap-1.5">
                    <Check className="w-4 h-4 text-emerald-600" />
                    <span>{qrSuccessMessage}</span>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isUpdatingQr}
                  className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs uppercase tracking-wider shadow-md shadow-emerald-600/20 cursor-pointer"
                >
                  Save QR Settings
                </button>
              </form>
            </div>

            {/* QR Live Preview */}
            <div className={`p-6 rounded-3xl ${cardClass} flex flex-col items-center justify-center text-center space-y-3`}>
              <h4 className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Live Checkout QR Preview</h4>
              <div className="p-4 rounded-2xl bg-white border border-zinc-200 shadow-lg">
                <img
                  src={qrSettings.qrImageUrl}
                  alt="QR Preview"
                  className="w-48 h-48 object-contain"
                />
              </div>
              <div className="text-xs text-zinc-900 font-mono font-black">{qrSettings.upiId}</div>
              <p className="text-[11px] text-zinc-500 font-medium">{qrSettings.payeeName}</p>
            </div>
          </div>
        )}

        {/* TAB 5: REVIEWS */}
        {activeTab === 'reviews' && (
          <div className="space-y-6 text-left">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-black text-zinc-950">Patient Reviews & Testimonials ({reviews.length})</h3>
                <p className="text-xs text-zinc-500">Verified reviews from clinic patients and dietary supplement purchasers.</p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {reviews.map((rev) => (
                <div key={rev.id} className={`p-5 rounded-3xl ${cardClass} space-y-2.5`}>
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-zinc-950 text-sm">{rev.userName}</span>
                    <div className="flex items-center gap-1 text-amber-500">
                      {[...Array(rev.rating)].map((_, i) => (
                        <Star key={i} className="w-3.5 h-3.5 fill-amber-500" />
                      ))}
                    </div>
                  </div>
                  <p className="text-xs text-zinc-600 leading-relaxed italic font-medium">"{rev.comment}"</p>
                  <div className="text-[11px] text-emerald-700 font-bold pt-2 border-t border-zinc-100">
                    Product: {rev.productName} • {rev.date}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* DOCTOR PRESCRIPTION MODAL */}
      {selectedReportForRx && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-white border border-zinc-200 rounded-3xl p-6 sm:p-8 shadow-2xl my-8 text-left space-y-4">
            <div className="flex items-center justify-between pb-4 border-b border-zinc-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-600 border border-emerald-200 flex items-center justify-center">
                  <Stethoscope className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-zinc-950">Issue Clinical Prescription</h3>
                  <p className="text-xs text-zinc-500">Patient: <strong className="text-zinc-900">{selectedReportForRx.userName}</strong> ({selectedReportForRx.reportName})</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedReportForRx(null)}
                className="p-2 rounded-xl bg-zinc-100 hover:bg-zinc-200 text-zinc-500 hover:text-zinc-900"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitPrescription} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-zinc-700 mb-1">Clinical Diagnosis</label>
                <input
                  type="text"
                  required
                  value={rxDiagnosis}
                  onChange={(e) => setRxDiagnosis(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-zinc-50 border border-zinc-200 text-zinc-900 text-xs font-medium"
                />
              </div>

              {/* Medicine rows */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-zinc-700">Prescribed Pharmaceuticals & Dosages</label>
                  <button
                    type="button"
                    onClick={handleAddMedicineRow}
                    className="text-xs text-emerald-600 font-bold hover:underline flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Medicine</span>
                  </button>
                </div>

                {rxMedicines.map((med, idx) => (
                  <div key={idx} className={`p-3 rounded-2xl ${subCardClass} space-y-2`}>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      <input
                        type="text"
                        placeholder="Medicine name"
                        value={med.name}
                        onChange={(e) => {
                          const updated = [...rxMedicines];
                          updated[idx].name = e.target.value;
                          setRxMedicines(updated);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-white border border-zinc-200 text-zinc-900 text-xs"
                      />
                      <input
                        type="text"
                        placeholder="Dosage (e.g. 100mg)"
                        value={med.dosage}
                        onChange={(e) => {
                          const updated = [...rxMedicines];
                          updated[idx].dosage = e.target.value;
                          setRxMedicines(updated);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-white border border-zinc-200 text-zinc-900 text-xs"
                      />
                      <input
                        type="text"
                        placeholder="Frequency (e.g. 1-0-1)"
                        value={med.frequency}
                        onChange={(e) => {
                          const updated = [...rxMedicines];
                          updated[idx].frequency = e.target.value;
                          setRxMedicines(updated);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-white border border-zinc-200 text-zinc-900 text-xs"
                      />
                      <div className="flex items-center gap-1">
                        <input
                          type="text"
                          placeholder="Duration (e.g. 30 days)"
                          value={med.duration}
                          onChange={(e) => {
                            const updated = [...rxMedicines];
                            updated[idx].duration = e.target.value;
                            setRxMedicines(updated);
                          }}
                          className="w-full px-3 py-1.5 rounded-lg bg-white border border-zinc-200 text-zinc-900 text-xs"
                        />
                        {rxMedicines.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleRemoveMedicineRow(idx)}
                            className="p-1.5 rounded-lg text-rose-500 hover:bg-rose-50"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-700 mb-1">Recommended Supplements & Store Products</label>
                <input
                  type="text"
                  value={rxSupplements}
                  onChange={(e) => setRxSupplements(e.target.value)}
                  placeholder="e.g. Your Care Pure Whey Isolate, Triple Strength Omega-3"
                  className="w-full px-4 py-2.5 rounded-xl bg-zinc-50 border border-zinc-200 text-zinc-900 text-xs font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-700 mb-1">Doctor's Clinical Notes</label>
                <textarea
                  rows={3}
                  value={rxNotes}
                  onChange={(e) => setRxNotes(e.target.value)}
                  placeholder="Additional lifestyle, hydration and follow-up notes..."
                  className="w-full px-4 py-2.5 rounded-xl bg-zinc-50 border border-zinc-200 text-zinc-900 text-xs resize-none"
                />
              </div>

              <div className="pt-3 border-t border-zinc-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedReportForRx(null)}
                  className="px-5 py-2.5 rounded-xl bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-bold cursor-pointer"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={isSubmittingRx}
                  className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md shadow-emerald-600/20 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>{isSubmittingRx ? 'Issuing...' : 'Issue & Attach to Patient Profile'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
