import React, { useState } from 'react';
import { 
  User, Mail, Phone, Calendar, ShieldCheck, Scale, 
  Target, Flame, Droplets, ArrowLeft, Edit3, Heart, 
  Stethoscope, Award, ChevronRight, LogOut, RefreshCw, 
  Package, FileText, CheckCircle2, ShieldAlert, Sparkles,
  Smartphone, Bell, Globe, Lock
} from 'lucide-react';
import { UserHealthProfile, UserAccount } from '../types';
import { useLanguage, LanguageSwitchButton } from '../context/LanguageContext';

interface ProfilePageProps {
  profile: UserHealthProfile;
  account: UserAccount;
  onBackToDashboard: () => void;
  onUpdateProfile: (updated: UserHealthProfile) => void;
  onOpenSettings: () => void;
  onOpenOrders: () => void;
  onOpenReports: () => void;
  onOpenDoctorConsult: () => void;
  onOpenRiskAssessment: () => void;
  onLogOut: () => void;
}

export const ProfilePage: React.FC<ProfilePageProps> = ({
  profile,
  account,
  onBackToDashboard,
  onUpdateProfile,
  onOpenSettings,
  onOpenOrders,
  onOpenReports,
  onOpenDoctorConsult,
  onOpenRiskAssessment,
  onLogOut,
}) => {
  const { language, t } = useLanguage();
  const [isEditingBiometrics, setIsEditingBiometrics] = useState(false);

  // Editable fields
  const [weight, setWeight] = useState(profile.currentWeightKg || 70);
  const [targetWeight, setTargetWeight] = useState(profile.targetWeightKg || 65);
  const [dietary, setDietary] = useState(profile.dietaryPreference || 'Vegetarian');

  const { calculatedPlan, heightCm = 170, age = 28, gender = 'male' } = profile;
  const bmi = calculatedPlan?.bmi || Number((weight / Math.pow(heightCm / 100, 2)).toFixed(1));

  const handleSaveBiometrics = () => {
    const updated: UserHealthProfile = {
      ...profile,
      currentWeightKg: Number(weight),
      targetWeightKg: Number(targetWeight),
      dietaryPreference: dietary,
      updatedAt: new Date().toISOString(),
    };
    onUpdateProfile(updated);
    setIsEditingBiometrics(false);
  };

  return (
    <div id="yourcare-profile-page" className="min-h-screen bg-[#F8FAFC] text-zinc-900 pb-16">
      
      {/* TOP NAVIGATION HEADER */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-zinc-200/90 px-4 sm:px-8 py-3.5 shadow-xs">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <button
            type="button"
            onClick={onBackToDashboard}
            className="inline-flex items-center gap-2 text-xs font-bold text-zinc-700 hover:text-zinc-950 px-3 py-1.5 rounded-xl hover:bg-zinc-100 transition-all cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>{language === 'hi' ? 'डैशबोर्ड पर वापस जाएं' : 'Back to Dashboard'}</span>
          </button>

          <div className="flex items-center gap-2">
            <LanguageSwitchButton />
          </div>
        </div>
      </header>

      {/* MAIN PROFILE CONTENT */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 pt-6 space-y-6 text-left">
        
        {/* 1. HERO USER PROFILE CARD */}
        <div className="p-6 sm:p-8 rounded-3xl bg-white border border-zinc-200 shadow-sm relative overflow-hidden">
          
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600" />
          
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5">
            
            <div className="flex items-center gap-4 sm:gap-5">
              {/* User Avatar */}
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-3xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center text-2xl font-black shadow-lg shadow-emerald-600/20 shrink-0">
                {(profile.name || account.displayName || 'U').charAt(0).toUpperCase()}
              </div>

              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="text-xl sm:text-2xl font-black text-zinc-950">
                    {profile.name || account.displayName || 'Your Care Member'}
                  </h1>
                  <span className="inline-flex items-center gap-1 text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">
                    <ShieldCheck className="w-3 h-3 text-emerald-600" />
                    <span>{language === 'hi' ? 'प्रमाणित सदस्य' : 'Verified Member'}</span>
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-zinc-500 font-medium">
                  <span className="flex items-center gap-1">
                    <Mail className="w-3.5 h-3.5 text-zinc-400" />
                    {profile.email || account.email || 'user@yourcare.app'}
                  </span>
                  <span className="flex items-center gap-1">
                    <Phone className="w-3.5 h-3.5 text-zinc-400" />
                    {profile.phone || account.phoneNumber || '+91 98765 43210'}
                  </span>
                </div>

                <div className="text-[11px] text-zinc-400 font-mono pt-0.5">
                  UID: {account.uid?.substring(0, 16) || 'usr_yourcare_99'} • {gender.toUpperCase()} • {age} YRS
                </div>
              </div>
            </div>

            {/* Edit / Actions */}
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                type="button"
                onClick={() => setIsEditingBiometrics(!isEditingBiometrics)}
                className="flex-1 sm:flex-none px-4 py-2 rounded-xl border border-zinc-200 bg-zinc-50 hover:bg-zinc-100 text-zinc-800 text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5 text-emerald-600" />
                <span>{isEditingBiometrics ? (language === 'hi' ? 'रद्द करें' : 'Cancel') : (language === 'hi' ? 'बायोमेट्रिक्स बदलें' : 'Edit Biometrics')}</span>
              </button>
            </div>

          </div>

          {/* EDIT BIOMETRICS DRAWER (IF OPEN) */}
          {isEditingBiometrics && (
            <div className="mt-6 pt-5 border-t border-zinc-100 space-y-4 bg-zinc-50 p-4 rounded-2xl animate-in fade-in">
              <h3 className="text-xs font-black uppercase text-zinc-700">
                {language === 'hi' ? 'शारीरिक बायोमेट्रिक्स अपडेट करें' : 'Update Physical Biometrics'}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-zinc-600 mb-1">Current Weight (kg)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={weight}
                    onChange={(e) => setWeight(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-zinc-300 bg-white text-xs font-bold text-zinc-900"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-zinc-600 mb-1">Target Weight (kg)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={targetWeight}
                    onChange={(e) => setTargetWeight(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-zinc-300 bg-white text-xs font-bold text-zinc-900"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-zinc-600 mb-1">Dietary Preference</label>
                  <select
                    value={dietary}
                    onChange={(e) => setDietary(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-zinc-300 bg-white text-xs font-bold text-zinc-900"
                  >
                    <option value="Vegetarian">Vegetarian</option>
                    <option value="Non-Vegetarian">Non-Vegetarian</option>
                    <option value="Eggetarian">Eggetarian</option>
                    <option value="Vegan">Vegan</option>
                    <option value="Jain">Jain</option>
                    <option value="Keto / Low-Carb">Keto / Low-Carb</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsEditingBiometrics(false)}
                  className="px-3 py-1.5 rounded-lg text-xs font-bold text-zinc-600 hover:bg-zinc-200"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSaveBiometrics}
                  className="px-4 py-1.5 rounded-lg text-xs font-black bg-emerald-600 text-white shadow-sm hover:bg-emerald-500 cursor-pointer"
                >
                  Save Changes
                </button>
              </div>
            </div>
          )}

        </div>

        {/* 2. CALIBRATED BIOMETRICS & TARGET STATS */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          
          <div className="p-4 rounded-2xl bg-white border border-zinc-200 shadow-xs space-y-1">
            <span className="text-[10px] font-black uppercase tracking-wider text-zinc-400">
              {t('currentWeight')}
            </span>
            <div className="text-xl sm:text-2xl font-black text-zinc-950">
              {profile.currentWeightKg} <span className="text-xs font-semibold text-zinc-400">kg</span>
            </div>
            <span className="text-[10px] text-zinc-500 block">
              {(profile.currentWeightKg * 2.20462).toFixed(1)} lbs
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-white border border-zinc-200 shadow-xs space-y-1">
            <span className="text-[10px] font-black uppercase tracking-wider text-emerald-700">
              {t('targetWeight')}
            </span>
            <div className="text-xl sm:text-2xl font-black text-emerald-600">
              {profile.targetWeightKg} <span className="text-xs font-semibold text-emerald-700">kg</span>
            </div>
            <span className="text-[10px] text-emerald-800 font-bold block">
              Goal: {profile.pace || 'steady'} pace
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-white border border-zinc-200 shadow-xs space-y-1">
            <span className="text-[10px] font-black uppercase tracking-wider text-zinc-400">
              {t('height')}
            </span>
            <div className="text-xl sm:text-2xl font-black text-zinc-950">
              {heightCm} <span className="text-xs font-semibold text-zinc-400">cm</span>
            </div>
            <span className="text-[10px] text-zinc-500 block">
              {Math.floor((heightCm / 2.54) / 12)} ft {Math.round((heightCm / 2.54) % 12)} in
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-white border border-zinc-200 shadow-xs space-y-1">
            <span className="text-[10px] font-black uppercase tracking-wider text-zinc-400">
              {t('bmiStatus')}
            </span>
            <div className="text-xl sm:text-2xl font-black text-zinc-950">
              {bmi}
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 inline-block">
              {bmi < 18.5 ? 'Underweight' : bmi < 25 ? 'Normal Optimal' : bmi < 30 ? 'Overweight' : 'Obese'}
            </span>
          </div>

        </div>

        {/* 3. DAILY MACRONUTRIENT BUDGET SUMMARY */}
        <div className="p-5 sm:p-6 rounded-3xl bg-white border border-zinc-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
            <div className="flex items-center gap-2">
              <Flame className="w-5 h-5 text-emerald-600" />
              <h3 className="text-sm font-black text-zinc-950 uppercase tracking-tight">
                {language === 'hi' ? 'दैनिक कैलिब्रेटेड पोषण बजट' : 'Daily Calibrated Nutrition Budget'}
              </h3>
            </div>
            <span className="text-xs font-extrabold text-emerald-700">
              {calculatedPlan?.targetCalories || 1850} kcal / day
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-left">
            <div className="p-3 rounded-2xl bg-zinc-50 border border-zinc-200/70">
              <span className="text-[10px] font-bold text-zinc-400 uppercase">Protein Budget</span>
              <div className="text-lg font-black text-emerald-600">{calculatedPlan?.proteinGrams || 130}g</div>
              <span className="text-[10px] text-zinc-500 font-medium">30% macro ratio</span>
            </div>

            <div className="p-3 rounded-2xl bg-zinc-50 border border-zinc-200/70">
              <span className="text-[10px] font-bold text-zinc-400 uppercase">Carb Budget</span>
              <div className="text-lg font-black text-zinc-900">{calculatedPlan?.carbsGrams || 180}g</div>
              <span className="text-[10px] text-zinc-500 font-medium">45% macro ratio</span>
            </div>

            <div className="p-3 rounded-2xl bg-zinc-50 border border-zinc-200/70">
              <span className="text-[10px] font-bold text-zinc-400 uppercase">Healthy Fats</span>
              <div className="text-lg font-black text-zinc-900">{calculatedPlan?.fatsGrams || 50}g</div>
              <span className="text-[10px] text-zinc-500 font-medium">25% macro ratio</span>
            </div>

            <div className="p-3 rounded-2xl bg-zinc-50 border border-zinc-200/70">
              <span className="text-[10px] font-bold text-zinc-400 uppercase">Water Intake</span>
              <div className="text-lg font-black text-teal-600">{calculatedPlan?.waterLiters || 3.2}L</div>
              <span className="text-[10px] text-zinc-500 font-medium">Clinical hydration</span>
            </div>
          </div>
        </div>

        {/* 4. HEALTH RISKS & DOCTOR SUPERVISION SHORTCUT */}
        <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-r from-rose-50 via-amber-50 to-orange-50 border border-rose-200/80 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-2xl bg-rose-600 text-white flex items-center justify-center shrink-0 mt-0.5 shadow-md shadow-rose-600/20">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-black text-rose-800 uppercase tracking-wide">
                  {language === 'hi' ? 'मेटाबॉलिक जोखिम विश्लेषण' : 'Metabolic Threat & Risk Assessment'}
                </span>
                <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded-full bg-rose-200 text-rose-800">
                  Critical
                </span>
              </div>
              <p className="text-xs text-zinc-700 font-medium mt-0.5">
                {language === 'hi'
                  ? 'विसरल फैट और मेटाबॉलिज्म से जुड़े 3 मुख्य स्वास्थ्य जोखिम देखें।'
                  : 'Review your 12-month visceral fat projection and clinical mitigation protocol.'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onOpenRiskAssessment}
            className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-md shadow-rose-600/20 transition-all cursor-pointer shrink-0"
          >
            <span>{language === 'hi' ? 'जोखिम रिपोर्ट देखें' : 'View Risk Report'}</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* 5. QUICK SHORTCUTS & APP MANAGEMENT */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          
          {/* Orders Shortcut */}
          <button
            type="button"
            onClick={onOpenOrders}
            className="p-4 rounded-2xl bg-white border border-zinc-200 hover:border-emerald-300 hover:bg-emerald-50/30 text-left flex items-center justify-between transition-all cursor-pointer shadow-xs"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-zinc-100 text-zinc-700 flex items-center justify-center font-bold">
                <Package className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-black text-zinc-900">
                  {language === 'hi' ? 'मेरे ऑर्डर और डिलीवरी' : 'My Orders & Deliveries'}
                </h4>
                <p className="text-[11px] text-zinc-500">Track supplements and health product shipments</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-zinc-400" />
          </button>

          {/* Medical Reports Shortcut */}
          <button
            type="button"
            onClick={onOpenReports}
            className="p-4 rounded-2xl bg-white border border-zinc-200 hover:border-emerald-300 hover:bg-emerald-50/30 text-left flex items-center justify-between transition-all cursor-pointer shadow-xs"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-zinc-100 text-zinc-700 flex items-center justify-center font-bold">
                <FileText className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-black text-zinc-900">
                  {language === 'hi' ? 'लैब रिपोर्ट और डॉक्टर के पर्चे' : 'Lab Reports & Prescriptions'}
                </h4>
                <p className="text-[11px] text-zinc-500">Uploaded blood tests & personalized diet charts</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-zinc-400" />
          </button>

          {/* Doctor Consult Shortcut */}
          <button
            type="button"
            onClick={onOpenDoctorConsult}
            className="p-4 rounded-2xl bg-white border border-zinc-200 hover:border-emerald-300 hover:bg-emerald-50/30 text-left flex items-center justify-between transition-all cursor-pointer shadow-xs"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center font-bold">
                <Stethoscope className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-black text-zinc-900">
                  {language === 'hi' ? 'डॉक्टर से परामर्श लें' : 'Consult Chief Clinical Nutritionist'}
                </h4>
                <p className="text-[11px] text-zinc-500">Dr. Arjun Mehta (MBBS, MD) & care team</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-zinc-400" />
          </button>

          {/* Settings & Preferences */}
          <button
            type="button"
            onClick={onOpenSettings}
            className="p-4 rounded-2xl bg-white border border-zinc-200 hover:border-emerald-300 hover:bg-emerald-50/30 text-left flex items-center justify-between transition-all cursor-pointer shadow-xs"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-zinc-100 text-zinc-700 flex items-center justify-center font-bold">
                <Bell className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-black text-zinc-900">
                  {language === 'hi' ? 'ऐप सेटिंग्स और नोटिफिकेशन' : 'App Settings & Alerts'}
                </h4>
                <p className="text-[11px] text-zinc-500">Manage water alerts, calorie rollover & reminders</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-zinc-400" />
          </button>

        </div>

        {/* 6. LOG OUT / SIGN OUT BUTTON */}
        <div className="pt-4 flex items-center justify-between border-t border-zinc-200/80">
          <span className="text-xs text-zinc-400 font-medium">
            Your Care Precision Clinical Engine • v2.4.0
          </span>
          <button
            type="button"
            onClick={onLogOut}
            className="px-4 py-2 rounded-xl text-xs font-black text-rose-700 hover:text-rose-800 bg-rose-50 hover:bg-rose-100 border border-rose-200 flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>{language === 'hi' ? 'लॉग आउट करें' : 'Sign Out Account'}</span>
          </button>
        </div>

      </main>

    </div>
  );
};
