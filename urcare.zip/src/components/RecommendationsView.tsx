import React, { useState } from 'react';
import { 
  CheckCircle2, AlertTriangle, ShieldCheck, Ban, Calendar, 
  Sparkles, Clock, Flame, Droplets, Target, ChevronRight, Activity, 
  HeartPulse, Stethoscope, FileText, ArrowRight, ChevronLeft,
  Check, X, PhoneCall, ShieldAlert, TrendingUp, Info, Dumbbell, Award, Lock
} from 'lucide-react';
import { UserHealthProfile, Prescription } from '../types';
import { useTheme } from '../context/ThemeContext';
import { Logo } from './Logo';

interface RecommendationsViewProps {
  profile: UserHealthProfile;
  prescriptions?: Prescription[];
  onOpenStore?: () => void;
  onOpenReportHub?: () => void;
  onOpenConsultDoctor?: () => void;
  onOpenProModal?: (feature: string) => void;
}

export const RecommendationsView: React.FC<RecommendationsViewProps> = ({
  profile,
  prescriptions = [],
  onOpenStore,
  onOpenReportHub,
  onOpenConsultDoctor,
  onOpenProModal,
}) => {
  const { theme } = useTheme();
  const isDark = theme === 'dark';

  // Strictly YESTERDAY and TODAY (No future dates allowed)
  const [selectedDay, setSelectedDay] = useState<'yesterday' | 'today'>('today');

  const { calculatedPlan, dietaryPreference } = profile;
  const targetCalories = calculatedPlan?.targetCalories || 1850;
  const targetProtein = calculatedPlan?.proteinGrams || 140;
  const targetCarbs = calculatedPlan?.carbsGrams || 180;
  const targetFats = calculatedPlan?.fatsGrams || 50;

  // Previous Day (Yesterday) historical achievement metrics
  const yesterdayTargetCalories = targetCalories;
  const yesterdayAchievedCalories = Math.round(targetCalories * 0.96);
  const yesterdayProteinAchieved = Math.round(targetProtein * 0.94);
  const yesterdayCarbsAchieved = Math.round(targetCarbs * 0.98);
  const yesterdayFatsAchieved = Math.round(targetFats * 0.92);
  const yesterdayAdherence = 97; // %

  const todayDate = new Date();
  const yesterdayDate = new Date(todayDate);
  yesterdayDate.setDate(todayDate.getDate() - 1);

  const formatDate = (d: Date) => {
    return d.toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
    });
  };

  const cardClass = isDark ? 'bg-zinc-950 border border-zinc-800' : 'bg-white border border-zinc-200 shadow-sm';
  const subCardClass = isDark ? 'bg-zinc-900/70 border border-zinc-800' : 'bg-zinc-50 border border-zinc-200';

  // Foods to Eat Today vs Yesterday
  const eatList = [
    {
      title: 'Lean Bio-Available Protein Sources',
      desc: `Target ${targetProtein}g daily partitioned across 3-4 meals. High priority: Whey Isolate, egg whites, Greek yogurt, steamed sprouted dal, and organic tofu/paneer.`,
      metric: `${targetProtein}g Target`,
    },
    {
      title: 'Soluble Viscous Fiber & Complex Polysaccharides',
      desc: 'Steel-cut oats, chia seeds, brown basmati, quinoa, and dark cruciferous greens (spinach, broccoli) to bind excess bile acids and optimize metabolic transit.',
      metric: '35g Fiber',
    },
    {
      title: 'Cardio-Protective Polyunsaturated Lipids',
      desc: 'Triple Strength Omega-3 triglycerides (EPA/DHA 1000mg), crushed walnuts, flaxseeds, and cold-pressed extra virgin olive oil.',
      metric: 'MUFA/PUFA Blend',
    },
    {
      title: 'Cellular Micronutrients & Electrolytes',
      desc: 'Elemental Magnesium Glycinate (400mg) for nocturnal neuromuscular recovery, Vitamin D3 (60k IU weekly if deficient), and buffered Vitamin C.',
      metric: 'Clinical Range',
    },
  ];

  // What to Avoid Strictly
  const avoidList = [
    {
      title: 'Deep-Fried & Industrial Trans-Fats',
      desc: 'Commercial bakery pastries, hydrogenated vegetable oils (vanaspati), and reheated cooking oils that trigger endothelial oxidation.',
      reason: 'Increases visceral adiposity and arterial inflammation.',
    },
    {
      title: 'Liquid Fructose & High-Glycemic Beverages',
      desc: 'Packaged fruit concentrates, carbonated beverages, and refined sugar in milk tea/coffee. Triggers hepatic de novo lipogenesis.',
      reason: 'Directly elevates liver triglycerides and causes acute insulin spikes.',
    },
    {
      title: 'Refined Flours & Rapidly Digestible Carbs',
      desc: 'White flour (maida), instant noodles, and low-fiber white bread leading to sharp postprandial glucose swings.',
      reason: 'Blunts fat oxidation and triggers reactive hunger.',
    },
    {
      title: 'Late-Night High Sodium Dining',
      desc: 'Heavy sodium meals post 9:30 PM leading to nocturnal hypertension, impaired REM sleep, and digestive reflux.',
      reason: 'Disrupts overnight metabolic repair cycles.',
    },
  ];

  // Exercises to Do vs Exercises to Avoid
  const exerciseDoList = [
    {
      name: 'Zone-2 Metabolic Base Cardio',
      duration: '35-45 mins',
      benefit: 'Maximizes mitochondrial biogenesis and steady-state lipid oxidation without spiking cortisol.',
      intensity: 'HR 115-135 BPM (Conversational pace)',
    },
    {
      name: 'Multi-Joint Compound Resistance Training',
      duration: '40 mins',
      benefit: 'Stimulates GLUT4 glucose transporter translocation to skeletal muscle independently of insulin.',
      intensity: 'RPE 7-8 (3-4 sets of 8-12 reps)',
    },
    {
      name: 'Postprandial Glucose Clearance Walk',
      duration: '10-15 mins',
      benefit: 'Reduces post-meal blood glucose spike by up to 28% through non-insulin mediated muscle contraction.',
      intensity: 'Brisk walking within 20m of eating',
    },
  ];

  const exerciseAvoidList = [
    {
      name: 'Exhaustive High-Intensity HIIT to Failure on Calorie Deficit',
      reason: 'Excess cortisol triggers gluconeogenesis from muscle tissue and causes severe central nervous system fatigue.',
    },
    {
      name: 'Heavy Spinal Compressive Loading Without Core Bracing',
      reason: 'Increases risk of intervertebral disc herniation, especially when fatigued or dehydrated.',
    },
    {
      name: 'Long-Duration Fasted Cardio Exceeding 60 Minutes',
      reason: 'Accelerates catabolism of lean myofibrillar protein and suppresses thyroid T3 hormone output.',
    },
  ];

  return (
    <div id="diet-recommendations-section" className="space-y-6 text-left">
      
      {/* 1. SECTION HEADER WITH DAY SELECTOR & PRO BADGE */}
      <div className={`p-5 sm:p-6 rounded-3xl ${cardClass} space-y-4`}>
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Logo size="sm" showSubtitle={false} />
              <span className="text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-500 border border-emerald-500/30 flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                <span>Pro Diet & Clinical Protocol</span>
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black tracking-tight mt-1.5">
              Precision Diet & Metabolic Protocols
            </h2>
            <p className="text-xs opacity-75 mt-0.5">
              Restricted to verified historical compliance and active daily execution. Future schedules unlock automatically each morning.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onOpenConsultDoctor}
              className="px-3.5 py-2 rounded-xl bg-teal-500 hover:bg-teal-400 text-black font-extrabold text-xs uppercase tracking-wider transition-all flex items-center gap-1.5 shadow-md shadow-teal-500/20"
            >
              <Stethoscope className="w-3.5 h-3.5" />
              <span>Doctor Review</span>
            </button>
          </div>
        </div>

        {/* 2-Day Switcher (Strictly: Yesterday vs Today) */}
        <div className="pt-3 border-t border-zinc-800/40 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center p-1 rounded-2xl bg-zinc-900/60 border border-zinc-800 w-full sm:w-auto">
            <button
              type="button"
              onClick={() => setSelectedDay('yesterday')}
              className={`flex-1 sm:flex-initial px-5 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 ${
                selectedDay === 'yesterday'
                  ? 'bg-emerald-500 text-black font-bold shadow-md'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              <span>Yesterday ({formatDate(yesterdayDate)})</span>
            </button>

            <button
              type="button"
              onClick={() => setSelectedDay('today')}
              className={`flex-1 sm:flex-initial px-6 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 ${
                selectedDay === 'today'
                  ? 'bg-emerald-500 text-black font-bold shadow-md'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>Today ({formatDate(todayDate)})</span>
            </button>
          </div>

          <div className="text-xs opacity-75 font-semibold">
            {selectedDay === 'yesterday' ? (
              <span className="text-emerald-500">Yesterday: Target vs. Actual Calories & Protocol Adherence</span>
            ) : (
              <span className="text-emerald-500">Today: Active Prescribed Nutrition & Movement Blueprint</span>
            )}
          </div>
        </div>
      </div>

      {/* 2. TARGET vs ACHIEVEMENT METRICS */}
      {selectedDay === 'yesterday' ? (
        <div className={`p-6 rounded-3xl ${cardClass} space-y-4`}>
          <div className="flex items-center justify-between pb-3 border-b border-zinc-800/40">
            <div className="flex items-center gap-2 text-emerald-500">
              <Award className="w-5 h-5" />
              <h3 className="text-sm font-black uppercase tracking-wider">Yesterday's Calorie Target vs. Achievement</h3>
            </div>
            <span className="text-xs font-extrabold px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400">
              {yesterdayAdherence}% Protocol Adherence
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className={`p-4 rounded-2xl ${subCardClass} text-center space-y-1`}>
              <span className="text-[10px] font-bold uppercase opacity-60">Calorie Target</span>
              <div className="text-xl font-black text-zinc-400">{yesterdayTargetCalories} <span className="text-xs">kcal</span></div>
              <div className="text-xs font-extrabold text-emerald-500 mt-1">Achieved: {yesterdayAchievedCalories} kcal</div>
            </div>

            <div className={`p-4 rounded-2xl ${subCardClass} text-center space-y-1`}>
              <span className="text-[10px] font-bold uppercase opacity-60">Protein Target</span>
              <div className="text-xl font-black text-zinc-400">{targetProtein} <span className="text-xs">g</span></div>
              <div className="text-xs font-extrabold text-emerald-500 mt-1">Achieved: {yesterdayProteinAchieved} g</div>
            </div>

            <div className={`p-4 rounded-2xl ${subCardClass} text-center space-y-1`}>
              <span className="text-[10px] font-bold uppercase opacity-60">Carb Allowance</span>
              <div className="text-xl font-black text-zinc-400">{targetCarbs} <span className="text-xs">g</span></div>
              <div className="text-xs font-extrabold text-emerald-500 mt-1">Achieved: {yesterdayCarbsAchieved} g</div>
            </div>

            <div className={`p-4 rounded-2xl ${subCardClass} text-center space-y-1`}>
              <span className="text-[10px] font-bold uppercase opacity-60">Fat Allowance</span>
              <div className="text-xl font-black text-zinc-400">{targetFats} <span className="text-xs">g</span></div>
              <div className="text-xs font-extrabold text-emerald-500 mt-1">Achieved: {yesterdayFatsAchieved} g</div>
            </div>
          </div>
        </div>
      ) : (
        <div className={`p-6 rounded-3xl ${cardClass} space-y-4`}>
          <div className="flex items-center justify-between pb-3 border-b border-zinc-800/40">
            <div className="flex items-center gap-2 text-emerald-500">
              <Target className="w-5 h-5" />
              <h3 className="text-sm font-black uppercase tracking-wider">Today's Precision Macronutrient Targets</h3>
            </div>
            <span className="text-xs font-extrabold px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400">
              Active Daily Goal
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className={`p-4 rounded-2xl ${subCardClass} text-center`}>
              <span className="text-[10px] font-bold uppercase opacity-60 text-emerald-500">Daily Calorie Target</span>
              <div className="text-2xl font-black mt-1 text-emerald-500">{targetCalories} <span className="text-xs opacity-60">kcal</span></div>
            </div>
            <div className={`p-4 rounded-2xl ${subCardClass} text-center`}>
              <span className="text-[10px] font-bold uppercase opacity-60">Protein Target</span>
              <div className="text-2xl font-black mt-1">{targetProtein} <span className="text-xs opacity-60">g</span></div>
            </div>
            <div className={`p-4 rounded-2xl ${subCardClass} text-center`}>
              <span className="text-[10px] font-bold uppercase opacity-60">Carbohydrate Limit</span>
              <div className="text-2xl font-black mt-1">{targetCarbs} <span className="text-xs opacity-60">g</span></div>
            </div>
            <div className={`p-4 rounded-2xl ${subCardClass} text-center`}>
              <span className="text-[10px] font-bold uppercase opacity-60">Healthy Fats</span>
              <div className="text-2xl font-black mt-1">{targetFats} <span className="text-xs opacity-60">g</span></div>
            </div>
          </div>
        </div>
      )}

      {/* 3. TWO COLUMNS: WHAT TO EAT vs WHAT TO AVOID */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        
        {/* RECOMMENDED EATS */}
        <div className={`p-5 sm:p-6 rounded-3xl ${cardClass} space-y-4`}>
          <div className="flex items-center justify-between pb-3 border-b border-zinc-800/40">
            <div className="flex items-center gap-2 text-emerald-500">
              <CheckCircle2 className="w-5 h-5" />
              <h3 className="text-base font-black tracking-tight">Prescribed Foods to Eat</h3>
            </div>
            <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-500">
              Clinical Priority
            </span>
          </div>

          <div className="space-y-3">
            {eatList.map((item, idx) => (
              <div key={idx} className={`p-3.5 rounded-2xl ${subCardClass} space-y-1.5`}>
                <div className="flex items-center justify-between">
                  <h4 className={`text-xs font-extrabold ${isDark ? 'text-white' : 'text-zinc-900'}`}>{item.title}</h4>
                  <span className="text-[10px] font-bold text-emerald-500 px-2 py-0.5 rounded bg-emerald-500/10">
                    {item.metric}
                  </span>
                </div>
                <p className={`text-xs leading-relaxed ${isDark ? 'text-zinc-300' : 'text-zinc-700'}`}>{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* PROHIBITED FOODS */}
        <div className={`p-5 sm:p-6 rounded-3xl ${cardClass} space-y-4`}>
          <div className="flex items-center justify-between pb-3 border-b border-zinc-800/40">
            <div className="flex items-center gap-2 text-rose-500">
              <Ban className="w-5 h-5 text-rose-500" />
              <h3 className="text-base font-black tracking-tight">Foods to Avoid Strictly</h3>
            </div>
            <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-rose-500/10 text-rose-500">
              Prohibited
            </span>
          </div>

          <div className="space-y-3">
            {avoidList.map((item, idx) => (
              <div key={idx} className={`p-3.5 rounded-2xl ${subCardClass} space-y-1.5`}>
                <div className="flex items-center justify-between">
                  <h4 className={`text-xs font-extrabold ${isDark ? 'text-white' : 'text-zinc-900'}`}>{item.title}</h4>
                  <span className="text-[10px] font-bold text-rose-500 px-2 py-0.5 rounded bg-rose-500/10">
                    Avoid
                  </span>
                </div>
                <p className={`text-xs leading-relaxed ${isDark ? 'text-zinc-300' : 'text-zinc-700'}`}>{item.desc}</p>
                <div className={`text-[11px] font-semibold pt-1 border-t ${
                  isDark ? 'border-zinc-800/60 text-rose-400' : 'border-zinc-200 text-rose-600'
                }`}>
                  Risk: {item.reason}
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* 4. EXERCISES TO PERFORM vs EXERCISES TO AVOID */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        
        {/* EXERCISES TO DO */}
        <div className={`p-5 sm:p-6 rounded-3xl ${cardClass} space-y-4`}>
          <div className="flex items-center justify-between pb-3 border-b border-zinc-800/40">
            <div className="flex items-center gap-2 text-teal-400">
              <Dumbbell className="w-5 h-5 text-teal-500" />
              <h3 className="text-base font-black tracking-tight">Exercises to Perform Today</h3>
            </div>
            <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-teal-500/10 text-teal-400">
              Prescribed
            </span>
          </div>

          <div className="space-y-3">
            {exerciseDoList.map((ex, idx) => (
              <div key={idx} className={`p-3.5 rounded-2xl ${subCardClass} space-y-1.5`}>
                <div className="flex items-center justify-between">
                  <h4 className={`text-xs font-extrabold ${isDark ? 'text-white' : 'text-zinc-900'}`}>{ex.name}</h4>
                  <span className="text-[10px] font-bold text-teal-400 px-2 py-0.5 rounded bg-teal-500/10">
                    {ex.duration}
                  </span>
                </div>
                <p className={`text-xs leading-relaxed ${isDark ? 'text-zinc-300' : 'text-zinc-700'}`}>{ex.benefit}</p>
                <div className="text-[11px] text-teal-400 font-bold pt-1 border-t border-zinc-800/40">
                  Target Zone: {ex.intensity}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* EXERCISES TO AVOID */}
        <div className={`p-5 sm:p-6 rounded-3xl ${cardClass} space-y-4`}>
          <div className="flex items-center justify-between pb-3 border-b border-zinc-800/40">
            <div className="flex items-center gap-2 text-amber-400">
              <AlertTriangle className="w-5 h-5 text-amber-500" />
              <h3 className="text-base font-black tracking-tight">Exercises to Avoid & Contraindications</h3>
            </div>
            <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-amber-500/10 text-amber-400">
              Caution
            </span>
          </div>

          <div className="space-y-3">
            {exerciseAvoidList.map((ex, idx) => (
              <div key={idx} className={`p-3.5 rounded-2xl ${subCardClass} space-y-1.5`}>
                <h4 className={`text-xs font-extrabold ${isDark ? 'text-white' : 'text-zinc-900'}`}>{ex.name}</h4>
                <p className={`text-xs leading-relaxed ${isDark ? 'text-zinc-300' : 'text-zinc-700'}`}>{ex.reason}</p>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* 5. CLINICAL DOCTOR CONSULTATION & DIRECT CALL PANEL */}
      <div className={`p-6 rounded-3xl ${
        isDark ? 'bg-gradient-to-r from-teal-950/40 to-emerald-950/30 border border-teal-500/30' : 'bg-teal-50 border border-teal-200'
      } space-y-4`}>
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-teal-500/20 text-teal-400 border border-teal-500/30 flex items-center justify-center shrink-0">
              <Stethoscope className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black">Physician & Clinical Care Hotline</h3>
                <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-400">
                  Direct Phone Access
                </span>
              </div>
              <p className={`text-xs mt-0.5 ${isDark ? 'text-zinc-300' : 'text-zinc-700'}`}>
                Connect with our board-certified MDs or clinical nutritionists for personalized prescription and lab review.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {onOpenReportHub && (
              <button
                type="button"
                onClick={onOpenReportHub}
                className="px-4 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-bold text-white transition-all"
              >
                Upload Lab PDF
              </button>
            )}
            <button
              type="button"
              onClick={onOpenConsultDoctor}
              className="px-4 py-2.5 rounded-xl bg-teal-500 hover:bg-teal-400 text-black font-black text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md shadow-teal-500/20 transition-all"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              <span>Call Specialist Now</span>
            </button>
          </div>
        </div>

        {prescriptions.length > 0 && (
          <div className="pt-3 border-t border-teal-500/20 space-y-2">
            <span className="text-[11px] font-black uppercase tracking-wider text-teal-400">
              Active Prescriptions on File ({prescriptions.length})
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {prescriptions.map((rx) => (
                <div key={rx.id} className={`p-3 rounded-xl ${subCardClass} flex items-center justify-between text-xs`}>
                  <div>
                    <div className="font-bold">{rx.productName}</div>
                    <span className="text-[10px] opacity-60">{rx.dosage} • {rx.frequency}</span>
                  </div>
                  <span className="text-[10px] font-bold text-teal-400 px-2 py-0.5 rounded bg-teal-500/10">
                    Dr. {rx.prescribedByDoctorName}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

    </div>
  );
};
