import React from 'react';
import { Shield, Sparkles, Activity, Heart } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showSubtitle?: boolean;
  className?: string;
}

export const Logo: React.FC<LogoProps> = ({
  size = 'md',
  showSubtitle = true,
  className = '',
}) => {
  const { theme } = useTheme();
  const isDark = theme === 'dark';

  const iconSizes = {
    sm: 'w-7 h-7',
    md: 'w-9 h-9',
    lg: 'w-11 h-11',
    xl: 'w-14 h-14',
  };

  const titleSizes = {
    sm: 'text-sm tracking-tight',
    md: 'text-lg tracking-tight',
    lg: 'text-2xl tracking-tighter',
    xl: 'text-3xl tracking-tighter',
  };

  const subSizes = {
    sm: 'text-[9px] tracking-wider',
    md: 'text-[10px] tracking-widest',
    lg: 'text-xs tracking-widest',
    xl: 'text-xs tracking-widest',
  };

  return (
    <div className={`inline-flex items-center gap-2.5 select-none ${className}`}>
      {/* Precision Geometric Medical Cross & Wellness Shield 3D Vector Icon */}
      <div className={`relative ${iconSizes[size]} shrink-0 rounded-2xl flex items-center justify-center transition-all duration-300 group`}>
        {/* Glow backdrop */}
        <div className="absolute inset-0 rounded-2xl bg-gradient-to-tr from-emerald-600 via-emerald-400 to-teal-200 opacity-90 blur-[2px] group-hover:blur-[4px] transition-all" />
        
        {/* Crisp Surface Plate */}
        <div className={`relative w-full h-full rounded-2xl ${isDark ? 'bg-zinc-950/90' : 'bg-white/95'} border border-emerald-400/50 flex items-center justify-center shadow-lg shadow-emerald-500/20 backdrop-blur-sm overflow-hidden`}>
          {/* Subtle Grid Accent */}
          <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:6px_6px]" />
          
          {/* Medical Cross / Leaf Monogram */}
          <div className="relative flex items-center justify-center text-emerald-500">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              className="w-5/6 h-5/6 stroke-[2.2] text-emerald-500"
            >
              {/* Shield Outline */}
              <path
                d="M12 2L4 5V11C4 16.5 7.5 21.5 12 23C16.5 21.5 20 16.5 20 11V5L12 2Z"
                className={isDark ? 'fill-emerald-500/10 stroke-emerald-400' : 'fill-emerald-500/10 stroke-emerald-600'}
              />
              {/* Medical Heart Pulse Line */}
              <path
                d="M8 12H10.5L12 8.5L13.5 15.5L15 12H16"
                strokeWidth="2.2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="stroke-emerald-400"
              />
            </svg>
          </div>
        </div>
      </div>

      {/* Brand Typography */}
      <div className="flex flex-col text-left">
        <div className={`font-black uppercase flex items-center gap-1 ${titleSizes[size]}`}>
          <span className={isDark ? 'text-white' : 'text-zinc-950'}>UR</span>
          <span className="text-emerald-500">CARE</span>
        </div>
        {showSubtitle && (
          <span className={`font-bold uppercase opacity-60 text-emerald-500/90 ${subSizes[size]}`}>
            Clinical Nutrition
          </span>
        )}
      </div>
    </div>
  );
};
