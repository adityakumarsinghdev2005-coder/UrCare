import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { useTheme } from '../context/ThemeContext';

export const ThreeBackground: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { theme } = useTheme();
  const isDark = theme === 'dark';

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Scene setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.z = 28;

    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, powerPreference: 'high-performance' });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Group for DNA Double-Helix Structure
    const dnaGroup = new THREE.Group();
    scene.add(dnaGroup);

    // Build DNA Double-Helix Strands and Base Pairs
    const numRungs = 40;
    const strandRadius = 4.2;
    const heightStep = 0.85;
    const angleStep = 0.32;

    const nodeGeom = new THREE.SphereGeometry(0.22, 12, 12);
    const primaryStrandMat = new THREE.MeshBasicMaterial({
      color: isDark ? 0x10b981 : 0x059669,
      transparent: true,
      opacity: isDark ? 0.85 : 0.65,
    });

    const secondaryStrandMat = new THREE.MeshBasicMaterial({
      color: isDark ? 0x34d399 : 0x10b981,
      transparent: true,
      opacity: isDark ? 0.7 : 0.5,
    });

    const rungMat = new THREE.LineBasicMaterial({
      color: isDark ? 0x10b981 : 0x059669,
      transparent: true,
      opacity: isDark ? 0.35 : 0.25,
      linewidth: 1,
    });

    const startY = -(numRungs * heightStep) / 2;

    for (let i = 0; i < numRungs; i++) {
      const angle = i * angleStep;
      const y = startY + i * heightStep;

      // Strand 1 node
      const x1 = Math.cos(angle) * strandRadius;
      const z1 = Math.sin(angle) * strandRadius;
      const node1 = new THREE.Mesh(nodeGeom, primaryStrandMat);
      node1.position.set(x1, y, z1);
      dnaGroup.add(node1);

      // Strand 2 node (180 deg offset)
      const x2 = Math.cos(angle + Math.PI) * strandRadius;
      const z2 = Math.sin(angle + Math.PI) * strandRadius;
      const node2 = new THREE.Mesh(nodeGeom, secondaryStrandMat);
      node2.position.set(x2, y, z2);
      dnaGroup.add(node2);

      // Connecting Hydrogen Bond / Rung Line
      const lineGeom = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(x1, y, z1),
        new THREE.Vector3(x2, y, z2),
      ]);
      const rungLine = new THREE.Line(lineGeom, rungMat);
      dnaGroup.add(rungLine);
    }

    // Position DNA tilted slightly to the right side
    dnaGroup.position.set(12, 0, -5);
    dnaGroup.rotation.z = -0.25;

    // Ambient floating metabolic glow points
    const particleCount = 80;
    const particleGeom = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount * 3; i += 3) {
      positions[i] = (Math.random() - 0.5) * 50;
      positions[i + 1] = (Math.random() - 0.5) * 45;
      positions[i + 2] = (Math.random() - 0.5) * 20;
    }

    particleGeom.setAttribute('position', new THREE.BufferAttribute(positions, 3));

    const particleMat = new THREE.PointsMaterial({
      color: isDark ? 0x34d399 : 0x059669,
      size: isDark ? 0.3 : 0.2,
      transparent: true,
      opacity: isDark ? 0.45 : 0.3,
    });

    const particles = new THREE.Points(particleGeom, particleMat);
    scene.add(particles);

    // Mouse Parallax Interaction
    let mouseX = 0;
    let mouseY = 0;
    let targetX = 0;
    let targetY = 0;

    const handleMouseMove = (e: MouseEvent) => {
      mouseX = (e.clientX / window.innerWidth - 0.5) * 2;
      mouseY = (e.clientY / window.innerHeight - 0.5) * 2;
    };

    window.addEventListener('mousemove', handleMouseMove);

    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };

    window.addEventListener('resize', handleResize);

    // Animation Loop
    let animationFrameId: number;

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      // Continuous slow helical rotation
      dnaGroup.rotation.y += 0.008;

      // Parallax easing
      targetX += (mouseX - targetX) * 0.03;
      targetY += (mouseY - targetY) * 0.03;
      dnaGroup.position.x = 12 + targetX * 1.5;
      dnaGroup.position.y = -targetY * 1.2;

      // Particle drift
      particles.rotation.y += 0.0004;

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
      if (container && renderer.domElement) {
        container.innerHTML = '';
      }
      renderer.dispose();
    };
  }, [isDark]);

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 pointer-events-none z-0 overflow-hidden opacity-50 transition-opacity duration-700"
      aria-hidden="true"
    />
  );
};
