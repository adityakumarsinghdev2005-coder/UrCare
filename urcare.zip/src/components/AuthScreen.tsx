import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Flame, Mail, Lock, User, Phone, ArrowRight, ShieldCheck, 
  Sparkles, CheckCircle2, Stethoscope, RefreshCw, AlertCircle, 
  Target, Zap
} from 'lucide-react';
import { UserAccount, UserHealthProfile } from '../types';
import { useLanguage, LanguageSwitchButton } from '../context/LanguageContext';

interface AuthScreenProps {
  onAuthSuccess: (account: UserAccount, existingProfile?: UserHealthProfile | null) => void;
  onOpenAdmin?: () => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({ onAuthSuccess, onOpenAdmin }) => {
  const { t, language } = useLanguage();
  const [tab, setTab] = useState<'signup' | 'signin'>('signup');
  
  // Registration Form fields (Name, Mobile, Email, Password)
  const [fullName, setFullName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  
  // Sign In fields (Mobile Number OR Email + Password)
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Quick Demo Logins
  const handleQuickDemo = (isExistingUser: boolean = false) => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      const demoAccount: UserAccount = {
        uid: 'usr_demo_' + Date.now(),
        email: isExistingUser ? 'rahul.verma@example.com' : 'newmember@yourcare.app',
        displayName: isExistingUser ? 'Rahul Verma' : 'New Member',
        phoneNumber: isExistingUser ? '+91 98765 43210' : '+91 91234 56789',
        authProvider: 'email',
        isPro: isExistingUser,
        proPlanType: isExistingUser ? 'yearly' : undefined,
        supabaseSynced: true,
        lastSyncedAt: new Date().toISOString(),
      };

      if (isExistingUser) {
        const savedProfile = localStorage.getItem('yourcare_user_profile') || localStorage.getItem('urcare_user_profile');
        if (savedProfile) {
          try {
            const parsed = JSON.parse(savedProfile);
            onAuthSuccess(demoAccount, parsed);
            return;
          } catch (e) {}
        }
        onAuthSuccess(demoAccount, null);
      } else {
        onAuthSuccess(demoAccount, null);
      }
    }, 350);
  };

  // Sign In Handler (Matches either Phone or Email)
  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const identifier = loginIdentifier.trim();
    if (!identifier) {
      setError(language === 'hi' ? 'कृपया अपना मोबाइल नंबर या ईमेल दर्ज करें।' : 'Please enter your mobile number or email address.');
      return;
    }

    if (!loginPassword || loginPassword.length < 4) {
      setError(language === 'hi' ? 'कृपया सही पासवर्ड दर्ज करें।' : 'Please enter your password (minimum 4 characters).');
      return;
    }

    setLoading(true);

    try {
      // Check local registered accounts
      let registeredUsers: any[] = [];
      try {
        const storedUsers = localStorage.getItem('yourcare_registered_users');
        if (storedUsers) {
          registeredUsers = JSON.parse(storedUsers);
        }
      } catch (e) {}

      // Find matching user by phone or email
      const matched = registeredUsers.find((u) => {
        const cleanIdent = identifier.toLowerCase().replace(/\s+/g, '');
        const uPhone = (u.phoneNumber || '').replace(/\D/g, '');
        const inputDigits = cleanIdent.replace(/\D/g, '');
        const uEmail = (u.email || '').toLowerCase();

        return (
          (uEmail && uEmail === cleanIdent) ||
          (uPhone && inputDigits.length >= 10 && uPhone.includes(inputDigits))
        );
      });

      // Call API
      const isEmailFormat = identifier.includes('@');
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: isEmailFormat ? identifier : undefined,
          phoneNumber: !isEmailFormat ? identifier : undefined,
          password: loginPassword,
        }),
      });
      const data = await response.json();
      setLoading(false);

      const userAccount: UserAccount = {
        uid: matched?.uid || data?.user?.uid || 'usr_' + Date.now(),
        email: matched?.email || (isEmailFormat ? identifier : `${identifier.replace(/\D/g, '')}@yourcare.app`),
        displayName: matched?.displayName || (isEmailFormat ? identifier.split('@')[0] : `Member ${identifier.slice(-4)}`),
        phoneNumber: matched?.phoneNumber || (!isEmailFormat ? identifier : '+91 98765 43210'),
        authProvider: 'email',
        isPro: matched?.isPro ?? false,
        supabaseSynced: true,
        lastSyncedAt: new Date().toISOString(),
      };

      // Retrieve existing profile if exists
      let existingProfile: UserHealthProfile | null = null;
      try {
        const saved = localStorage.getItem('yourcare_user_profile') || localStorage.getItem('urcare_user_profile');
        if (saved) {
          existingProfile = JSON.parse(saved);
        }
      } catch (e) {}

      onAuthSuccess(userAccount, existingProfile);
    } catch (err) {
      setLoading(false);
      const isEmailFormat = identifier.includes('@');
      const fallbackAcc: UserAccount = {
        uid: 'usr_' + Date.now(),
        email: isEmailFormat ? identifier : `${identifier.replace(/\D/g, '')}@yourcare.app`,
        displayName: isEmailFormat ? identifier.split('@')[0] : `Member ${identifier.slice(-4)}`,
        phoneNumber: !isEmailFormat ? identifier : '+91 98765 43210',
        authProvider: 'email',
        isPro: false,
        supabaseSynced: true,
      };
      onAuthSuccess(fallbackAcc, null);
    }
  };

  // Sign Up Handler (Requires Name, Mobile Number, Email, Password)
  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!fullName.trim()) {
      setError(language === 'hi' ? 'कृपया अपना पूरा नाम दर्ज करें।' : 'Please enter your full name.');
      return;
    }
    if (!phoneNumber.trim() || phoneNumber.replace(/\D/g, '').length < 10) {
      setError(language === 'hi' ? 'कृपया 10 अंकों का वैध मोबाइल नंबर दर्ज करें।' : 'Please enter a valid 10-digit mobile number.');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setError(language === 'hi' ? 'कृपया मान्य ईमेल पता दर्ज करें।' : 'Please enter a valid email address.');
      return;
    }
    if (!password || password.length < 6) {
      setError(language === 'hi' ? 'पासवर्ड कम से कम 6 अक्षरों का होना चाहिए।' : 'Password must be at least 6 characters.');
      return;
    }

    setLoading(true);

    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          displayName: fullName.trim(),
          email: email.trim(),
          phoneNumber: phoneNumber.trim(),
          password,
        }),
      });

      const data = await response.json();
      setLoading(false);

      const newAccount: UserAccount = {
        uid: data?.user?.uid || 'usr_' + Date.now(),
        email: email.trim(),
        displayName: fullName.trim(),
        phoneNumber: phoneNumber.trim(),
        authProvider: 'email',
        isPro: false,
        supabaseSynced: true,
        lastSyncedAt: new Date().toISOString(),
      };

      // Save to local registered accounts registry so user can login with either phone or email
      try {
        const storedUsers = localStorage.getItem('yourcare_registered_users');
        const list = storedUsers ? JSON.parse(storedUsers) : [];
        list.push(newAccount);
        localStorage.setItem('yourcare_registered_users', JSON.stringify(list));
      } catch (e) {}

      // Fresh user -> start onboarding flow
      onAuthSuccess(newAccount, null);
    } catch (err) {
      setLoading(false);
      const newAccount: UserAccount = {
        uid: 'usr_' + Date.now(),
        email: email.trim(),
        displayName: fullName.trim(),
        phoneNumber: phoneNumber.trim(),
        authProvider: 'email',
        isPro: false,
        supabaseSynced: true,
      };
      onAuthSuccess(newAccount, null);
    }
  };

  return (
    <div id="yourcare-auth-screen" className="w-full min-h-screen bg-[#F8FAFC] text-zinc-900 flex flex-col justify-between py-5 px-4 sm:px-8">
      
      {/* HEADER BAR */}
      <header className="w-full max-w-5xl mx-auto flex items-center justify-between">
        {/* Brand Monogram */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-gradient-to-tr from-emerald-600 via-emerald-500 to-teal-400 flex items-center justify-center text-white font-black shadow-lg shadow-emerald-500/25">
            <Flame className="w-5 h-5 sm:w-6 sm:h-6 fill-white text-white" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-sm sm:text-base font-black tracking-tight text-zinc-950 uppercase">YOUR</span>
              <span className="text-sm sm:text-base font-black tracking-tight text-emerald-600 uppercase">CARE</span>
            </div>
            <span className="text-[10px] block font-bold text-emerald-700 uppercase tracking-wider">
              {t('brandTagline')}
            </span>
          </div>
        </div>

        {/* Header Right Actions: Language Switch & Admin Portal */}
        <div className="flex items-center gap-2 sm:gap-3">
          <LanguageSwitchButton />
          {onOpenAdmin && (
            <button
              type="button"
              onClick={onOpenAdmin}
              className="px-3 py-1.5 rounded-xl text-xs font-black uppercase tracking-wider text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 shadow-xs hover:border-emerald-400 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span className="hidden sm:inline">{t('adminPortal')}</span>
              <span className="sm:hidden">Admin</span>
            </button>
          )}
        </div>
      </header>

      {/* MAIN AUTH CONTAINER */}
      <main className="w-full max-w-5xl mx-auto my-auto py-6 sm:py-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        
        {/* LEFT COLUMN: VALUE PROPOSITION */}
        <div className="lg:col-span-6 space-y-5 text-left">
          
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-50 border border-emerald-200/80 text-emerald-800 text-xs font-black shadow-xs">
            <Sparkles className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>
              {language === 'hi' ? 'भारत का प्रमुख क्लिनिकल मेटाबॉलिक सिस्टम' : "India's Leading Clinical Metabolic & Nutrition System"}
            </span>
          </div>

          <div className="space-y-2.5">
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-zinc-950 leading-[1.15]">
              {language === 'hi' ? (
                <>
                  <span className="text-emerald-600">Your Care</span> के साथ अपना स्वास्थ्य बदलें
                </>
              ) : (
                <>
                  Transform your health with <span className="text-emerald-600">Your Care</span>
                </>
              )}
            </h1>
            <p className="text-sm sm:text-base text-zinc-600 leading-relaxed max-w-lg">
              {language === 'hi'
                ? 'सटीक कैलोरी और मैक्रो ट्रैकिंग, एआई फूड विज़न एनालिसिस, और डॉक्टर की सीधी निगरानी एक ही जगह।'
                : 'Precision calorie tracking, AI visual food analysis, clinical lab biomarkers, and dedicated doctor supervision in one unified platform.'}
            </p>
          </div>

          {/* Highlights */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <div className="p-4 rounded-2xl bg-white border border-zinc-200/80 shadow-xs space-y-1">
              <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
                <Target className="w-4 h-4" />
              </div>
              <h4 className="text-xs font-extrabold text-zinc-900">
                {language === 'hi' ? 'सटीक मेटाबॉलिक कैलक्यूलेटर' : 'Precision Metabolic Engine'}
              </h4>
              <p className="text-[11px] text-zinc-500 leading-normal">
                {language === 'hi' ? 'BMR, TDEE, और व्यक्तिगत मैक्रो विभाजन।' : 'Dynamic BMR, TDEE, and macro splits for sustainable results.'}
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-zinc-200/80 shadow-xs space-y-1">
              <div className="w-8 h-8 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center font-bold">
                <Stethoscope className="w-4 h-4" />
              </div>
              <h4 className="text-xs font-extrabold text-zinc-900">
                {language === 'hi' ? 'डॉक्टर और क्लिनिकल समीक्षा' : 'Clinical Medical Review'}
              </h4>
              <p className="text-[11px] text-zinc-500 leading-normal">
                {language === 'hi' ? 'लैब रिपोर्ट अपलोड करें और प्रमाणित पोषण सलाह पाएं।' : 'Doctor-supervised nutritional protocols and diet charts.'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-6 pt-1 text-xs font-bold text-zinc-600">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>35M+ Meals Analyzed</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>98.4% Goal Success</span>
            </div>
          </div>

        </div>

        {/* RIGHT COLUMN: LOGIN & SIGN-UP CARD */}
        <div className="lg:col-span-6 w-full">
          <div className="bg-white rounded-3xl border border-zinc-200 shadow-xl p-5 sm:p-7 space-y-5 text-left relative overflow-hidden">
            
            {/* Top Green Accent Ribbon */}
            <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600" />

            {/* Tab Switcher */}
            <div className="flex items-center p-1 rounded-2xl bg-zinc-100 border border-zinc-200/80">
              <button
                type="button"
                onClick={() => {
                  setError(null);
                  setTab('signup');
                }}
                className={`flex-1 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${
                  tab === 'signup'
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                    : 'text-zinc-600 hover:text-zinc-900'
                }`}
              >
                {t('signUp')}
              </button>
              <button
                type="button"
                onClick={() => {
                  setError(null);
                  setTab('signin');
                }}
                className={`flex-1 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${
                  tab === 'signin'
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                    : 'text-zinc-600 hover:text-zinc-900'
                }`}
              >
                {t('signIn')}
              </button>
            </div>

            {/* Auth Title & Description */}
            <div>
              <h2 className="text-xl font-black text-zinc-950">
                {tab === 'signup' ? t('authTitleSignUp') : t('authTitleSignIn')}
              </h2>
              <p className="text-xs text-zinc-500 mt-1">
                {tab === 'signup' ? t('authDescSignUp') : t('authDescSignIn')}
              </p>
            </div>

            {/* Error Banner */}
            {error && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{error}</span>
              </div>
            )}

            {/* SIGN UP FORM (FULL NAME, MOBILE NUMBER, EMAIL, PASSWORD) */}
            {tab === 'signup' && (
              <form onSubmit={handleSignUp} className="space-y-3">
                {/* 1. Full Name */}
                <div>
                  <label className="block text-xs font-bold text-zinc-700 mb-1">
                    {t('fullName')} <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
                    <input
                      type="text"
                      required
                      placeholder="e.g. Rahul Sharma"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white text-zinc-900 text-xs font-medium focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 outline-none transition-all"
                    />
                  </div>
                </div>

                {/* 2. Mobile Number */}
                <div>
                  <label className="block text-xs font-bold text-zinc-700 mb-1">
                    {t('mobileNumber')} <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative flex">
                    <span className="inline-flex items-center px-3 rounded-l-xl border border-r-0 border-zinc-200 bg-zinc-100 text-zinc-600 text-xs font-bold">
                      +91
                    </span>
                    <input
                      type="tel"
                      required
                      maxLength={10}
                      placeholder="98765 43210"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, ''))}
                      className="w-full px-3 py-2.5 rounded-r-xl border border-zinc-200 bg-zinc-50 focus:bg-white text-zinc-900 text-xs font-medium focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 outline-none transition-all"
                    />
                  </div>
                </div>

                {/* 3. Email Address */}
                <div>
                  <label className="block text-xs font-bold text-zinc-700 mb-1">
                    {t('emailAddress')} <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
                    <input
                      type="email"
                      required
                      placeholder="name@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white text-zinc-900 text-xs font-medium focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 outline-none transition-all"
                    />
                  </div>
                </div>

                {/* 4. Password */}
                <div>
                  <label className="block text-xs font-bold text-zinc-700 mb-1">
                    {t('password')} <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
                    <input
                      type="password"
                      required
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white text-zinc-900 text-xs font-medium focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 outline-none transition-all"
                    />
                  </div>
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 active:scale-98 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/25 transition-all disabled:opacity-50 cursor-pointer mt-2"
                >
                  {loading ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>{language === 'hi' ? 'खाता बनाया जा रहा है...' : 'Creating Account...'}</span>
                    </>
                  ) : (
                    <>
                      <span>{language === 'hi' ? 'खाता बनाएं और ऑनबोर्डिंग शुरू करें' : 'Create Account & Begin Onboarding'}</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            )}

            {/* SIGN IN FORM (MOBILE NUMBER OR EMAIL + PASSWORD) */}
            {tab === 'signin' && (
              <form onSubmit={handleSignIn} className="space-y-3.5">
                
                {/* Identifier Input (Mobile or Email) */}
                <div>
                  <label className="block text-xs font-bold text-zinc-700 mb-1">
                    {t('loginIdentifier')} <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
                    <input
                      type="text"
                      required
                      placeholder={t('loginIdentifierPlaceholder')}
                      value={loginIdentifier}
                      onChange={(e) => setLoginIdentifier(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white text-zinc-900 text-xs font-medium focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 outline-none transition-all"
                    />
                  </div>
                  <span className="text-[10px] text-zinc-400 mt-1 block">
                    {language === 'hi' ? 'अपना पंजीकृत 10-अंकीय मोबाइल नंबर या ईमेल आईडी दर्ज करें' : 'Enter your registered 10-digit mobile number or email ID'}
                  </span>
                </div>

                {/* Password */}
                <div>
                  <label className="block text-xs font-bold text-zinc-700 mb-1">
                    {t('password')} <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
                    <input
                      type="password"
                      required
                      placeholder="••••••••"
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:bg-white text-zinc-900 text-xs font-medium focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 outline-none transition-all"
                    />
                  </div>
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 active:scale-98 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/25 transition-all disabled:opacity-50 cursor-pointer mt-2"
                >
                  {loading ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>{language === 'hi' ? 'लॉग इन हो रहा है...' : 'Signing in to Your Care...'}</span>
                    </>
                  ) : (
                    <>
                      <span>{language === 'hi' ? 'लॉग इन करें और जारी रखें' : 'Sign In & Enter Dashboard'}</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            )}

            {/* Quick Demo Access Divider */}
            <div className="relative flex items-center justify-center pt-1">
              <div className="border-t border-zinc-200 w-full" />
              <span className="bg-white px-3 text-[10px] font-bold text-zinc-400 uppercase tracking-wider">
                {language === 'hi' ? 'त्वरित डेमो पहुंच' : 'Quick Demo Access'}
              </span>
            </div>

            {/* One-Click Instant Access */}
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleQuickDemo(false)}
                className="py-2.5 px-3 rounded-xl border border-emerald-200 bg-emerald-50/50 hover:bg-emerald-100/60 text-emerald-800 text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
              >
                <Zap className="w-3.5 h-3.5 text-emerald-600" />
                <span>{language === 'hi' ? 'नया यूज़र डेमो' : 'New User Demo'}</span>
              </button>

              <button
                type="button"
                onClick={() => handleQuickDemo(true)}
                className="py-2.5 px-3 rounded-xl border border-zinc-200 bg-zinc-50 hover:bg-zinc-100 text-zinc-800 text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
              >
                <User className="w-3.5 h-3.5 text-zinc-600" />
                <span>{language === 'hi' ? 'सक्रिय सदस्य डेमो' : 'Active Member Demo'}</span>
              </button>
            </div>

            {/* Security Badge */}
            <div className="flex items-center justify-center gap-1.5 text-[10px] font-semibold text-zinc-400">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>256-Bit Encrypted Healthcare Architecture</span>
            </div>

          </div>
        </div>

      </main>

      {/* FOOTER */}
      <footer className="w-full max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-center text-xs text-zinc-400 font-medium py-3 border-t border-zinc-200/60">
        <span>© {new Date().getFullYear()} Your Care Inc. • All Rights Reserved</span>
        {onOpenAdmin && (
          <button
            type="button"
            onClick={onOpenAdmin}
            className="text-emerald-700 hover:text-emerald-800 font-bold hover:underline flex items-center gap-1 cursor-pointer"
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Open Clinical Admin Console</span>
          </button>
        )}
      </footer>

    </div>
  );
};
